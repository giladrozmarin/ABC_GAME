#!/bin/bash
set -e

echo "=== Test 1: Simple field extraction ==="
echo '{"name": "John", "age": 30}' | node dist/index.js '$.name'
echo "Expected: \"John\""

echo -e "\n=== Test 2: Nested object access ==="
echo '{"user": {"name": "Alice", "email": "alice@example.com"}}' | node dist/index.js '$.user.name'
echo "Expected: \"Alice\""

echo -e "\n=== Test 3: Array index access ==="
echo '{"users": [{"id": 1, "name": "Bob"}, {"id": 2, "name": "Carol"}]}' | node dist/index.js '$.users[0].name'
echo "Expected: \"Bob\""

echo -e "\n=== Test 4: Wildcard extraction ==="
echo '{"users": [{"id": 1, "name": "Bob"}, {"id": 2, "name": "Carol"}]}' | node dist/index.js '$.users.*.id'
echo "Expected: 1 and 2 on separate lines"

echo -e "\n=== Test 5: Root level array ==="
echo '[{"id": 1, "status": "active"}, {"id": 2, "status": "inactive"}]' | node dist/index.js '$.*.status'
echo "Expected: \"active\" and \"inactive\""

echo -e "\n=== Test 6: Compact output ==="
echo '{"nested": {"value": "test"}}' | node dist/index.js -c '$.nested'
echo "Expected: {\"value\":\"test\"}"

echo -e "\n=== Test 7: Raw output ==="
echo '{"message": "Hello World"}' | node dist/index.js -r '$.message'
echo "Expected: Hello World (without quotes)"

echo -e "\n=== Test 8: Filter by field value ==="
echo '{"name": "alice", "status": "active"}' | node dist/index.js -f 'status=active' '$'
echo "Expected: {\"name\":\"alice\",\"status\":\"active\"} (pretty printed)"

echo -e "\n✅ All tests completed!"
