# JSON Query/Filter CLI Tool

A lightweight, zero-dependency CLI tool for querying and filtering JSON data, similar to `jq` but optimized for simplicity and speed.

## Features

- **Path Queries**: Extract values using simple path syntax like `$.name`, `$.users[0].email`
- **Wildcard Support**: Use `*` to match all items in arrays or object values
- **Filtering**: Filter results by field values or regex patterns
- **Multiple Formats**: Compact, raw, and pretty-printed output options
- **Streaming**: Process one JSON object per line or slurp multiple objects
- **Zero Dependencies**: Pure Node.js, no external libraries required

## Installation

```bash
npm install
npm run build
```

## Usage

### Basic Syntax

```bash
cat data.json | node dist/index.js [OPTIONS] <QUERY>
```

### Query Syntax

- `$.fieldname` - Extract a top-level field
- `$.parent.child` - Access nested objects
- `$.items[0]` - Access array elements by index
- `$.*.id` - Extract all `id` fields from an array or object
- `$` - Return the entire object

### Examples

#### Extract single value
```bash
echo '{"name": "John", "age": 30}' | node dist/index.js '$.name'
# Output: "John"
```

#### Access nested object
```bash
echo '{"user": {"name": "Alice", "email": "alice@example.com"}}' | node dist/index.js '$.user.email'
# Output: "alice@example.com"
```

#### Access array element
```bash
echo '{"users": [{"id": 1, "name": "Bob"}, {"id": 2, "name": "Carol"}]}' | node dist/index.js '$.users[0].name'
# Output: "Bob"
```

#### Extract multiple values with wildcard
```bash
echo '{"users": [{"id": 1, "name": "Bob"}, {"id": 2, "name": "Carol"}]}' | node dist/index.js '$.users.*.id'
# Output:
# 1
# 2
```

#### Working with arrays
```bash
echo '[{"id": 1, "status": "active"}, {"id": 2, "status": "inactive"}]' | node dist/index.js '$.*.status'
# Output:
# "active"
# "inactive"
```

### Options

- `-c, --compact` - Output JSON without pretty printing
- `-r, --raw` - Output raw strings without JSON quotes
- `-s, --slurp` - Combine all input lines into a single array and query it
- `-f, --filter <EXPR>` - Filter results by field value

### Filter Examples

#### Equality filter
```bash
echo '{"name": "alice", "status": "active"}' | node dist/index.js -f 'status=active' '$'
# Returns objects where status equals "active"
```

#### Regex filter
```bash
echo '[{"email": "alice@example.com"}, {"email": "bob@test.org"}]' | node dist/index.js -f 'email~example' '$.*.email'
# Returns values matching the pattern
```

## Testing

Run the test suite:

```bash
npm test
```

This will test:
- Simple field extraction
- Nested object access
- Array index access
- Wildcard extraction
- Raw output
- Filtering

## Implementation Details

- Written in TypeScript, compiled to JavaScript
- Single source file (`src/index.ts`) for easy understanding
- Recursive path traversal for flexible querying
- Supports both streaming and batch processing
- Proper error handling with clear error messages

## Performance

- Fast startup (no dependencies to load)
- Efficient path traversal
- Memory-efficient streaming by default
- Optional slurp mode for batch processing

## Limitations

- Basic filter syntax (no complex boolean logic yet)
- No recursive descent operator (`..`)
- No custom functions
- Array slicing not yet supported (only direct indexing)

These can be added in future versions if needed.

## License

ISC
