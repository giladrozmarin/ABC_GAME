import * as fs from 'fs';
import * as readline from 'readline';

interface QueryOptions {
  filter?: string;
  compact?: boolean;
  raw?: boolean;
  slurp?: boolean;
}

class JSONQuery {
  static queryValue(obj: any, path: string): any[] {
    const parts = path.split('.');
    let results: any[] = [];

    const traverse = (current: any, pathParts: string[]): any[] => {
      if (pathParts.length === 0) return [current];

      const part = pathParts[0];
      const remaining = pathParts.slice(1);

      // Handle array index notation like [0] or [1]
      const arrayMatch = part.match(/^(\w+)\[(\d+)\]$/);
      if (arrayMatch) {
        const key = arrayMatch[1];
        const index = parseInt(arrayMatch[2]);
        if (current && typeof current === 'object' && key in current) {
          const arr = current[key];
          if (Array.isArray(arr) && index < arr.length) {
            return traverse(arr[index], remaining);
          }
        }
        return [];
      }

      // Handle wildcard *
      if (part === '*') {
        let collected: any[] = [];
        if (Array.isArray(current)) {
          current.forEach(item => {
            collected = collected.concat(traverse(item, remaining));
          });
        } else if (typeof current === 'object' && current !== null) {
          Object.values(current).forEach(value => {
            collected = collected.concat(traverse(value, remaining));
          });
        }
        return collected;
      }

      // Handle regular property access
      if (current && typeof current === 'object' && part in current) {
        return traverse(current[part], remaining);
      }

      return [];
    };

    // Handle $. prefix
    let cleanPath = path.startsWith('$.') ? path.slice(2) : path;
    if (cleanPath === '' || cleanPath === '$') {
      return [obj];
    }

    return traverse(obj, cleanPath.split('.'));
  }

  static filterObjects(objs: any[], filterExpr: string): any[] {
    // Simple filter: field=value or field~regex
    const eqMatch = filterExpr.match(/^(\w+)=(.+)$/);
    if (eqMatch) {
      const [, field, value] = eqMatch;
      return objs.filter(obj => {
        const val = obj[field];
        if (val === undefined) return false;
        return String(val) === value || val === JSON.parse(value);
      });
    }

    const regexMatch = filterExpr.match(/^(\w+)~(.+)$/);
    if (regexMatch) {
      const [, field, pattern] = regexMatch;
      const regex = new RegExp(pattern);
      return objs.filter(obj => {
        const val = obj[field];
        return val !== undefined && regex.test(String(val));
      });
    }

    return objs;
  }

  static format(value: any, compact: boolean, raw: boolean): string {
    if (raw && typeof value === 'string') {
      return value;
    }
    if (compact) {
      return JSON.stringify(value);
    }
    return JSON.stringify(value, null, 2);
  }
}

async function main() {
  const args = process.argv.slice(2);

  let query = '$';
  const options: QueryOptions = {};

  // Parse arguments
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '-c' || args[i] === '--compact') {
      options.compact = true;
    } else if (args[i] === '-r' || args[i] === '--raw') {
      options.raw = true;
    } else if (args[i] === '-s' || args[i] === '--slurp') {
      options.slurp = true;
    } else if (args[i] === '-f' || args[i] === '--filter') {
      options.filter = args[++i];
    } else if (!args[i].startsWith('-')) {
      query = args[i];
    }
  }

  let jsonData: any;
  let inputs: string[] = [];

  // Read from stdin
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: false,
  });

  for await (const line of rl) {
    inputs.push(line);
  }

  if (inputs.length === 0) {
    console.error('Error: No JSON input provided');
    process.exit(1);
  }

  try {
    if (options.slurp) {
      // Combine all inputs into an array
      jsonData = inputs.map(line => {
        const trimmed = line.trim();
        return trimmed ? JSON.parse(trimmed) : null;
      }).filter(x => x !== null);
    } else {
      // Process each line separately
      let hasOutput = false;
      for (const line of inputs) {
        const trimmed = line.trim();
        if (!trimmed) continue;

        const obj = JSON.parse(trimmed);
        let results = JSONQuery.queryValue(obj, query);

        if (options.filter) {
          results = JSONQuery.filterObjects(results, options.filter);
        }

        results.forEach(result => {
          console.log(JSONQuery.format(result, options.compact || false, options.raw || false));
          hasOutput = true;
        });
      }

      if (hasOutput) return;
      process.exit(0);
    }

    // Process slurped data
    let results = JSONQuery.queryValue(jsonData, query);

    if (options.filter) {
      results = JSONQuery.filterObjects(results, options.filter);
    }

    results.forEach(result => {
      console.log(JSONQuery.format(result, options.compact || false, options.raw || false));
    });
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
