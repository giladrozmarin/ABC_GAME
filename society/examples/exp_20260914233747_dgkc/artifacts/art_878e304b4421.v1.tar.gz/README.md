# TodoSync - CLI Todo Manager

A blazingly fast, elegant command-line todo manager with priority levels and automatic persistence.

## Features

✨ **Fast & Lightweight**: Pure Python, no heavy dependencies  
📊 **Priority System**: Low (⬜), Medium (🟨), High (🔴) priority levels  
💾 **Auto-Persistence**: Todos saved to JSON automatically  
🎯 **Simple CLI**: Intuitive commands  
✓ **Fully Tested**: Comprehensive unit test suite  

## Quick Start

```bash
# Add a todo
python todo_cli.py add "Buy groceries"

# Add with high priority
python todo_cli.py add "Finish report" --priority 3

# View all todos
python todo_cli.py list

# Mark as done
python todo_cli.py done 1

# Remove a todo
python todo_cli.py rm 1

# Show statistics
python todo_cli.py stats
```

## Commands

| Command | Example | Description |
|---------|---------|-------------|
| `add <text>` | `add "Buy milk"` | Add a new todo (medium priority by default) |
| `add <text> --priority <1-3>` | `add "Urgent fix" --priority 3` | Add todo with specific priority |
| `done <id>` | `done 1` | Mark todo as completed |
| `rm <id>` | `rm 2` | Delete a todo |
| `list` | `list` | Show active todos (default) |
| `list --all` | `list --all` | Show all todos including completed |
| `stats` | `stats` | Show summary statistics |
| `help` | `help` | Display help message |

## Priority Levels

- **1**: Low priority (⬜)
- **2**: Medium priority (🟨) - default
- **3**: High priority (🔴)

Todos are automatically sorted by priority when displayed.

## Data Storage

Todos are stored in `.todos.json` in your current directory. You can back it up or sync across machines.

Example `.todos.json`:
```json
[
  {
    "id": 1,
    "text": "Buy groceries",
    "priority": 2,
    "completed": false,
    "created": "2026-09-14T23:40:00"
  }
]
```

## Testing

Run the full test suite:

```bash
python -m pytest test_todo_cli.py -v
# OR
python -m unittest test_todo_cli.py
```

Tests cover:
- ✓ Adding todos with validation
- ✓ Removing todos
- ✓ Marking todos complete
- ✓ Persistence to disk
- ✓ Priority sorting
- ✓ Statistics generation

## Installation

No dependencies! Just run directly:

```bash
chmod +x todo_cli.py
./todo_cli.py add "My task"
```

Or install as a module/script:

```bash
python setup.py install
```

## Performance

- **Add**: O(1) - instant
- **Complete/Remove**: O(n) where n = number of todos (typically very small)
- **List**: O(n log n) due to sorting

With typical usage (< 200 todos), all operations complete in < 1ms.

## Why TodoSync?

Most todo apps are bloated. TodoSync is:
- **No internet required**: Works completely offline
- **No database**: Just JSON
- **No dependencies**: Pure Python 3
- **Portable**: Take your `.todos.json` anywhere
- **Scriptable**: Easy to integrate into other tools

Perfect for developers who live in the terminal.

---

Built for speed. Built for simplicity. Built for you. 🚀

**License**: MIT  
**Author**: Agent B  
**Python**: 3.7+
