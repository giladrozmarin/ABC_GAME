# NotesSync - CLI Note Manager

A fast, powerful note-taking tool for the terminal with tagging, searching, and pinning. Capture and organize your thoughts without leaving the command line.

## Features

📝 **Instant Note Taking**: Create notes from the terminal in seconds  
🏷️ **Smart Tagging**: Organize notes with flexible tagging system  
🔍 **Full-Text Search**: Find notes by title or content  
📌 **Pin Important Notes**: Mark notes for quick access  
✏️ **Edit & Modify**: Update note content anytime  
💾 **Auto-Persistence**: All notes saved to JSON automatically  
✓ **Fully Tested**: 16 comprehensive unit tests  

## Quick Start

```bash
# Create a note
python notes_cli.py add "Project Ideas" "Build a web framework #project #python"

# List all notes
python notes_cli.py list

# View a specific note
python notes_cli.py view 1

# Search notes
python notes_cli.py search "web"

# Pin important notes
python notes_cli.py pin 1

# Edit a note
python notes_cli.py edit 1 "Updated content"

# Update tags
python notes_cli.py tag 1 python web framework

# Delete a note
python notes_cli.py delete 1

# Show statistics
python notes_cli.py stats
```

## Commands

| Command | Example | Description |
|---------|---------|-------------|
| `add <title> <content>` | `add "Ideas" "Brainstorm topics"` | Create a new note |
| `add <title> <content> [#tags]` | `add "Note" "Content #tag1 #tag2"` | Add note with tags |
| `view <id>` | `view 1` | Display full note content |
| `delete <id>` | `delete 2` | Remove a note |
| `pin <id>` | `pin 1` | Pin/unpin important notes |
| `edit <id> <content>` | `edit 1 "New text"` | Update note content |
| `tag <id> <tags>...` | `tag 1 python web` | Add/update tags |
| `search <query>` | `search "python"` | Search by title or content |
| `list` | `list` | Show all notes (default) |
| `list --tag <name>` | `list --tag python` | Filter by tag |
| `stats` | `stats` | Show summary statistics |
| `help` | `help` | Display help message |

## Tagging System

Tags help you organize notes thematically. Use them when creating notes:

```bash
# Create note with inline tags
python notes_cli.py add "Learning Goals" "Study Python and databases #python #databases #learning"

# Add tags later
python notes_cli.py tag 1 urgent important

# Filter by tag
python notes_cli.py list --tag python
```

## Pinning

Pin important or frequently-accessed notes to keep them visible:

```bash
# Toggle pin status
python notes_cli.py pin 1

# Pinned notes appear at the top when listing
python notes_cli.py list
```

## Data Storage

Notes are stored in `.notes.json`. Each note includes:
- Unique ID for reference
- Title and content
- Tags for organization
- Creation and modification timestamps
- Pin status

Example `.notes.json`:
```json
[
  {
    "id": 1,
    "title": "Project Ideas",
    "content": "Build a web framework",
    "tags": ["project", "python"],
    "created": "2026-09-14T23:40:00",
    "modified": "2026-09-14T23:42:00",
    "pinned": true
  }
]
```

## Testing

Run the comprehensive test suite:

```bash
python -m unittest test_notes_cli.py -v
```

Test coverage includes:
- ✓ Creating notes with/without tags
- ✓ Viewing and deleting notes
- ✓ Pinning/unpinning
- ✓ Editing content
- ✓ Tag management
- ✓ Full-text search
- ✓ Persistence to disk
- ✓ Statistics generation
- ✓ Tag-based filtering

## Use Cases

### Capture Quick Ideas
```bash
python notes_cli.py add "Startup idea" "Platform for community learning #idea #startup"
```

### Organize Research
```bash
python notes_cli.py add "ML Papers" "List of important papers to read #research #ml"
python notes_cli.py tag 1 deep-learning neural-networks
```

### Keep Meeting Notes
```bash
python notes_cli.py add "Team Meeting 9/14" "Discussed Q4 roadmap #meeting #work"
python notes_cli.py pin 1
```

### Maintain Code Snippets
```bash
python notes_cli.py add "Python Patterns" "Useful decorators and context managers #code #python"
```

## Performance

- **Create**: O(1) - instant
- **Search**: O(n) - linear scan (typically < 1ms for < 1000 notes)
- **Edit/Delete**: O(n) - find and update (< 1ms typical)
- **List**: O(n log n) - sorted display (< 5ms typical)

## Installation

No dependencies required! Just Python 3.7+:

```bash
chmod +x notes_cli.py
./notes_cli.py add "My first note" "Hello from NotesSync!"
```

## Why NotesSync?

- **Zero Overhead**: No cloud, no account, no ads
- **Offline First**: Works completely offline
- **Portable**: Take `.notes.json` anywhere
- **Scriptable**: Easy to integrate into workflows
- **Developer Friendly**: Lives in your terminal

Perfect for developers, writers, researchers, and anyone who loves the command line.

---

**License**: MIT  
**Author**: Agent B  
**Python**: 3.7+  
**Tests**: 16 passing  
**Dependencies**: None
