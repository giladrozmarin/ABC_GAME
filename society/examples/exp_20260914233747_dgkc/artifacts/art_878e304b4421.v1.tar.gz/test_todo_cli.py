#!/usr/bin/env python3
"""Tests for TodoSync CLI."""

import unittest
import tempfile
import os
from pathlib import Path
from todo_cli import TodoManager


class TestTodoManager(unittest.TestCase):
    """Test TodoManager functionality."""

    def setUp(self):
        """Create a temporary file for testing."""
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.json')
        self.temp_file.close()
        self.manager = TodoManager(self.temp_file.name)

    def tearDown(self):
        """Clean up temporary files."""
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)

    def test_add_todo(self):
        """Test adding a todo."""
        result = self.manager.add("Test task", priority=2)
        self.assertIn("Added", result)
        self.assertEqual(len(self.manager.todos), 1)
        self.assertEqual(self.manager.todos[0]["text"], "Test task")

    def test_add_empty_todo_fails(self):
        """Test that adding empty todo fails."""
        result = self.manager.add("", priority=2)
        self.assertIn("Error", result)
        self.assertEqual(len(self.manager.todos), 0)

    def test_add_invalid_priority_fails(self):
        """Test that invalid priority fails."""
        result = self.manager.add("Task", priority=5)
        self.assertIn("Error", result)
        self.assertEqual(len(self.manager.todos), 0)

    def test_remove_todo(self):
        """Test removing a todo."""
        self.manager.add("Task to remove", priority=1)
        result = self.manager.remove(1)
        self.assertIn("Removed", result)
        self.assertEqual(len(self.manager.todos), 0)

    def test_remove_nonexistent_fails(self):
        """Test removing non-existent todo fails."""
        result = self.manager.remove(999)
        self.assertIn("Error", result)

    def test_complete_todo(self):
        """Test completing a todo."""
        self.manager.add("Task to complete", priority=2)
        result = self.manager.complete(1)
        self.assertIn("Completed", result)
        self.assertTrue(self.manager.todos[0]["completed"])

    def test_complete_nonexistent_fails(self):
        """Test completing non-existent todo fails."""
        result = self.manager.complete(999)
        self.assertIn("Error", result)

    def test_persistence(self):
        """Test that todos persist to disk."""
        self.manager.add("Persistent task", priority=3)

        # Create new manager with same file
        manager2 = TodoManager(self.temp_file.name)
        self.assertEqual(len(manager2.todos), 1)
        self.assertEqual(manager2.todos[0]["text"], "Persistent task")

    def test_priority_sorting(self):
        """Test that todos are sorted by priority."""
        self.manager.add("Low priority", priority=1)
        self.manager.add("High priority", priority=3)
        self.manager.add("Medium priority", priority=2)

        output = self.manager.list_todos()
        # High priority should appear first
        high_idx = output.find("High priority")
        med_idx = output.find("Medium priority")
        low_idx = output.find("Low priority")

        self.assertGreater(med_idx, high_idx)
        self.assertGreater(low_idx, med_idx)

    def test_stats(self):
        """Test stats generation."""
        self.manager.add("Task 1", priority=3)
        self.manager.add("Task 2", priority=2)
        self.manager.complete(1)

        stats = self.manager.stats()
        self.assertIn("2 total", stats)
        self.assertIn("1 completed", stats)
        self.assertIn("0 high-priority", stats)


if __name__ == '__main__':
    unittest.main()
