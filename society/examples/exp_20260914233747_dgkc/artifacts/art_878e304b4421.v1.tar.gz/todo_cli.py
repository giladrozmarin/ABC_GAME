#!/usr/bin/env python3
"""
TodoSync - A blazingly fast CLI todo manager with priority support.
Manage your tasks from the terminal with automatic persistence.
"""

import json
import sys
from pathlib import Path
from datetime import datetime
from typing import List, Optional
import os


class TodoManager:
    """Manages todos with priority levels and persistence."""

    def __init__(self, filepath: str = ".todos.json"):
        self.filepath = Path(filepath)
        self.todos = self._load()

    def _load(self) -> List[dict]:
        """Load todos from disk, or return empty list if file doesn't exist."""
        if not self.filepath.exists():
            return []
        try:
            with open(self.filepath) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []

    def _save(self):
        """Persist todos to disk."""
        with open(self.filepath, 'w') as f:
            json.dump(self.todos, f, indent=2)

    def add(self, text: str, priority: int = 2) -> str:
        """Add a new todo. Priority: 1=low, 2=medium, 3=high."""
        if not text.strip():
            return "Error: Todo text cannot be empty"
        if priority not in (1, 2, 3):
            return "Error: Priority must be 1, 2, or 3"

        todo = {
            "id": len(self.todos) + 1,
            "text": text.strip(),
            "priority": priority,
            "completed": False,
            "created": datetime.now().isoformat()
        }
        self.todos.append(todo)
        self._save()
        return f"✓ Added: {text} (priority: {priority})"

    def remove(self, todo_id: int) -> str:
        """Remove a todo by ID."""
        for i, todo in enumerate(self.todos):
            if todo["id"] == todo_id:
                text = todo["text"]
                self.todos.pop(i)
                self._save()
                return f"✓ Removed: {text}"
        return f"Error: Todo ID {todo_id} not found"

    def complete(self, todo_id: int) -> str:
        """Mark a todo as completed."""
        for todo in self.todos:
            if todo["id"] == todo_id:
                if todo["completed"]:
                    return f"Todo {todo_id} is already completed"
                todo["completed"] = True
                self._save()
                return f"✓ Completed: {todo['text']}"
        return f"Error: Todo ID {todo_id} not found"

    def list_todos(self, show_completed: bool = False) -> str:
        """List all active todos, sorted by priority (high to low)."""
        if not self.todos:
            return "No todos yet! Use 'add <text>' to create one."

        # Filter and sort
        active = [t for t in self.todos if not t.get("completed", False)]
        if not active and not show_completed:
            return "All todos completed! 🎉"

        if show_completed:
            active = self.todos

        active.sort(key=lambda x: -x["priority"])

        # Format output
        priority_symbols = {1: "⬜", 2: "🟨", 3: "🔴"}
        lines = ["┌─ TODOS ─────────────────────┐"]
        for todo in active:
            symbol = priority_symbols[todo["priority"]]
            status = "✓" if todo.get("completed") else " "
            lines.append(f"│ [{status}] {symbol} #{todo['id']}: {todo['text']}")
        lines.append("└──────────────────────────────┘")

        return "\n".join(lines)

    def stats(self) -> str:
        """Show statistics."""
        total = len(self.todos)
        completed = sum(1 for t in self.todos if t.get("completed"))
        high_pri = sum(1 for t in self.todos if t["priority"] == 3 and not t.get("completed"))

        return f"📊 Stats: {total} total | {completed} completed | {high_pri} high-priority"


def main():
    """CLI entry point."""
    manager = TodoManager()

    if len(sys.argv) < 2:
        print(manager.list_todos())
        print(f"\n{manager.stats()}")
        return

    cmd = sys.argv[1].lower()

    if cmd == "add" and len(sys.argv) > 2:
        text = " ".join(sys.argv[2:])
        priority = 2
        # Check for priority flag: "add task --priority 3"
        if "--priority" in sys.argv:
            idx = sys.argv.index("--priority")
            if idx + 1 < len(sys.argv):
                try:
                    priority = int(sys.argv[idx + 1])
                    text = " ".join(sys.argv[2:idx])
                except ValueError:
                    pass
        print(manager.add(text, priority))

    elif cmd == "rm" and len(sys.argv) > 2:
        try:
            todo_id = int(sys.argv[2])
            print(manager.remove(todo_id))
        except ValueError:
            print(f"Error: Invalid todo ID '{sys.argv[2]}'")

    elif cmd == "done" and len(sys.argv) > 2:
        try:
            todo_id = int(sys.argv[2])
            print(manager.complete(todo_id))
        except ValueError:
            print(f"Error: Invalid todo ID '{sys.argv[2]}'")

    elif cmd == "list":
        show_completed = "--all" in sys.argv
        print(manager.list_todos(show_completed))
        print(f"\n{manager.stats()}")

    elif cmd == "help":
        print("""
TodoSync - Fast CLI Todo Manager

Commands:
  add <text>           Add a new todo (default priority: 2)
  add <text> --priority <1-3>  Add with specific priority
  done <id>            Mark todo as completed
  rm <id>              Remove a todo
  list                 List active todos (default)
  list --all           Show all todos including completed
  help                 Show this help message
  stats                Show statistics

Examples:
  $ todo-cli add "Buy groceries"
  $ todo-cli add "Finish report" --priority 3
  $ todo-cli list
  $ todo-cli done 1
        """)

    elif cmd == "stats":
        print(manager.stats())

    else:
        print(f"Unknown command: {cmd}")
        print("Use 'help' for usage information")
