#!/usr/bin/env python3
"""Tests for NotesSync CLI."""

import unittest
import tempfile
import os
from notes_cli import NotesManager


class TestNotesManager(unittest.TestCase):
    """Test NotesManager functionality."""

    def setUp(self):
        """Create a temporary file for testing."""
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.json')
        self.temp_file.close()
        self.manager = NotesManager(self.temp_file.name)

    def tearDown(self):
        """Clean up temporary files."""
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)

    def test_create_note(self):
        """Test creating a note."""
        result = self.manager.create("Test Note", "This is a test")
        self.assertIn("Created", result)
        self.assertEqual(len(self.manager.notes), 1)
        self.assertEqual(self.manager.notes[0]["title"], "Test Note")

    def test_create_with_tags(self):
        """Test creating a note with tags."""
        tags = ["python", "learning"]
        result = self.manager.create("Learn Python", "Study guide", tags)
        self.assertIn("Created", result)
        self.assertEqual(self.manager.notes[0]["tags"], tags)

    def test_create_empty_title_fails(self):
        """Test that empty title fails."""
        result = self.manager.create("", "Content")
        self.assertIn("Error", result)

    def test_create_empty_content_fails(self):
        """Test that empty content fails."""
        result = self.manager.create("Title", "")
        self.assertIn("Error", result)

    def test_view_note(self):
        """Test viewing a note."""
        self.manager.create("My Note", "My Content")
        result = self.manager.view(1)
        self.assertIn("My Note", result)
        self.assertIn("My Content", result)

    def test_view_nonexistent_fails(self):
        """Test viewing non-existent note fails."""
        result = self.manager.view(999)
        self.assertIn("Error", result)

    def test_delete_note(self):
        """Test deleting a note."""
        self.manager.create("To Delete", "Content")
        result = self.manager.delete(1)
        self.assertIn("Deleted", result)
        self.assertEqual(len(self.manager.notes), 0)

    def test_delete_nonexistent_fails(self):
        """Test deleting non-existent note fails."""
        result = self.manager.delete(999)
        self.assertIn("Error", result)

    def test_pin_note(self):
        """Test pinning a note."""
        self.manager.create("Important", "Content")
        result = self.manager.pin(1)
        self.assertIn("pinned", result)
        self.assertTrue(self.manager.notes[0]["pinned"])

    def test_unpin_note(self):
        """Test unpinning a note."""
        self.manager.create("Note", "Content")
        self.manager.pin(1)
        result = self.manager.pin(1)
        self.assertIn("unpinned", result)
        self.assertFalse(self.manager.notes[0]["pinned"])

    def test_edit_note(self):
        """Test editing note content."""
        self.manager.create("Original", "Old content")
        result = self.manager.edit(1, "New content")
        self.assertIn("Updated", result)
        self.assertEqual(self.manager.notes[0]["content"], "New content")

    def test_tag_note(self):
        """Test updating note tags."""
        self.manager.create("Note", "Content", ["old"])
        result = self.manager.tag(1, ["new", "tags"])
        self.assertIn("Updated", result)
        self.assertEqual(self.manager.notes[0]["tags"], ["new", "tags"])

    def test_search_by_title(self):
        """Test searching by title."""
        self.manager.create("Python Tutorial", "Content")
        self.manager.create("JavaScript Guide", "Content")
        result = self.manager.search("Python")
        self.assertIn("Found 1", result)
        self.assertIn("Python Tutorial", result)

    def test_search_by_content(self):
        """Test searching by content."""
        self.manager.create("Note 1", "Contains keyword")
        self.manager.create("Note 2", "Different")
        result = self.manager.search("keyword")
        self.assertIn("Found 1", result)

    def test_search_no_results(self):
        """Test search with no results."""
        self.manager.create("Note", "Content")
        result = self.manager.search("nonexistent")
        self.assertIn("No notes found", result)

    def test_persistence(self):
        """Test that notes persist to disk."""
        self.manager.create("Persistent", "Content", ["tag1"])

        # Create new manager with same file
        manager2 = NotesManager(self.temp_file.name)
        self.assertEqual(len(manager2.notes), 1)
        self.assertEqual(manager2.notes[0]["title"], "Persistent")

    def test_stats(self):
        """Test stats generation."""
        self.manager.create("Note 1", "Content", ["tag1"])
        self.manager.create("Note 2", "Content", ["tag1", "tag2"])
        self.manager.pin(1)

        stats = self.manager.stats()
        self.assertIn("2 notes", stats)
        self.assertIn("1 pinned", stats)
        self.assertIn("2 tags", stats)

    def test_list_filter_by_tag(self):
        """Test listing notes filtered by tag."""
        self.manager.create("Python Note", "Content", ["python"])
        self.manager.create("JS Note", "Content", ["javascript"])

        result = self.manager.list_notes(tag_filter="python")
        self.assertIn("Python Note", result)
        self.assertNotIn("JS Note", result)


if __name__ == '__main__':
    unittest.main()
