#!/usr/bin/env python3
"""
NotesSync - A fast, elegant CLI note-taking tool with tagging and search.
Capture ideas from the terminal with automatic persistence.
"""

import json
import sys
from pathlib import Path
from datetime import datetime
from typing import List, Optional


class NotesManager:
    """Manages notes with tagging, timestamps, and persistence."""

    def __init__(self, filepath: str = ".notes.json"):
        self.filepath = Path(filepath)
        self.notes = self._load()

    def _load(self) -> List[dict]:
        """Load notes from disk."""
        if not self.filepath.exists():
            return []
        try:
            with open(self.filepath) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []

    def _save(self):
        """Persist notes to disk."""
        with open(self.filepath, 'w') as f:
            json.dump(self.notes, f, indent=2)

    def create(self, title: str, content: str, tags: Optional[List[str]] = None) -> str:
        """Create a new note."""
        if not title.strip():
            return "Error: Title cannot be empty"
        if not content.strip():
            return "Error: Content cannot be empty"

        tags = tags or []
        tags = [t.strip() for t in tags if t.strip()]

        note = {
            "id": len(self.notes) + 1,
            "title": title.strip(),
            "content": content.strip(),
            "tags": tags,
            "created": datetime.now().isoformat(),
            "modified": datetime.now().isoformat(),
            "pinned": False
        }
        self.notes.append(note)
        self._save()
        return f"✓ Created note #{note['id']}: {title}"

    def view(self, note_id: int) -> str:
        """View a specific note."""
        for note in self.notes:
            if note["id"] == note_id:
                tags_str = f" [{', '.join(note['tags'])}]" if note["tags"] else ""
                pin_str = "📌 " if note.get("pinned") else ""
                return f"""{pin_str}Note #{note["id"]}: {note["title"]}{tags_str}
─────────────────────────────────────
{note["content"]}
─────────────────────────────────────
Created: {note["created"]}
Modified: {note["modified"]}"""
        return f"Error: Note #{note_id} not found"

    def delete(self, note_id: int) -> str:
        """Delete a note."""
        for i, note in enumerate(self.notes):
            if note["id"] == note_id:
                title = note["title"]
                self.notes.pop(i)
                self._save()
                return f"✓ Deleted: {title}"
        return f"Error: Note #{note_id} not found"

    def pin(self, note_id: int) -> str:
        """Pin/unpin a note."""
        for note in self.notes:
            if note["id"] == note_id:
                note["pinned"] = not note.get("pinned", False)
                self._save()
                status = "pinned" if note["pinned"] else "unpinned"
                return f"✓ Note {status}: {note['title']}"
        return f"Error: Note #{note_id} not found"

    def edit(self, note_id: int, content: str) -> str:
        """Edit a note's content."""
        for note in self.notes:
            if note["id"] == note_id:
                note["content"] = content.strip()
                note["modified"] = datetime.now().isoformat()
                self._save()
                return f"✓ Updated note #{note_id}"
        return f"Error: Note #{note_id} not found"

    def tag(self, note_id: int, new_tags: List[str]) -> str:
        """Update note tags."""
        for note in self.notes:
            if note["id"] == note_id:
                note["tags"] = [t.strip() for t in new_tags if t.strip()]
                note["modified"] = datetime.now().isoformat()
                self._save()
                return f"✓ Updated tags for note #{note_id}"
        return f"Error: Note #{note_id} not found"

    def list_notes(self, tag_filter: Optional[str] = None) -> str:
        """List all notes, optionally filtered by tag."""
        if not self.notes:
            return "No notes yet! Use 'add' to create one."

        # Filter by tag if specified
        notes_to_show = self.notes
        if tag_filter:
            notes_to_show = [n for n in self.notes if tag_filter in n.get("tags", [])]
            if not notes_to_show:
                return f"No notes with tag '{tag_filter}'"

        # Sort: pinned first, then by creation date (newest first)
        notes_to_show.sort(
            key=lambda x: (-x.get("pinned", False), -datetime.fromisoformat(x["created"]).timestamp())
        )

        lines = ["┌─ NOTES ────────────────────────────────┐"]
        for note in notes_to_show:
            pin = "📌" if note.get("pinned") else "  "
            tags = f" #{' #'.join(note['tags'])}" if note["tags"] else ""
            preview = note["content"][:40].replace("\n", " ")
            if len(note["content"]) > 40:
                preview += "..."
            lines.append(f"│ {pin} #{note['id']:3d} | {note['title'][:25]:25s}{tags}")
        lines.append("└─────────────────────────────────────────┘")

        return "\n".join(lines)

    def search(self, query: str) -> str:
        """Search notes by title and content."""
        query_lower = query.lower()
        results = [
            n for n in self.notes
            if query_lower in n["title"].lower() or query_lower in n["content"].lower()
        ]

        if not results:
            return f"No notes found matching '{query}'"

        lines = [f"🔍 Found {len(results)} note(s) matching '{query}':"]
        for note in results:
            lines.append(f"  #{note['id']}: {note['title']}")

        return "\n".join(lines)

    def stats(self) -> str:
        """Show statistics."""
        total = len(self.notes)
        pinned = sum(1 for n in self.notes if n.get("pinned"))
        tags_set = set()
        for note in self.notes:
            tags_set.update(note.get("tags", []))

        return f"📊 Stats: {total} notes | {pinned} pinned | {len(tags_set)} tags"


def main():
    """CLI entry point."""
    manager = NotesManager()

    if len(sys.argv) < 2:
        print(manager.list_notes())
        print(f"\n{manager.stats()}")
        return

    cmd = sys.argv[1].lower()

    if cmd == "add" and len(sys.argv) > 2:
        title = sys.argv[2]
        # Parse content and tags
        content = " ".join(sys.argv[3:])
        tags = []

        # Extract tags (words starting with #)
        words = content.split()
        content_words = []
        for word in words:
            if word.startswith("#"):
                tags.append(word[1:])
            else:
                content_words.append(word)

        content = " ".join(content_words)
        print(manager.create(title, content if content else "[empty]", tags))

    elif cmd == "view" and len(sys.argv) > 2:
        try:
            note_id = int(sys.argv[2])
            print(manager.view(note_id))
        except ValueError:
            print(f"Error: Invalid note ID '{sys.argv[2]}'")

    elif cmd == "delete" and len(sys.argv) > 2:
        try:
            note_id = int(sys.argv[2])
            print(manager.delete(note_id))
        except ValueError:
            print(f"Error: Invalid note ID '{sys.argv[2]}'")

    elif cmd == "pin" and len(sys.argv) > 2:
        try:
            note_id = int(sys.argv[2])
            print(manager.pin(note_id))
        except ValueError:
            print(f"Error: Invalid note ID '{sys.argv[2]}'")

    elif cmd == "edit" and len(sys.argv) > 3:
        try:
            note_id = int(sys.argv[2])
            new_content = " ".join(sys.argv[3:])
            print(manager.edit(note_id, new_content))
        except ValueError:
            print(f"Error: Invalid note ID '{sys.argv[2]}'")

    elif cmd == "tag" and len(sys.argv) > 3:
        try:
            note_id = int(sys.argv[2])
            tags = sys.argv[3:]
            print(manager.tag(note_id, tags))
        except ValueError:
            print(f"Error: Invalid note ID '{sys.argv[2]}'")

    elif cmd == "search" and len(sys.argv) > 2:
        query = " ".join(sys.argv[2:])
        print(manager.search(query))

    elif cmd == "list":
        tag_filter = None
        if "--tag" in sys.argv:
            idx = sys.argv.index("--tag")
            if idx + 1 < len(sys.argv):
                tag_filter = sys.argv[idx + 1]
        print(manager.list_notes(tag_filter))
        print(f"\n{manager.stats()}")

    elif cmd == "stats":
        print(manager.stats())

    elif cmd == "help":
        print("""
NotesSync - Fast CLI Note Manager

Commands:
  add <title> <content> [#tags]  Create a new note (tags optional)
  view <id>                       View a specific note
  delete <id>                     Delete a note
  pin <id>                        Pin/unpin a note (for important ones)
  edit <id> <new_content>         Update note content
  tag <id> <tag1> <tag2> ...      Update note tags
  search <query>                  Search notes by title/content
  list                            List all notes (default)
  list --tag <tagname>            Filter by tag
  stats                           Show statistics
  help                            Show this help message

Examples:
  $ notes-cli add "Project Ideas" "Build a web framework #project #python"
  $ notes-cli list
  $ notes-cli view 1
  $ notes-cli search "web"
  $ notes-cli tag 1 python web framework
  $ notes-cli pin 1
        """)

    else:
        print(f"Unknown command: {cmd}")
        print("Use 'help' for usage information")


if __name__ == "__main__":
    main()
