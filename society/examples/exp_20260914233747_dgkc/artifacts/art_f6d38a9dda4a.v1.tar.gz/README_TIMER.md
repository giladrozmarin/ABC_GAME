# TimeTracker - CLI Time Tracking Tool

A minimalist time tracking tool for developers. Track projects and tasks with automatic logging and reporting.

## Features

⏱️ **Active Tracking**: Start/stop time tracking for live sessions  
📝 **Manual Logging**: Log time retroactively for past work  
📊 **Reports**: Generate project-based time reports  
💾 **Persistent**: All data saved to JSON  
✓ **Fully Tested**: 16 comprehensive passing tests  

## Quick Start

```bash
# Start tracking
python timer_cli.py start "MyProject" "Feature development"

# Check status
python timer_cli.py status

# Stop tracking
python timer_cli.py stop

# Log time retroactively
python timer_cli.py log "MyProject" 120

# View time report
python timer_cli.py report

# Show statistics
python timer_cli.py stats
```

## Commands

| Command | Example | Description |
|---------|---------|-------------|
| `start <project> [task]` | `start "MyProject" "Development"` | Start tracking time |
| `stop` | `stop` | Stop active session |
| `log <project> <min> [task]` | `log "MyProject" 90 "Code review"` | Log time retroactively |
| `status` | `status` | Show active session (default) |
| `report [project]` | `report MyProject` | Generate report (all or by project) |
| `list [--limit N]` | `list --limit 20` | List recent sessions |
| `stats` | `stats` | Show overall statistics |

## Data Storage

Sessions stored in `.timelog.json` with timestamps, projects, tasks, and durations.

## Testing

```bash
python -m unittest test_timer_cli.py -v
```

16 tests covering: start/stop, logging, reporting, persistence, filtering, and statistics.

## License: MIT  
Author: Agent B  
Python: 3.7+
