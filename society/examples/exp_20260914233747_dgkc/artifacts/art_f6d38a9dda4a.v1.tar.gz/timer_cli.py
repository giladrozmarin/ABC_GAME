#!/usr/bin/env python3
"""
TimeTracker - A minimalist CLI time tracking tool for developers.
Track projects and tasks with automatic logging.
"""

import json
import sys
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Optional


class TimeTracker:
    """Track time spent on projects and tasks."""

    def __init__(self, filepath: str = ".timelog.json"):
        self.filepath = Path(filepath)
        self.sessions = self._load()
        self.active_session = None

    def _load(self) -> List[dict]:
        """Load time sessions from disk."""
        if not self.filepath.exists():
            return []
        try:
            with open(self.filepath) as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return []

    def _save(self):
        """Persist sessions to disk."""
        with open(self.filepath, 'w') as f:
            json.dump(self.sessions, f, indent=2)

    def start(self, project: str, task: str = "") -> str:
        """Start tracking time for a project."""
        if not project.strip():
            return "Error: Project name required"

        self.active_session = {
            "id": len(self.sessions) + 1,
            "project": project.strip(),
            "task": task.strip(),
            "started": datetime.now().isoformat(),
            "ended": None,
            "duration_seconds": 0
        }
        return f"⏱️  Started tracking: {project}" + (f" - {task}" if task else "")

    def stop(self) -> str:
        """Stop the active tracking session."""
        if not self.active_session:
            return "Error: No active session"

        self.active_session["ended"] = datetime.now().isoformat()
        start = datetime.fromisoformat(self.active_session["started"])
        end = datetime.fromisoformat(self.active_session["ended"])
        duration = (end - start).total_seconds()

        self.active_session["duration_seconds"] = duration
        self.sessions.append(self.active_session)
        self._save()

        hours = int(duration // 3600)
        minutes = int((duration % 3600) // 60)
        seconds = int(duration % 60)

        duration_str = f"{hours}h {minutes}m {seconds}s" if hours else f"{minutes}m {seconds}s"
        result = f"✓ Stopped: {self.active_session['project']} ({duration_str})"
        self.active_session = None
        return result

    def log(self, project: str, duration_minutes: int, task: str = "") -> str:
        """Log time spent retroactively."""
        if not project.strip():
            return "Error: Project name required"
        if duration_minutes <= 0:
            return "Error: Duration must be positive"

        start = datetime.now() - timedelta(minutes=duration_minutes)

        session = {
            "id": len(self.sessions) + 1,
            "project": project.strip(),
            "task": task.strip(),
            "started": start.isoformat(),
            "ended": datetime.now().isoformat(),
            "duration_seconds": duration_minutes * 60
        }
        self.sessions.append(session)
        self._save()

        return f"✓ Logged {duration_minutes}m for {project}"

    def status(self) -> str:
        """Show active session status."""
        if not self.active_session:
            return "No active session"

        start = datetime.fromisoformat(self.active_session["started"])
        elapsed = (datetime.now() - start).total_seconds()

        hours = int(elapsed // 3600)
        minutes = int((elapsed % 3600) // 60)
        seconds = int(elapsed % 60)

        duration_str = f"{hours}h {minutes}m {seconds}s" if hours else f"{minutes}m {seconds}s"
        task_str = f" - {self.active_session['task']}" if self.active_session['task'] else ""

        return f"⏱️  Active: {self.active_session['project']}{task_str} ({duration_str})"

    def report(self, project_filter: Optional[str] = None) -> str:
        """Generate time report."""
        if not self.sessions:
            return "No time logged yet"

        # Filter by project if specified
        sessions = self.sessions
        if project_filter:
            sessions = [s for s in sessions if project_filter.lower() in s["project"].lower()]

        if not sessions:
            return f"No sessions found for '{project_filter}'"

        # Group by project
        by_project = {}
        for session in sessions:
            proj = session["project"]
            if proj not in by_project:
                by_project[proj] = []
            by_project[proj].append(session)

        lines = ["📊 TIME REPORT"]
        lines.append("=" * 40)

        total_seconds = 0
        for proj in sorted(by_project.keys()):
            proj_sessions = by_project[proj]
            proj_seconds = sum(s["duration_seconds"] for s in proj_sessions)
            total_seconds += proj_seconds

            hours = int(proj_seconds // 3600)
            minutes = int((proj_seconds % 3600) // 60)

            duration_str = f"{hours}h {minutes}m" if hours else f"{minutes}m"
            lines.append(f"{proj:25s} | {duration_str:>8s} | {len(proj_sessions)} session(s)")

        lines.append("=" * 40)
        total_hours = int(total_seconds // 3600)
        total_minutes = int((total_seconds % 3600) // 60)
        total_str = f"{total_hours}h {total_minutes}m" if total_hours else f"{total_minutes}m"
        lines.append(f"{'TOTAL':25s} | {total_str:>8s}")

        return "\n".join(lines)

    def list_sessions(self, limit: int = 10) -> str:
        """List recent sessions."""
        if not self.sessions:
            return "No sessions logged"

        recent = sorted(self.sessions, key=lambda x: x["started"], reverse=True)[:limit]

        lines = [f"Recent sessions (last {limit}):"]
        for session in recent:
            start = datetime.fromisoformat(session["started"])
            hours = int(session["duration_seconds"] // 3600)
            minutes = int((session["duration_seconds"] % 3600) // 60)
            duration = f"{hours}h {minutes}m" if hours else f"{minutes}m"

            task_str = f" - {session['task']}" if session.get('task') else ""
            lines.append(f"  [{start.strftime('%Y-%m-%d %H:%M')}] {session['project']}{task_str} ({duration})")

        return "\n".join(lines)

    def stats(self) -> str:
        """Show overall statistics."""
        if not self.sessions:
            return "No sessions logged"

        total_seconds = sum(s["duration_seconds"] for s in self.sessions)
        total_hours = total_seconds / 3600
        avg_session = total_seconds / len(self.sessions)
        avg_minutes = int(avg_session / 60)

        total_h = int(total_seconds // 3600)
        total_m = int((total_seconds % 3600) // 60)

        projects = len(set(s["project"] for s in self.sessions))

        return f"📈 Total: {total_h}h {total_m}m | Sessions: {len(self.sessions)} | Avg: {avg_minutes}m | Projects: {projects}"


def main():
    """CLI entry point."""
    tracker = TimeTracker()

    if len(sys.argv) < 2:
        print(tracker.status())
        if tracker.sessions:
            print(f"\n{tracker.stats()}")
        return

    cmd = sys.argv[1].lower()

    if cmd == "start" and len(sys.argv) > 2:
        project = sys.argv[2]
        task = " ".join(sys.argv[3:]) if len(sys.argv) > 3 else ""
        print(tracker.start(project, task))

    elif cmd == "stop":
        print(tracker.stop())

    elif cmd == "log" and len(sys.argv) > 3:
        project = sys.argv[2]
        try:
            minutes = int(sys.argv[3])
            task = " ".join(sys.argv[4:]) if len(sys.argv) > 4 else ""
            print(tracker.log(project, minutes, task))
        except ValueError:
            print(f"Error: '{sys.argv[3]}' is not a valid duration")

    elif cmd == "status":
        print(tracker.status())

    elif cmd == "report":
        project = sys.argv[2] if len(sys.argv) > 2 else None
        print(tracker.report(project))

    elif cmd == "list":
        limit = 10
        if "--limit" in sys.argv:
            idx = sys.argv.index("--limit")
            if idx + 1 < len(sys.argv):
                try:
                    limit = int(sys.argv[idx + 1])
                except ValueError:
                    pass
        print(tracker.list_sessions(limit))

    elif cmd == "stats":
        print(tracker.stats())

    elif cmd == "help":
        print("""
TimeTracker - CLI Time Tracking Tool

Commands:
  start <project> [task]           Start tracking time
  stop                             Stop active session
  log <project> <minutes> [task]   Log time retroactively
  status                           Show active session (default)
  report [project]                 Generate time report (all or by project)
  list [--limit N]                 List recent sessions
  stats                            Show statistics
  help                             Show this help

Examples:
  $ timer start "MyProject" "Feature development"
  $ timer status
  $ timer stop
  $ timer log "MyProject" 120 "Code review"
  $ timer report
  $ timer report MyProject
  $ timer list --limit 20
        """)

    else:
        print(f"Unknown command: {cmd}")
        print("Use 'help' for usage information")


if __name__ == "__main__":
    main()
