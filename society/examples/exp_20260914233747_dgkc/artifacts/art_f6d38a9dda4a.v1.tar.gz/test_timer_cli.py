#!/usr/bin/env python3
"""Tests for TimeTracker CLI."""

import unittest
import tempfile
import os
from datetime import datetime, timedelta
from timer_cli import TimeTracker


class TestTimeTracker(unittest.TestCase):
    """Test TimeTracker functionality."""

    def setUp(self):
        """Create a temporary file for testing."""
        self.temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.json')
        self.temp_file.close()
        self.tracker = TimeTracker(self.temp_file.name)

    def tearDown(self):
        """Clean up temporary files."""
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)

    def test_start_session(self):
        """Test starting a tracking session."""
        result = self.tracker.start("MyProject", "Task 1")
        self.assertIn("Started", result)
        self.assertIsNotNone(self.tracker.active_session)
        self.assertEqual(self.tracker.active_session["project"], "MyProject")

    def test_start_without_task(self):
        """Test starting session without task."""
        result = self.tracker.start("MyProject")
        self.assertIn("Started", result)
        self.assertEqual(self.tracker.active_session["task"], "")

    def test_start_empty_project_fails(self):
        """Test that empty project fails."""
        result = self.tracker.start("")
        self.assertIn("Error", result)

    def test_stop_session(self):
        """Test stopping a session."""
        self.tracker.start("MyProject")
        result = self.tracker.stop()
        self.assertIn("Stopped", result)
        self.assertEqual(len(self.tracker.sessions), 1)
        self.assertIsNone(self.tracker.active_session)

    def test_stop_without_active_fails(self):
        """Test stopping without active session fails."""
        result = self.tracker.stop()
        self.assertIn("Error", result)

    def test_log_time(self):
        """Test logging time retroactively."""
        result = self.tracker.log("MyProject", 60, "Code review")
        self.assertIn("Logged", result)
        self.assertEqual(len(self.tracker.sessions), 1)
        self.assertEqual(self.tracker.sessions[0]["duration_seconds"], 3600)

    def test_log_invalid_duration_fails(self):
        """Test that invalid duration fails."""
        result = self.tracker.log("MyProject", -10)
        self.assertIn("Error", result)

    def test_status_no_active(self):
        """Test status with no active session."""
        result = self.tracker.status()
        self.assertIn("No active", result)

    def test_status_active(self):
        """Test status with active session."""
        self.tracker.start("MyProject", "Task")
        result = self.tracker.status()
        self.assertIn("Active", result)
        self.assertIn("MyProject", result)

    def test_report_empty(self):
        """Test report with no sessions."""
        result = self.tracker.report()
        self.assertIn("No time logged", result)

    def test_report_summary(self):
        """Test report generation."""
        self.tracker.log("ProjectA", 60)
        self.tracker.log("ProjectB", 30)
        result = self.tracker.report()
        self.assertIn("ProjectA", result)
        self.assertIn("ProjectB", result)
        self.assertIn("TOTAL", result)

    def test_report_filter_by_project(self):
        """Test filtering report by project."""
        self.tracker.log("ProjectA", 60)
        self.tracker.log("ProjectB", 30)
        result = self.tracker.report("ProjectA")
        self.assertIn("ProjectA", result)
        self.assertNotIn("ProjectB", result)

    def test_persistence(self):
        """Test persistence to disk."""
        self.tracker.log("MyProject", 45)

        # Create new tracker with same file
        tracker2 = TimeTracker(self.temp_file.name)
        self.assertEqual(len(tracker2.sessions), 1)
        self.assertEqual(tracker2.sessions[0]["project"], "MyProject")

    def test_stats(self):
        """Test statistics generation."""
        self.tracker.log("ProjectA", 60)
        self.tracker.log("ProjectA", 30)
        self.tracker.log("ProjectB", 90)

        stats = self.tracker.stats()
        self.assertIn("Total", stats)
        self.assertIn("3", stats)  # 3 sessions
        self.assertIn("2", stats)  # 2 projects

    def test_list_sessions(self):
        """Test listing sessions."""
        self.tracker.log("ProjectA", 30)
        self.tracker.log("ProjectB", 60)
        result = self.tracker.list_sessions()
        self.assertIn("ProjectA", result)
        self.assertIn("ProjectB", result)

    def test_duration_calculation(self):
        """Test that duration is correctly calculated."""
        self.tracker.start("Test")
        # Manually set start time to 1 hour ago
        self.tracker.active_session["started"] = (datetime.now() - timedelta(hours=1)).isoformat()
        self.tracker.stop()

        self.assertGreaterEqual(self.tracker.sessions[0]["duration_seconds"], 3600)


if __name__ == '__main__':
    unittest.main()
