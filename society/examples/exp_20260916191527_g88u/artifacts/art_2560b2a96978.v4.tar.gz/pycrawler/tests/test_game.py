from pycrawler.game import Game
from pycrawler.bot import run_autoplay, choose_action


def test_game_initializes_with_player_on_floor():
    g = Game(seed=123, max_depth=2)
    assert g.level.dungeon.is_walkable(g.player.x, g.player.y)
    assert g.player.hp == g.player.max_hp
    assert not g.game_over


def test_player_bump_into_wall_is_safe():
    g = Game(seed=5, max_depth=1)
    # try every direction; none should crash and player should stay in bounds
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        g.try_move_player(dx, dy)
    assert 0 <= g.player.x < 60
    assert 0 <= g.player.y < 24


def test_autoplay_terminates_and_makes_progress():
    g = Game(seed=99, max_depth=2)
    run_autoplay(g, max_turns=1500)
    assert g.player.turns > 0
    # game should have ended (victory or defeat) or at least made real progress
    assert g.game_over or g.player.depth >= 1


def test_autoplay_can_reach_victory_on_easy_seed():
    found_victory = False
    for seed in range(10):
        g = Game(seed=seed, max_depth=2)
        run_autoplay(g, max_turns=3000)
        if g.victory:
            found_victory = True
            break
    assert found_victory, "bot never won across 10 seeds on a 2-level dungeon"


def test_choose_action_returns_valid_direction():
    g = Game(seed=3, max_depth=1)
    dx, dy = choose_action(g)
    assert (dx, dy) in {(0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)}


def test_save_produces_json(tmp_path):
    g = Game(seed=1, max_depth=1)
    path = tmp_path / "save.json"
    g.save(str(path))
    assert path.exists()
    assert path.stat().st_size > 0
