from pycrawler.dungeon import generate_dungeon, flood_fill_reachable, all_floor_tiles


def test_generated_dungeon_has_floor_tiles():
    d = generate_dungeon(60, 24, seed=1)
    floors = all_floor_tiles(d)
    assert len(floors) > 50


def test_dungeon_is_fully_connected_for_many_seeds():
    for seed in range(25):
        d = generate_dungeon(60, 24, seed=seed)
        floors = all_floor_tiles(d)
        assert floors, f"no floor tiles for seed {seed}"
        start = next(iter(floors))
        reachable = flood_fill_reachable(d, start)
        assert reachable == floors, f"dungeon not fully connected for seed {seed}"


def test_dungeon_bounded_by_walls():
    d = generate_dungeon(40, 20, seed=7)
    for x in range(d.width):
        assert d.tiles[0][x] == "#"
        assert d.tiles[d.height - 1][x] == "#"
    for y in range(d.height):
        assert d.tiles[y][0] == "#"
        assert d.tiles[y][d.width - 1] == "#"


def test_deterministic_with_same_seed():
    d1 = generate_dungeon(50, 22, seed=42)
    d2 = generate_dungeon(50, 22, seed=42)
    assert d1.render_rows() == d2.render_rows()


def test_different_seeds_produce_different_layouts():
    d1 = generate_dungeon(50, 22, seed=1)
    d2 = generate_dungeon(50, 22, seed=2)
    assert d1.render_rows() != d2.render_rows()
