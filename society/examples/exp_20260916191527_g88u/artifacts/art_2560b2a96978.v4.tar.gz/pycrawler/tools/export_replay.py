#!/usr/bin/env python3
"""Run a full autoplayed game and export it as a single self-contained HTML
file with an embedded frame-by-frame replay viewer (play/pause/step/speed,
no server, no build step, no network access needed -- open it directly in a
browser).

Usage:
    python3 tools/export_replay.py --seed 3 --depth 3 --out replay.html
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pycrawler.game import Game
from pycrawler.bot import choose_action
from pycrawler.render import render_frame, render_log


TEMPLATE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>PyCrawler Replay - seed {seed}</title>
<style>
  body {{ background:#0b0d10; color:#d7dee3; font-family: "SF Mono", Menlo, Consolas, monospace; display:flex; flex-direction:column; align-items:center; padding:24px; }}
  h1 {{ font-size:16px; font-weight:600; color:#8fd3ff; margin:0 0 4px; }}
  #meta {{ color:#7a8790; font-size:12px; margin-bottom:14px; }}
  #screen {{ background:#111418; border:1px solid #262b31; border-radius:8px; padding:16px 20px; white-space:pre; line-height:1.28; font-size:15px; letter-spacing:1px; min-width:620px; }}
  .wall {{ color:#4c5560; }}
  .floor {{ color:#2c333b; }}
  .player {{ color:#ffe066; font-weight:bold; }}
  .monster {{ color:#ff6b6b; font-weight:bold; }}
  .item {{ color:#6bffb8; font-weight:bold; }}
  .stairs {{ color:#8fd3ff; font-weight:bold; }}
  #log {{ margin-top:10px; color:#9fe0a0; font-size:13px; min-height:70px; white-space:pre-wrap; }}
  #status {{ margin-top:8px; color:#e7c76f; font-size:13px; }}
  #controls {{ margin-top:16px; display:flex; gap:10px; align-items:center; }}
  button {{ background:#1c2126; color:#d7dee3; border:1px solid #333c44; border-radius:6px; padding:8px 14px; font-family:inherit; cursor:pointer; font-size:13px; }}
  button:hover {{ background:#262d34; }}
  input[type=range] {{ width:280px; }}
  #frameLabel {{ font-size:12px; color:#7a8790; min-width:90px; text-align:center; }}
  #result {{ margin-top:10px; font-size:14px; font-weight:700; }}
</style>
</head>
<body>
  <h1>PyCrawler &mdash; autoplay replay</h1>
  <div id="meta">seed={seed} &middot; depth goal={depth} &middot; {n_frames} frames &middot; result: {result}</div>
  <div id="screen"></div>
  <div id="status"></div>
  <div id="log"></div>
  <div id="controls">
    <button id="playBtn">Play</button>
    <button id="stepBack">&laquo; Step</button>
    <button id="stepFwd">Step &raquo;</button>
    <input id="scrub" type="range" min="0" max="{max_idx}" value="0">
    <span id="frameLabel">frame 0 / {max_idx}</span>
    <select id="speed">
      <option value="240">Slow</option>
      <option value="90" selected>Normal</option>
      <option value="30">Fast</option>
    </select>
  </div>
  <div id="result"></div>

<script>
const FRAMES = {frames_json};
const RESULT = {result_json};

const screenEl = document.getElementById('screen');
const statusEl = document.getElementById('status');
const logEl = document.getElementById('log');
const scrub = document.getElementById('scrub');
const frameLabel = document.getElementById('frameLabel');
const playBtn = document.getElementById('playBtn');
const speedSel = document.getElementById('speed');
const resultEl = document.getElementById('result');

let idx = 0;
let playing = false;
let timer = null;

function colorize(line) {{
  let out = '';
  for (const ch of line) {{
    if (ch === '#') out += '<span class="wall">#</span>';
    else if (ch === '.') out += '<span class="floor">.</span>';
    else if (ch === '@') out += '<span class="player">@</span>';
    else if (ch === '>' || ch === '<') out += '<span class="stairs">' + ch + '</span>';
    else if (ch === '!' || ch === '/' || ch === '?') out += '<span class="item">' + ch + '</span>';
    else if (/[a-zA-Z]/.test(ch)) out += '<span class="monster">' + ch + '</span>';
    else out += ch === ' ' ? '&nbsp;' : ch;
  }}
  return out;
}}

function render() {{
  const f = FRAMES[idx];
  const lines = f.grid;
  screenEl.innerHTML = lines.map(colorize).join('\\n');
  statusEl.textContent = f.status;
  logEl.textContent = f.log.join('\\n');
  scrub.value = idx;
  frameLabel.textContent = `frame ${{idx}} / ${{FRAMES.length - 1}}`;
  if (idx === FRAMES.length - 1) {{
    resultEl.textContent = RESULT;
  }} else {{
    resultEl.textContent = '';
  }}
}}

function step(delta) {{
  idx = Math.max(0, Math.min(FRAMES.length - 1, idx + delta));
  render();
  if (idx === FRAMES.length - 1) pause();
}}

function play() {{
  playing = true;
  playBtn.textContent = 'Pause';
  const tick = () => {{
    if (!playing) return;
    if (idx >= FRAMES.length - 1) {{ pause(); return; }}
    step(1);
    timer = setTimeout(tick, parseInt(speedSel.value, 10));
  }};
  tick();
}}

function pause() {{
  playing = false;
  playBtn.textContent = 'Play';
  if (timer) clearTimeout(timer);
}}

playBtn.addEventListener('click', () => playing ? pause() : play());
document.getElementById('stepFwd').addEventListener('click', () => {{ pause(); step(1); }});
document.getElementById('stepBack').addEventListener('click', () => {{ pause(); step(-1); }});
scrub.addEventListener('input', () => {{ pause(); idx = parseInt(scrub.value, 10); render(); }});

render();
</script>
</body>
</html>
"""


def export(seed: int, depth: int, max_turns: int, out_path: str) -> None:
    game = Game(seed=seed, max_depth=depth)
    frames = []

    def snapshot():
        lines = render_frame(game).splitlines()
        frames.append({
            "grid": lines[:-1],
            "status": lines[-1],
            "log": game.log[-4:],
        })

    snapshot()
    while not game.game_over and game.player.turns < max_turns:
        if game.player.hp < game.player.max_hp * 0.5 and any(
            i.kind == "potion" for i in game.player.inventory
        ):
            game.use_inventory()
        dx, dy = choose_action(game)
        if (dx, dy) == (0, 0):
            break
        game.try_move_player(dx, dy)
        snapshot()

    result = "VICTORY!" if game.victory else ("DEFEAT" if game.game_over else "STOPPED (turn limit)")
    result += f" -- depth {game.player.depth}/{depth}, {game.player.kills} kills, {game.player.turns} turns, seed={game.seed}"

    html = TEMPLATE.format(
        seed=game.seed,
        depth=depth,
        n_frames=len(frames),
        max_idx=len(frames) - 1,
        frames_json=json.dumps(frames),
        result_json=json.dumps(result),
        result=result,
    )
    with open(out_path, "w") as f:
        f.write(html)
    print(f"Wrote {out_path} ({len(frames)} frames). Result: {result}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=3)
    parser.add_argument("--depth", type=int, default=3)
    parser.add_argument("--turns", type=int, default=3000)
    parser.add_argument("--out", type=str, default="replay.html")
    args = parser.parse_args()
    export(args.seed, args.depth, args.turns, args.out)


if __name__ == "__main__":
    main()
