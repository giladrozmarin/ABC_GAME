"""Entities: Player, Monster and Item definitions."""
from __future__ import annotations

import random
from dataclasses import dataclass, field


@dataclass
class Item:
    name: str
    kind: str  # "potion", "weapon", "scroll"
    power: int
    glyph: str = "!"

    def describe(self) -> str:
        return f"{self.name} ({self.kind}, power {self.power})"


@dataclass
class Actor:
    x: int
    y: int
    hp: int
    max_hp: int
    atk: int
    name: str
    glyph: str

    @property
    def alive(self) -> bool:
        return self.hp > 0

    def attack(self, other: "Actor", rng: random.Random) -> int:
        variance = rng.randint(-1, 2)
        dmg = max(1, self.atk + variance)
        other.hp -= dmg
        return dmg


@dataclass
class Player(Actor):
    level: int = 1
    inventory: list[Item] = field(default_factory=list)
    kills: int = 0
    turns: int = 0
    depth: int = 1

    def apply_item(self, item: Item) -> str:
        if item.kind == "potion":
            healed = min(item.power, self.max_hp - self.hp)
            self.hp += healed
            return f"You drink the {item.name} and heal {healed} HP."
        if item.kind == "weapon":
            self.atk += item.power
            return f"You wield the {item.name}. Attack +{item.power}!"
        if item.kind == "scroll":
            self.max_hp += item.power
            self.hp += item.power
            return f"You read the {item.name}. Max HP +{item.power}!"
        return "Nothing happens."


MONSTER_TEMPLATES = [
    dict(name="Rat", glyph="r", hp=5, atk=2, xp=2),
    dict(name="Goblin", glyph="g", hp=9, atk=3, xp=4),
    dict(name="Skeleton", glyph="s", hp=13, atk=4, xp=6),
    dict(name="Orc", glyph="o", hp=18, atk=6, xp=9),
    dict(name="Troll", glyph="T", hp=28, atk=8, xp=15),
]

ITEM_TEMPLATES = [
    dict(name="Minor Potion", kind="potion", power=8, glyph="!"),
    dict(name="Greater Potion", kind="potion", power=16, glyph="!"),
    dict(name="Rusty Dagger", kind="weapon", power=2, glyph="/"),
    dict(name="Steel Sword", kind="weapon", power=4, glyph="/"),
    dict(name="War Axe", kind="weapon", power=6, glyph="/"),
    dict(name="Scroll of Vigor", kind="scroll", power=10, glyph="?"),
]


def make_monster(x: int, y: int, depth: int, rng: random.Random) -> Actor:
    idx = min(len(MONSTER_TEMPLATES) - 1, max(0, (depth - 1) + rng.randint(-1, 1)))
    tpl = MONSTER_TEMPLATES[idx]
    scale = 1 + (depth - 1) * 0.15
    hp = int(tpl["hp"] * scale)
    atk = int(tpl["atk"] * scale)
    m = Actor(x=x, y=y, hp=hp, max_hp=hp, atk=atk, name=tpl["name"], glyph=tpl["glyph"])
    m.xp = tpl["xp"]  # type: ignore[attr-defined]
    return m


def make_item(rng: random.Random) -> Item:
    tpl = rng.choice(ITEM_TEMPLATES)
    return Item(**tpl)
