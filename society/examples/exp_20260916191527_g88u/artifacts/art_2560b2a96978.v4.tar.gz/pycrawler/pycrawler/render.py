"""Plain-text rendering shared by the curses UI and the headless demo mode."""
from __future__ import annotations

from .dungeon import WALL, FLOOR
from .game import Game, WIDTH, HEIGHT


def render_frame(game: Game, visible: set[tuple[int, int]] | None = None) -> str:
    level = game.level
    if visible is None:
        visible = game.visible_now()
    grid = []
    for y in range(HEIGHT):
        row = []
        for x in range(WIDTH):
            if (x, y) not in level.visited:
                row.append(" ")
                continue
            ch = level.dungeon.tiles[y][x]
            if (x, y) == level.stairs_down:
                ch = ">"
            elif (x, y) == level.stairs_up:
                ch = "<"
            elif (x, y) in level.items and (x, y) in visible:
                ch = level.items[(x, y)].glyph
            if (x, y) not in visible and (x, y) in level.visited:
                # remembered but currently out of sight: dim representation
                ch = ch if ch in (WALL, FLOOR, ">", "<") else "."
            row.append(ch)
        grid.append(row)

    if (game.player.x, game.player.y) in visible or True:
        grid[game.player.y][game.player.x] = "@"

    for m in level.monsters:
        if m.alive and (m.x, m.y) in visible:
            grid[m.y][m.x] = m.glyph

    lines = ["".join(r) for r in grid]
    p = game.player
    status = (
        f"Depth {p.depth}/{game.max_depth}  HP {p.hp}/{p.max_hp}  ATK {p.atk}  "
        f"Kills {p.kills}  Items {len(p.inventory)}  Turn {p.turns}"
    )
    lines.append(status)
    return "\n".join(lines)


def render_log(game: Game, n: int = 4) -> str:
    return "\n".join(game.log[-n:])
