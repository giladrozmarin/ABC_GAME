"""PyCrawler - a procedurally generated ASCII roguelike dungeon crawler."""

__version__ = "1.0.0"
