"""Core turn-based game loop, independent of any rendering backend."""
from __future__ import annotations

import json
import random
from dataclasses import dataclass, field

from .dungeon import Dungeon, generate_dungeon, flood_fill_reachable, all_floor_tiles, FLOOR
from .entities import Actor, Item, Player, make_item, make_monster

WIDTH, HEIGHT = 60, 24
VIEW_RADIUS = 6


@dataclass
class Level:
    dungeon: Dungeon
    monsters: list[Actor]
    items: dict[tuple[int, int], Item]
    stairs_down: tuple[int, int]
    stairs_up: tuple[int, int]
    visited: set = field(default_factory=set)


class Game:
    def __init__(self, seed: int | None = None, max_depth: int = 5):
        self.rng = random.Random(seed)
        self.seed = seed if seed is not None else self.rng.randrange(1 << 30)
        self.rng = random.Random(self.seed)
        self.max_depth = max_depth
        self.levels: dict[int, Level] = {}
        self.log: list[str] = []
        self.game_over = False
        self.victory = False

        first = self._build_level(1)
        start = first.stairs_up
        self.player = Player(
            x=start[0], y=start[1], hp=30, max_hp=30, atk=5,
            name="Hero", glyph="@", depth=1,
        )
        self._reveal(first)
        self.message(f"Welcome, {self.player.name}! Seed={self.seed}. Find the stairs (>) and descend to depth {max_depth}.")

    # ------------------------------------------------------------------ #
    def message(self, text: str) -> None:
        self.log.append(text)
        if len(self.log) > 200:
            self.log = self.log[-200:]

    def _build_level(self, depth: int) -> Level:
        if depth in self.levels:
            return self.levels[depth]
        d = generate_dungeon(WIDTH, HEIGHT, seed=self.seed * 1000 + depth)
        floors = list(all_floor_tiles(d))
        self.rng.shuffle(floors)
        up = floors[0]
        down = floors[-1]
        n_monsters = 3 + depth
        n_items = 2 + depth // 2
        monsters = []
        used = {up, down}
        pool = [f for f in floors if f not in used]
        for i in range(min(n_monsters, len(pool))):
            mx, my = pool[i]
            monsters.append(make_monster(mx, my, depth, self.rng))
            used.add((mx, my))
        items: dict[tuple[int, int], Item] = {}
        remaining = [f for f in floors if f not in used]
        for i in range(min(n_items, len(remaining))):
            ix, iy = remaining[i]
            items[(ix, iy)] = make_item(self.rng)
        level = Level(dungeon=d, monsters=monsters, items=items, stairs_down=down, stairs_up=up)
        self.levels[depth] = level
        return level

    @property
    def level(self) -> Level:
        return self.levels[self.player.depth]

    def _reveal(self, level: Level) -> None:
        px, py = self.player.x, self.player.y
        for y in range(max(0, py - VIEW_RADIUS), min(HEIGHT, py + VIEW_RADIUS + 1)):
            for x in range(max(0, px - VIEW_RADIUS), min(WIDTH, px + VIEW_RADIUS + 1)):
                if (x - px) ** 2 + (y - py) ** 2 <= VIEW_RADIUS ** 2 and level.dungeon.is_walkable(x, y):
                    level.visited.add((x, y))

    def visible_now(self) -> set[tuple[int, int]]:
        level = self.level
        px, py = self.player.x, self.player.y
        out = set()
        for y in range(max(0, py - VIEW_RADIUS), min(HEIGHT, py + VIEW_RADIUS + 1)):
            for x in range(max(0, px - VIEW_RADIUS), min(WIDTH, px + VIEW_RADIUS + 1)):
                if (x - px) ** 2 + (y - py) ** 2 <= VIEW_RADIUS ** 2 and level.dungeon.is_walkable(x, y):
                    out.add((x, y))
        return out

    # ------------------------------------------------------------------ #
    def try_move_player(self, dx: int, dy: int) -> None:
        if self.game_over:
            return
        level = self.level
        nx, ny = self.player.x + dx, self.player.y + dy
        target = next((m for m in level.monsters if m.alive and m.x == nx and m.y == ny), None)
        if target is not None:
            dmg = self.player.attack(target, self.rng)
            self.message(f"You hit the {target.name} for {dmg}.")
            if not target.alive:
                self.message(f"The {target.name} dies!")
                self.player.kills += 1
        elif level.dungeon.is_walkable(nx, ny):
            self.player.x, self.player.y = nx, ny
            item = level.items.pop((nx, ny), None)
            if item is not None:
                self.player.inventory.append(item)
                self.message(f"You pick up a {item.name}.")
            if (nx, ny) == level.stairs_down:
                self._descend()
        else:
            self.message("You bump into a wall.")
        self._reveal(self.level)
        self._monster_turn()
        self.player.turns += 1

    def use_inventory(self) -> None:
        """Auto-consume the most useful item (used by demo AI / 'u' key)."""
        if not self.player.inventory:
            self.message("Inventory is empty.")
            return
        # prefer potion if hurt, else weapon/scroll
        item = None
        if self.player.hp < self.player.max_hp * 0.6:
            item = next((i for i in self.player.inventory if i.kind == "potion"), None)
        if item is None:
            item = self.player.inventory[0]
        self.player.inventory.remove(item)
        self.message(self.player.apply_item(item))

    def _descend(self) -> None:
        if self.player.depth >= self.max_depth:
            self.victory = True
            self.game_over = True
            self.message("You descend into the final chamber and claim the Heart of the Dungeon. VICTORY!")
            return
        self.player.depth += 1
        level = self._build_level(self.player.depth)
        self.player.x, self.player.y = level.stairs_up
        self.message(f"You descend to depth {self.player.depth}.")
        self._reveal(level)

    def _monster_turn(self) -> None:
        level = self.level
        for m in level.monsters:
            if not m.alive:
                continue
            dist2 = (m.x - self.player.x) ** 2 + (m.y - self.player.y) ** 2
            if dist2 <= VIEW_RADIUS ** 2:
                dx = (self.player.x > m.x) - (self.player.x < m.x)
                dy = (self.player.y > m.y) - (self.player.y < m.y)
                if dx != 0 and dy != 0:
                    if self.rng.random() < 0.5:
                        dy = 0
                    else:
                        dx = 0
                nx, ny = m.x + dx, m.y + dy
                if (nx, ny) == (self.player.x, self.player.y):
                    dmg = m.attack(self.player, self.rng)
                    self.message(f"The {m.name} hits you for {dmg}.")
                    if not self.player.alive:
                        self.game_over = True
                        self.message("You have died. Game over.")
                elif level.dungeon.is_walkable(nx, ny) and not any(
                    o is not m and o.alive and o.x == nx and o.y == ny for o in level.monsters
                ):
                    m.x, m.y = nx, ny

    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict:
        return {
            "seed": self.seed,
            "max_depth": self.max_depth,
            "player": {
                "x": self.player.x, "y": self.player.y, "hp": self.player.hp,
                "max_hp": self.player.max_hp, "atk": self.player.atk,
                "depth": self.player.depth, "kills": self.player.kills,
                "turns": self.player.turns,
                "inventory": [i.__dict__ for i in self.player.inventory],
            },
        }

    def save(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)
