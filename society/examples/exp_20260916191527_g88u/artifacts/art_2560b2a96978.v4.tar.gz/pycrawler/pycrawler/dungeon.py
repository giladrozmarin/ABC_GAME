"""Procedural dungeon generation using Binary Space Partitioning (BSP).

Pure, deterministic (given a seed) and side-effect free so it can be
unit tested without any rendering / terminal dependency.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

WALL = "#"
FLOOR = "."
STAIRS_DOWN = ">"
STAIRS_UP = "<"


@dataclass
class Rect:
    x1: int
    y1: int
    x2: int
    y2: int

    def center(self) -> tuple[int, int]:
        return ((self.x1 + self.x2) // 2, (self.y1 + self.y2) // 2)

    def intersects(self, other: "Rect") -> bool:
        return (
            self.x1 <= other.x2
            and self.x2 >= other.x1
            and self.y1 <= other.y2
            and self.y2 >= other.y1
        )


@dataclass
class Dungeon:
    width: int
    height: int
    tiles: list[list[str]] = field(default_factory=list)
    rooms: list[Rect] = field(default_factory=list)

    def in_bounds(self, x: int, y: int) -> bool:
        return 0 <= x < self.width and 0 <= y < self.height

    def is_walkable(self, x: int, y: int) -> bool:
        if not self.in_bounds(x, y):
            return False
        return self.tiles[y][x] != WALL

    def render_rows(self) -> list[str]:
        return ["".join(row) for row in self.tiles]


class BSPNode:
    def __init__(self, x1: int, y1: int, x2: int, y2: int):
        self.x1, self.y1, self.x2, self.y2 = x1, y1, x2, y2
        self.left: "BSPNode | None" = None
        self.right: "BSPNode | None" = None
        self.room: Rect | None = None

    @property
    def width(self) -> int:
        return self.x2 - self.x1

    @property
    def height(self) -> int:
        return self.y2 - self.y1

    def is_leaf(self) -> bool:
        return self.left is None and self.right is None

    def split(self, rng: random.Random, min_size: int) -> bool:
        if not self.is_leaf():
            return False
        split_horizontally = rng.random() < 0.5
        if self.width > self.height and self.width / max(self.height, 1) >= 1.25:
            split_horizontally = False
        elif self.height > self.width and self.height / max(self.width, 1) >= 1.25:
            split_horizontally = True

        max_size = (self.height if split_horizontally else self.width) - min_size
        if max_size <= min_size:
            return False

        split_pos = rng.randint(min_size, max_size)
        if split_horizontally:
            self.left = BSPNode(self.x1, self.y1, self.x2, self.y1 + split_pos)
            self.right = BSPNode(self.x1, self.y1 + split_pos, self.x2, self.y2)
        else:
            self.left = BSPNode(self.x1, self.y1, self.x1 + split_pos, self.y2)
            self.right = BSPNode(self.x1 + split_pos, self.y1, self.x2, self.y2)
        return True

    def all_leaves(self) -> list["BSPNode"]:
        if self.is_leaf():
            return [self]
        leaves = []
        if self.left:
            leaves.extend(self.left.all_leaves())
        if self.right:
            leaves.extend(self.right.all_leaves())
        return leaves


def _carve_room(tiles: list[list[str]], room: Rect) -> None:
    for y in range(room.y1, room.y2 + 1):
        for x in range(room.x1, room.x2 + 1):
            tiles[y][x] = FLOOR


def _carve_corridor(tiles: list[list[str]], x1: int, y1: int, x2: int, y2: int, rng: random.Random) -> None:
    if rng.random() < 0.5:
        _carve_h(tiles, x1, x2, y1)
        _carve_v(tiles, y1, y2, x2)
    else:
        _carve_v(tiles, y1, y2, x1)
        _carve_h(tiles, x1, x2, y2)


def _carve_h(tiles, x1, x2, y):
    for x in range(min(x1, x2), max(x1, x2) + 1):
        tiles[y][x] = FLOOR


def _carve_v(tiles, y1, y2, x):
    for y in range(min(y1, y2), max(y1, y2) + 1):
        tiles[y][x] = FLOOR


def generate_dungeon(width: int, height: int, seed: int | None = None,
                      min_leaf_size: int = 8, max_rooms_depth: int = 5) -> Dungeon:
    """Generate a connected dungeon using BSP partitioning.

    Guarantees: every carved room is reachable from every other room
    (corridors are carved along the BSP tree so siblings are always
    connected), which is verified by tests via flood fill.
    """
    rng = random.Random(seed)
    tiles = [[WALL for _ in range(width)] for _ in range(height)]

    root = BSPNode(1, 1, width - 2, height - 2)
    nodes = [root]
    for _ in range(max_rooms_depth):
        new_nodes = []
        for node in nodes:
            if node.width < min_leaf_size or node.height < min_leaf_size:
                new_nodes.append(node)
                continue
            if node.split(rng, min_leaf_size // 2):
                new_nodes.append(node.left)
                new_nodes.append(node.right)
            else:
                new_nodes.append(node)
        nodes = new_nodes

    rooms: list[Rect] = []

    def make_rooms(node: BSPNode):
        if node.is_leaf():
            w = max(3, node.width - rng.randint(2, max(2, min(4, node.width - 3))))
            h = max(3, node.height - rng.randint(2, max(2, min(4, node.height - 3))))
            w = min(w, node.width)
            h = min(h, node.height)
            x1 = node.x1 + rng.randint(0, max(0, node.width - w))
            y1 = node.y1 + rng.randint(0, max(0, node.height - h))
            room = Rect(x1, y1, min(x1 + w, width - 2), min(y1 + h, height - 2))
            node.room = room
            rooms.append(room)
            _carve_room(tiles, room)
        else:
            if node.left:
                make_rooms(node.left)
            if node.right:
                make_rooms(node.right)
            # connect the two children's representative rooms
            left_room = _first_room(node.left)
            right_room = _first_room(node.right)
            if left_room and right_room:
                cx1, cy1 = left_room.center()
                cx2, cy2 = right_room.center()
                _carve_corridor(tiles, cx1, cy1, cx2, cy2, rng)

    def _first_room(node: "BSPNode | None") -> Rect | None:
        if node is None:
            return None
        if node.room:
            return node.room
        return _first_room(node.left) or _first_room(node.right)

    make_rooms(root)

    dungeon = Dungeon(width=width, height=height, tiles=tiles, rooms=rooms)
    return dungeon


def flood_fill_reachable(dungeon: Dungeon, start: tuple[int, int]) -> set[tuple[int, int]]:
    """Return the set of floor tiles reachable from `start`."""
    seen = {start}
    stack = [start]
    while stack:
        x, y = stack.pop()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if (nx, ny) in seen:
                continue
            if dungeon.is_walkable(nx, ny):
                seen.add((nx, ny))
                stack.append((nx, ny))
    return seen


def all_floor_tiles(dungeon: Dungeon) -> set[tuple[int, int]]:
    return {
        (x, y)
        for y in range(dungeon.height)
        for x in range(dungeon.width)
        if dungeon.tiles[y][x] == FLOOR
    }
