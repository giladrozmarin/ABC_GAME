"""Command line entry point.

Two ways to experience PyCrawler:

  python -m pycrawler --demo          headless auto-play, prints frames to
                                       stdout -- works anywhere, no TTY needed
  python -m pycrawler --play          interactive curses UI (arrow keys/WASD,
                                       'u' to use an item, 'q' to quit)
"""
from __future__ import annotations

import argparse
import sys
import time

from .game import Game
from .render import render_frame, render_log
from .bot import choose_action


def run_demo(seed: int | None, max_depth: int, max_turns: int, delay: float) -> None:
    game = Game(seed=seed, max_depth=max_depth)
    frame = 0
    while not game.game_over and game.player.turns < max_turns:
        if delay:
            print("\033[2J\033[H", end="")
        print(render_frame(game))
        print("-" * 60)
        print(render_log(game))
        print("=" * 60)
        if game.player.hp < game.player.max_hp * 0.5 and any(
            i.kind == "potion" for i in game.player.inventory
        ):
            game.use_inventory()
        dx, dy = choose_action(game)
        if (dx, dy) == (0, 0):
            break
        game.try_move_player(dx, dy)
        frame += 1
        if delay:
            time.sleep(delay)

    print(render_frame(game))
    print("-" * 60)
    print(render_log(game))
    print("=" * 60)
    result = "VICTORY!" if game.victory else ("DEFEAT" if game.game_over else "STOPPED (turn limit)")
    print(f"\n{result}  -- reached depth {game.player.depth}/{max_depth}, "
          f"{game.player.kills} kills, {game.player.turns} turns, seed={game.seed}")


def run_interactive(seed: int | None, max_depth: int) -> None:
    import curses

    def _main(stdscr):
        curses.curs_set(0)
        game = Game(seed=seed, max_depth=max_depth)
        key_map = {
            curses.KEY_UP: (0, -1), ord("w"): (0, -1), ord("k"): (0, -1),
            curses.KEY_DOWN: (0, 1), ord("s"): (0, 1), ord("j"): (0, 1),
            curses.KEY_LEFT: (-1, 0), ord("a"): (-1, 0), ord("h"): (-1, 0),
            curses.KEY_RIGHT: (1, 0), ord("d"): (1, 0), ord("l"): (1, 0),
        }
        while True:
            stdscr.erase()
            text = render_frame(game) + "\n" + ("-" * 60) + "\n" + render_log(game)
            text += "\n\nmove: WASD/arrows  u: use item  q: quit"
            for i, line in enumerate(text.splitlines()):
                try:
                    stdscr.addstr(i, 0, line)
                except curses.error:
                    pass
            stdscr.refresh()
            if game.game_over:
                stdscr.addstr(0, 0, "GAME OVER - press any key to exit" if not game.victory else "VICTORY! press any key to exit")
                stdscr.getch()
                break
            ch = stdscr.getch()
            if ch == ord("q"):
                break
            if ch == ord("u"):
                game.use_inventory()
                continue
            if ch in key_map:
                dx, dy = key_map[ch]
                game.try_move_player(dx, dy)

    curses.wrapper(_main)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="pycrawler", description="Procedural ASCII roguelike dungeon crawler.")
    parser.add_argument("--play", action="store_true", help="interactive curses mode")
    parser.add_argument("--demo", action="store_true", help="headless auto-play demo (default)")
    parser.add_argument("--seed", type=int, default=None, help="dungeon seed for reproducible runs")
    parser.add_argument("--depth", type=int, default=5, help="number of dungeon levels")
    parser.add_argument("--turns", type=int, default=4000, help="max turns for demo mode")
    parser.add_argument("--delay", type=float, default=0.0, help="seconds between frames in demo mode (0 = no animation)")
    args = parser.parse_args(argv)

    if args.play:
        run_interactive(args.seed, args.depth)
    else:
        run_demo(args.seed, args.depth, args.turns, args.delay)
    return 0


if __name__ == "__main__":
    sys.exit(main())
