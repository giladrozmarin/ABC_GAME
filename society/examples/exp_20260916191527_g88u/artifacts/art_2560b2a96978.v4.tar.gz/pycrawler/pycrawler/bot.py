"""A simple autoplaying agent used for the headless demo mode and for
smoke-testing full playthroughs in CI without a TTY."""
from __future__ import annotations

from collections import deque

from .game import Game


def _bfs_step_towards(game: Game, target: tuple[int, int]) -> tuple[int, int] | None:
    """Return the (dx, dy) first step of a shortest path from the player to
    `target`, treating both floor tiles and the target itself as walkable."""
    level = game.level
    start = (game.player.x, game.player.y)
    if start == target:
        return None
    q = deque([start])
    came_from = {start: None}
    while q:
        cur = q.popleft()
        if cur == target:
            break
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nxt = (cur[0] + dx, cur[1] + dy)
            if nxt in came_from:
                continue
            if nxt != target and not level.dungeon.is_walkable(*nxt):
                continue
            came_from[nxt] = cur
            q.append(nxt)
    if target not in came_from:
        return None
    step = target
    while came_from[step] != start:
        step = came_from[step]
        if step is None:
            return None
    return (step[0] - start[0], step[1] - start[1])


def choose_action(game: Game) -> tuple[int, int]:
    """Very small heuristic bot: fight adjacent monsters, else go for
    nearby items, else head for a visible monster, else push toward the
    stairs down."""
    level = game.level
    p = game.player

    has_potion = any(i.kind == "potion" for i in p.inventory)
    critical = p.hp <= p.max_hp * 0.25 and not has_potion

    adjacent_monster_dir = None
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        for m in level.monsters:
            if m.alive and (m.x, m.y) == (p.x + dx, p.y + dy):
                adjacent_monster_dir = (dx, dy)
                break
        if adjacent_monster_dir:
            break

    if adjacent_monster_dir:
        if critical:
            # flee: step away from the monster if possible
            dx, dy = adjacent_monster_dir
            flee_dx, flee_dy = -dx, -dy
            if level.dungeon.is_walkable(p.x + flee_dx, p.y + flee_dy):
                return flee_dx, flee_dy
            for alt_dx, alt_dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                if (alt_dx, alt_dy) != adjacent_monster_dir and level.dungeon.is_walkable(p.x + alt_dx, p.y + alt_dy):
                    return alt_dx, alt_dy
        else:
            return adjacent_monster_dir

    visible = game.visible_now()

    # 2) go grab a nearby visible item
    visible_items = [pos for pos in level.items if pos in visible]
    if visible_items:
        visible_items.sort(key=lambda pos: (pos[0] - p.x) ** 2 + (pos[1] - p.y) ** 2)
        step = _bfs_step_towards(game, visible_items[0])
        if step:
            return step

    # 3) hunt a visible, reachable monster if we're healthy
    if p.hp > p.max_hp * 0.35 and not critical:
        visible_monsters = [(m.x, m.y) for m in level.monsters if m.alive and (m.x, m.y) in visible]
        if visible_monsters:
            visible_monsters.sort(key=lambda pos: (pos[0] - p.x) ** 2 + (pos[1] - p.y) ** 2)
            step = _bfs_step_towards(game, visible_monsters[0])
            if step:
                return step

    # 4) otherwise head for the stairs down
    step = _bfs_step_towards(game, level.stairs_down)
    if step:
        return step

    return 0, 0


def run_autoplay(game: Game, max_turns: int = 4000) -> None:
    while not game.game_over and game.player.turns < max_turns:
        if game.player.hp < game.player.max_hp * 0.5 and any(
            i.kind == "potion" for i in game.player.inventory
        ):
            game.use_inventory()
        dx, dy = choose_action(game)
        if (dx, dy) == (0, 0):
            break
        game.try_move_player(dx, dy)
