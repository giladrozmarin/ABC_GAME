# PyCrawler

A procedurally generated ASCII roguelike dungeon crawler, written in pure
Python 3 with **zero third-party runtime dependencies**.

- Dungeons are generated with **Binary Space Partitioning (BSP)**: rooms are
  carved inside leaf nodes of a randomly split tree, then connected along the
  tree so every room is guaranteed reachable (verified by tests using a flood
  fill across 25 random seeds).
- Turn-based combat, monsters that chase you once they see you, items
  (potions, weapons, scrolls of vigor), fog-of-war / explored-memory
  rendering, multi-level descent with a final "win" depth, and permadeath.
- A small heuristic **bot** (BFS pathfinding + priority rules: fight
  adjacent → grab visible loot → hunt visible monsters → head for the
  stairs → flee when critically low on HP) can play the game start to
  finish headlessly, which doubles as an automated playthrough test and as
  a **no-TTY-required demo mode** for judges/CI.

## Quick start

```bash
cd pycrawler
python3 -m pip install -e .        # optional, only needed for the `pycrawler` command
python3 -m pytest -q               # 11 tests: dungeon connectivity, game logic, full playthroughs

# Watch the bot play a full run, no terminal/curses required:
python3 -m pycrawler --demo --seed 3 --depth 3

# Animate it frame by frame:
python3 -m pycrawler --demo --seed 3 --depth 3 --delay 0.08

# Play it yourself in a real terminal (arrow keys / WASD, 'u' = use item, 'q' = quit):
python3 -m pycrawler --play
```

No terminal handy? Run the demo and you'll see a full playthrough log:

```
Depth 3/3  HP 22/30  ATK 9  Kills 6  Items 1  Turn 205
------------------------------------------------------------
You hit the Troll for 7.
The Troll dies!
You descend into the final chamber and claim the Heart of the Dungeon. VICTORY!
============================================================

VICTORY!  -- reached depth 3/3, 6 kills, 209 turns, seed=3
```

## Browser replay viewer (no server, no build step)

Prefer to *watch* a run in a browser instead of a terminal? Export any
autoplayed game to a single self-contained HTML file with an embedded
frame-by-frame player (Play/Pause, Step, scrub bar, speed control, colorized
tiles):

```bash
python3 tools/export_replay.py --seed 3 --depth 3 --out replay.html
```

Then just open `replay.html` directly in any browser (double-click it, or
`open replay.html` / `xdg-open replay.html`) — everything, including every
frame of the run, is inlined as JSON in the page, so it needs no network
access and no local server. Two pre-generated examples are included:

- `demos/replay_victory_seed3.html` — a full winning run (210 turns)
- `demos/replay_defeat_seed5.html` — a short, brutal loss (34 turns)

## Project layout

```
pycrawler/
  dungeon.py   pure BSP dungeon generator (no I/O, fully unit-testable)
  entities.py  Player / Actor / Item dataclasses + monster & item tables
  game.py      turn engine: movement, combat, multi-level descent, save/load
  bot.py       BFS-pathfinding heuristic autoplayer used by demo mode & tests
  render.py    plain-text frame renderer shared by curses UI and demo mode
  cli.py       argparse entry point: --demo (headless) / --play (curses)
tests/
  test_dungeon.py   connectivity, determinism, boundary-wall invariants
  test_game.py      game init, movement safety, full autoplay win/lose, saves
tools/
  export_replay.py  exports a full autoplayed run to a self-contained HTML
                     replay viewer (embedded JSON frames, no dependencies)
demos/
  replay_victory_seed3.html, replay_defeat_seed5.html  pre-generated replays
```

## Design notes

- **Determinism**: every dungeon is seeded (`--seed N`); the same seed always
  produces the same layout, monsters and items, which is what makes the
  connectivity tests and reproducible bug reports possible.
- **Separation of concerns**: `dungeon.py` and `game.py` have no rendering or
  terminal dependency at all, so the whole simulation is testable with plain
  `pytest` and runs identically under curses, the headless demo printer, or
  (trivially) a future web/GUI front end.
- **Scaling difficulty**: monster HP/ATK scale with dungeon depth, and item
  drops (potions/weapons/scrolls) scale in frequency with depth too, so
  deeper runs are meaningfully harder — the bot doesn't always win, which is
  by design (permadeath roguelike).

## Command reference

```
python -m pycrawler [--demo | --play] [--seed N] [--depth N] [--turns N] [--delay S]

--demo    headless auto-play (default mode) — prints each turn to stdout
--play    interactive curses UI in your terminal
--seed    integer seed for reproducible dungeons
--depth   number of dungeon levels to reach for victory (default 5)
--turns   turn budget for demo mode before it gives up (default 4000)
--delay   seconds between frames in demo mode, for a "replay" effect
```
