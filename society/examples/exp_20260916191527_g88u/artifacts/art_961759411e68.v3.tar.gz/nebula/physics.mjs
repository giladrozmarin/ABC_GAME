// physics.mjs — core N-body gravity engine (Barnes-Hut approximation)
// Pure, dependency-free module so it can run both in the browser and in Node for tests.

export const G = 6.674e-2; // scaled gravitational constant for a nice on-screen simulation
export const THETA = 0.6;  // Barnes-Hut opening angle
export const SOFTENING = 6; // avoids singularities when bodies get very close

export function vecSub(a, b) { return { x: a.x - b.x, y: a.y - b.y }; }
export function vecAdd(a, b) { return { x: a.x + b.x, y: a.y + b.y }; }
export function vecScale(a, s) { return { x: a.x * s, y: a.y * s }; }
export function vecLen(a) { return Math.sqrt(a.x * a.x + a.y * a.y); }

/** Compute the raw Newtonian gravitational force vector exerted on `a` by `b`. */
export function gravityForce(a, b) {
  const d = vecSub(b.pos, a.pos);
  const distSq = d.x * d.x + d.y * d.y + SOFTENING * SOFTENING;
  const dist = Math.sqrt(distSq);
  const forceMag = (G * a.mass * b.mass) / distSq;
  return vecScale(d, forceMag / dist);
}

/** Axis-aligned bounding box quadtree node for Barnes-Hut approximation. */
class QuadNode {
  constructor(x, y, size) {
    this.x = x; this.y = y; this.size = size; // bounding square: [x, x+size] x [y, y+size]
    this.mass = 0;
    this.comX = 0; this.comY = 0; // center of mass
    this.body = null; // set if leaf holding exactly one body
    this.children = null; // array of 4 QuadNode or null
  }

  isLeaf() { return this.children === null; }

  subdivide() {
    const h = this.size / 2;
    this.children = [
      new QuadNode(this.x, this.y, h),
      new QuadNode(this.x + h, this.y, h),
      new QuadNode(this.x, this.y + h, h),
      new QuadNode(this.x + h, this.y + h, h),
    ];
  }

  quadrantFor(body) {
    const h = this.size / 2;
    const right = body.pos.x >= this.x + h ? 1 : 0;
    const bottom = body.pos.y >= this.y + h ? 1 : 0;
    return bottom * 2 + right;
  }

  insert(body) {
    if (this.mass === 0 && this.body === null && this.isLeaf()) {
      this.body = body;
      this.mass = body.mass;
      this.comX = body.pos.x;
      this.comY = body.pos.y;
      return;
    }
    if (this.isLeaf()) {
      const existing = this.body;
      this.body = null;
      this.subdivide();
      if (existing) this.children[this.quadrantFor(existing)].insert(existing);
      this.children[this.quadrantFor(body)].insert(body);
    } else {
      this.children[this.quadrantFor(body)].insert(body);
    }
    const totalMass = this.mass + body.mass;
    this.comX = (this.comX * this.mass + body.pos.x * body.mass) / totalMass;
    this.comY = (this.comY * this.mass + body.pos.y * body.mass) / totalMass;
    this.mass = totalMass;
  }

  /** Accumulate gravitational acceleration on `body` into `acc` {x,y}. */
  accumulateForce(body, theta, acc) {
    if (this.mass === 0) return;
    if (this.body === body) return; // skip self
    const dx = this.comX - body.pos.x;
    const dy = this.comY - body.pos.y;
    const distSq = dx * dx + dy * dy + SOFTENING * SOFTENING;
    const dist = Math.sqrt(distSq);
    if (this.isLeaf() || this.size / dist < theta) {
      const forceMag = (G * this.mass) / distSq; // acceleration on body = G*M/d^2
      acc.x += (dx / dist) * forceMag;
      acc.y += (dy / dist) * forceMag;
    } else {
      for (const c of this.children) c.accumulateForce(body, theta, acc);
    }
  }
}

/** Build a Barnes-Hut quadtree covering all bodies. */
export function buildTree(bodies) {
  if (bodies.length === 0) return null;
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const b of bodies) {
    if (b.pos.x < minX) minX = b.pos.x;
    if (b.pos.y < minY) minY = b.pos.y;
    if (b.pos.x > maxX) maxX = b.pos.x;
    if (b.pos.y > maxY) maxY = b.pos.y;
  }
  const size = Math.max(maxX - minX, maxY - minY, 1) * 1.2 + 10;
  const root = new QuadNode(minX - 5, minY - 5, size);
  for (const b of bodies) root.insert(b);
  return root;
}

/** Collect the bounding square of every node in a Barnes-Hut tree, for debug/visualization. */
export function collectQuadBounds(tree, out = []) {
  if (!tree || tree.mass === 0) return out;
  out.push({ x: tree.x, y: tree.y, size: tree.size, leaf: tree.isLeaf() });
  if (!tree.isLeaf()) for (const c of tree.children) collectQuadBounds(c, out);
  return out;
}

/**
 * Merge bodies that have physically collided (distance <= sum of radii) into
 * a single combined body, conserving total mass and momentum (perfectly
 * inelastic collision / accretion). Mutates and returns a new bodies array.
 */
export function resolveCollisions(bodies) {
  const merged = new Array(bodies.length).fill(false);
  const result = [];
  for (let i = 0; i < bodies.length; i++) {
    if (merged[i]) continue;
    let host = bodies[i];
    for (let j = i + 1; j < bodies.length; j++) {
      if (merged[j]) continue;
      const other = bodies[j];
      const dx = other.pos.x - host.pos.x;
      const dy = other.pos.y - host.pos.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const minDist = ((host.radius || 1) + (other.radius || 1)) * 0.32;
      if (dist < minDist) {
        const totalMass = host.mass + other.mass;
        const newPos = {
          x: (host.pos.x * host.mass + other.pos.x * other.mass) / totalMass,
          y: (host.pos.y * host.mass + other.pos.y * other.mass) / totalMass,
        };
        const newVel = {
          x: (host.vel.x * host.mass + other.vel.x * other.mass) / totalMass,
          y: (host.vel.y * host.mass + other.vel.y * other.mass) / totalMass,
        };
        const newRadius = Math.cbrt(Math.pow(host.radius || 1, 3) + Math.pow(other.radius || 1, 3));
        host = {
          pos: newPos, vel: newVel, mass: totalMass, radius: newRadius,
          color: host.mass >= other.mass ? host.color : other.color,
        };
        merged[j] = true;
      }
    }
    result.push(host);
  }
  return result;
}

/** Advance the simulation in-place by dt using leapfrog (velocity-Verlet-like) integration. */
export function step(bodies, dt, theta = THETA) {
  const tree = buildTree(bodies);
  const accs = new Array(bodies.length);
  for (let i = 0; i < bodies.length; i++) {
    const acc = { x: 0, y: 0 };
    if (tree) tree.accumulateForce(bodies[i], theta, acc);
    accs[i] = acc;
  }
  for (let i = 0; i < bodies.length; i++) {
    const b = bodies[i];
    b.vel.x += accs[i].x * dt;
    b.vel.y += accs[i].y * dt;
    b.pos.x += b.vel.x * dt;
    b.pos.y += b.vel.y * dt;
  }
  return bodies;
}

/** Brute-force O(n^2) reference step, used by tests to validate Barnes-Hut accuracy. */
export function stepBruteForce(bodies, dt) {
  const accs = bodies.map(() => ({ x: 0, y: 0 }));
  for (let i = 0; i < bodies.length; i++) {
    for (let j = 0; j < bodies.length; j++) {
      if (i === j) continue;
      const dx = bodies[j].pos.x - bodies[i].pos.x;
      const dy = bodies[j].pos.y - bodies[i].pos.y;
      const distSq = dx * dx + dy * dy + SOFTENING * SOFTENING;
      const dist = Math.sqrt(distSq);
      const forceMag = (G * bodies[j].mass) / distSq;
      accs[i].x += (dx / dist) * forceMag;
      accs[i].y += (dy / dist) * forceMag;
    }
  }
  for (let i = 0; i < bodies.length; i++) {
    bodies[i].vel.x += accs[i].x * dt;
    bodies[i].vel.y += accs[i].y * dt;
    bodies[i].pos.x += bodies[i].vel.x * dt;
    bodies[i].pos.y += bodies[i].vel.y * dt;
  }
  return bodies;
}

export function totalMomentum(bodies) {
  return bodies.reduce((acc, b) => ({ x: acc.x + b.vel.x * b.mass, y: acc.y + b.vel.y * b.mass }), { x: 0, y: 0 });
}

export function totalEnergy(bodies) {
  let ke = 0, pe = 0;
  for (const b of bodies) ke += 0.5 * b.mass * (b.vel.x * b.vel.x + b.vel.y * b.vel.y);
  for (let i = 0; i < bodies.length; i++) {
    for (let j = i + 1; j < bodies.length; j++) {
      const dx = bodies[j].pos.x - bodies[i].pos.x;
      const dy = bodies[j].pos.y - bodies[i].pos.y;
      const dist = Math.sqrt(dx * dx + dy * dy + SOFTENING * SOFTENING);
      pe -= (G * bodies[i].mass * bodies[j].mass) / dist;
    }
  }
  return ke + pe;
}

/** Deterministic seeded PRNG (mulberry32) so demo scenes are reproducible. */
export function makeRng(seed) {
  let a = seed >>> 0;
  return function rng() {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function makeGalaxy({ n = 400, cx = 0, cy = 0, radius = 260, seed = 1, centralMass = 26000 } = {}) {
  const rng = makeRng(seed);
  const bodies = [];
  bodies.push({ pos: { x: cx, y: cy }, vel: { x: 0, y: 0 }, mass: centralMass, radius: 6, color: '#fff7d6', fixed: false });
  for (let i = 0; i < n; i++) {
    const r = radius * Math.sqrt(rng()) + 12;
    const angle = rng() * Math.PI * 2;
    const x = cx + Math.cos(angle) * r;
    const y = cy + Math.sin(angle) * r * 0.55; // flatten into a disk-ish spiral
    // Orbital velocity for a roughly circular orbit around the central mass
    const speed = Math.sqrt((G * centralMass) / r) * (0.85 + rng() * 0.3);
    const vx = -Math.sin(angle) * speed;
    const vy = Math.cos(angle) * speed * 0.55;
    const mass = 1 + rng() * 3;
    const hue = 190 + rng() * 140;
    bodies.push({
      pos: { x, y }, vel: { x: vx, y: vy }, mass,
      radius: 1 + Math.cbrt(mass),
      color: `hsl(${hue.toFixed(0)}, 80%, 70%)`,
    });
  }
  return bodies;
}
