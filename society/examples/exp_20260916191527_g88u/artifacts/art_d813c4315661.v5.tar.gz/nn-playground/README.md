# NN Playground

A **from-scratch, zero-dependency neural network** — the backprop engine is
~150 lines of plain JavaScript with no libraries (no TensorFlow.js, no npm
install required) — trained **live in your browser** with a real-time
decision-boundary visualization, loss curve, and interactive controls.

## Why it's interesting

- **The whole ML stack is hand-written**: dense layers, forward pass,
  backprop, SGD, tanh/relu/sigmoid activations — all in `src/nn.js`, ~150
  lines, no dependencies at all (not even in `package.json`).
- **That same file runs unmodified in Node and in the browser** (UMD-style
  export), so it's both the engine powering the visualizer *and* the thing
  covered by automated unit tests.
- **Live visual feedback**: pick a dataset (XOR, circle, spiral, linear),
  pick a network architecture, watch the decision surface warp in real time
  as gradient descent runs, frame by frame, in front of you.
- **It actually learns the hard cases**: the two-spiral dataset is a classic
  stress test for MLPs and the default 8x8 tanh network solves it live.
- **Live network-structure diagram**: a second canvas draws every neuron and
  every weight as a node/edge graph, colored by sign (blue = positive, red =
  negative) and thickness/opacity by magnitude, redrawn every frame — you can
  literally watch the weights reorganize themselves during training.
- **Fully interactive dataset**: click the main canvas to drop a new "class 1"
  point, right-click to drop a "class 0" point, and watch the decision
  boundary bend to accommodate your new data in real time — no page reload,
  no retraining step, it just keeps learning.

## Run it

No build step, no server required:

```bash
open index.html      # macOS
# or just double-click index.html / drag it into a browser tab
```

(If your browser blocks local `<script src>` loading under `file://`, serve
it instead: `npx serve .` or `python3 -m http.server`, then open the printed
URL.)

## Test it

```bash
npm test
```

Runs `test/nn.test.js` (plain Node `assert`, no test framework dependency)
which verifies:
- forward pass output shape/range,
- that a single training step actually reduces loss,
- that the network converges and correctly solves **XOR** (the textbook
  proof a network has a working hidden layer + non-linearity + backprop),
- **a numerical gradient check**: backprop's analytic weight gradients are
  compared against finite-difference gradients computed by directly
  perturbing weights and measuring the loss change — the standard sanity
  check that a from-scratch backprop implementation is mathematically
  correct, not just "looks like it's learning",
- that every bundled toy dataset generator produces well-formed data.

## Benchmark it

```bash
npm run benchmark
```

Headlessly trains the same engine on all four bundled datasets (with tuned
hyperparameters per dataset, e.g. a bigger net + smaller learning rate for
the harder two-spiral problem) and prints accuracy / convergence speed —
useful for verifying the engine actually works without opening a browser:

```
xor      acc=100.0%  final_loss=0.0000  converged_at_epoch=3    [PASS]
circle   acc=100.0%  final_loss=0.0000  converged_at_epoch=4    [PASS]
spiral   acc=98.8%   final_loss=0.0129  converged_at_epoch=686  [PASS]
linear   acc=100.0%  final_loss=0.0000  converged_at_epoch=1    [PASS]
```

## Project layout

```
index.html          interactive visualizer (canvas, vanilla JS, no deps)
src/nn.js           the neural network engine (Dense layer, Network, datasets)
test/nn.test.js     unit tests for src/nn.js
scripts/benchmark.js headless accuracy/convergence benchmark across datasets
package.json        `npm test` / `npm run benchmark` entry points
```

## Controls

- **Dataset**: XOR / Circle / Spiral / Linear
- **Hidden layer sizes**: pick network capacity
- **Learning rate**: live-adjustable SGD step size
- **Play/Pause, Reset**: control the training loop
- Live stats: epoch count, MSE loss, classification accuracy, loss curve

---
Built solo, end-to-end (engine + tests + UI + docs), by agent **D** as an
entry in a timed multi-agent build competition.
