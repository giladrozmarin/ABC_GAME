// Pure pathfinding/maze-generation algorithms, shared between the browser UI
// and the Node test suite (no DOM dependencies).
'use strict';

function key(r, c) { return r + ',' + c; }

function neighbors(r, c, rows, cols) {
  const out = [];
  if (r > 0) out.push([r - 1, c]);
  if (r < rows - 1) out.push([r + 1, c]);
  if (c > 0) out.push([r, c - 1]);
  if (c < cols - 1) out.push([r, c + 1]);
  return out;
}

function reconstructPath(cameFrom, endKey) {
  const path = [];
  let cur = endKey;
  while (cur !== undefined) {
    path.push(cur);
    cur = cameFrom.get(cur);
  }
  path.reverse();
  return path;
}

// grid: 2D array of 0 (open) / 1 (wall)
function bfs(grid, start, end) {
  const rows = grid.length, cols = grid[0].length;
  const visitedOrder = [];
  const cameFrom = new Map();
  const seen = new Set([key(...start)]);
  const queue = [start];
  let qi = 0;
  while (qi < queue.length) {
    const [r, c] = queue[qi++];
    visitedOrder.push(key(r, c));
    if (r === end[0] && c === end[1]) {
      return { visitedOrder, path: reconstructPath(cameFrom, key(r, c)), found: true };
    }
    for (const [nr, nc] of neighbors(r, c, rows, cols)) {
      if (grid[nr][nc] === 1) continue;
      const k = key(nr, nc);
      if (seen.has(k)) continue;
      seen.add(k);
      cameFrom.set(k, key(r, c));
      queue.push([nr, nc]);
    }
  }
  return { visitedOrder, path: [], found: false };
}

function dfs(grid, start, end) {
  const rows = grid.length, cols = grid[0].length;
  const visitedOrder = [];
  const cameFrom = new Map();
  const seen = new Set();
  const stack = [start];
  while (stack.length) {
    const [r, c] = stack.pop();
    const k = key(r, c);
    if (seen.has(k)) continue;
    seen.add(k);
    visitedOrder.push(k);
    if (r === end[0] && c === end[1]) {
      return { visitedOrder, path: reconstructPath(cameFrom, k), found: true };
    }
    for (const [nr, nc] of neighbors(r, c, rows, cols)) {
      if (grid[nr][nc] === 1) continue;
      const nk = key(nr, nc);
      if (!seen.has(nk)) {
        if (!cameFrom.has(nk)) cameFrom.set(nk, k);
        stack.push([nr, nc]);
      }
    }
  }
  return { visitedOrder, path: [], found: false };
}

function dijkstra(grid, start, end, weighted) {
  const rows = grid.length, cols = grid[0].length;
  const dist = new Map();
  const cameFrom = new Map();
  const visitedOrder = [];
  const startK = key(...start);
  dist.set(startK, 0);
  // simple array-based priority queue (fine for demo-sized grids)
  const pq = [[0, start]];
  const visited = new Set();
  while (pq.length) {
    pq.sort((a, b) => a[0] - b[0]);
    const [d, [r, c]] = pq.shift();
    const k = key(r, c);
    if (visited.has(k)) continue;
    visited.add(k);
    visitedOrder.push(k);
    if (r === end[0] && c === end[1]) {
      return { visitedOrder, path: reconstructPath(cameFrom, k), found: true, cost: d };
    }
    for (const [nr, nc] of neighbors(r, c, rows, cols)) {
      if (grid[nr][nc] === 1) continue;
      const nk = key(nr, nc);
      const w = weighted && weighted[nr] && weighted[nr][nc] ? weighted[nr][nc] : 1;
      const nd = d + w;
      if (nd < (dist.has(nk) ? dist.get(nk) : Infinity)) {
        dist.set(nk, nd);
        cameFrom.set(nk, k);
        pq.push([nd, [nr, nc]]);
      }
    }
  }
  return { visitedOrder, path: [], found: false };
}

function heuristic(a, b) {
  return Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]);
}

function astar(grid, start, end, weighted) {
  const rows = grid.length, cols = grid[0].length;
  const gScore = new Map([[key(...start), 0]]);
  const fScore = new Map([[key(...start), heuristic(start, end)]]);
  const cameFrom = new Map();
  const visitedOrder = [];
  const open = [[fScore.get(key(...start)), start]];
  const closed = new Set();
  while (open.length) {
    open.sort((a, b) => a[0] - b[0]);
    const [, [r, c]] = open.shift();
    const k = key(r, c);
    if (closed.has(k)) continue;
    closed.add(k);
    visitedOrder.push(k);
    if (r === end[0] && c === end[1]) {
      return { visitedOrder, path: reconstructPath(cameFrom, k), found: true, cost: gScore.get(k) };
    }
    for (const [nr, nc] of neighbors(r, c, rows, cols)) {
      if (grid[nr][nc] === 1) continue;
      const nk = key(nr, nc);
      const w = weighted && weighted[nr] && weighted[nr][nc] ? weighted[nr][nc] : 1;
      const tentative = gScore.get(k) + w;
      if (tentative < (gScore.has(nk) ? gScore.get(nk) : Infinity)) {
        cameFrom.set(nk, k);
        gScore.set(nk, tentative);
        fScore.set(nk, tentative + heuristic([nr, nc], end));
        open.push([fScore.get(nk), [nr, nc]]);
      }
    }
  }
  return { visitedOrder, path: [], found: false };
}

// Bidirectional BFS: grows a frontier simultaneously from start and end,
// one level at a time, and stops as soon as the two frontiers touch.
// Typically visits far fewer nodes than a single-direction BFS/A* on open grids.
function bidirectionalBFS(grid, start, end) {
  const rows = grid.length, cols = grid[0].length;
  const startK = key(...start), endK = key(...end);
  const visitedOrder = [];
  if (startK === endK) return { visitedOrder: [startK], path: [startK], found: true };

  const cameFromStart = new Map();
  const cameFromEnd = new Map();
  const seenStart = new Set([startK]);
  const seenEnd = new Set([endK]);
  let frontierStart = [start];
  let frontierEnd = [end];

  function expandLevel(frontier, seenSelf, cameFromSelf, seenOther) {
    const next = [];
    for (const [r, c] of frontier) {
      const k = key(r, c);
      visitedOrder.push(k);
      for (const [nr, nc] of neighbors(r, c, rows, cols)) {
        if (grid[nr][nc] === 1) continue;
        const nk = key(nr, nc);
        if (seenSelf.has(nk)) continue;
        seenSelf.add(nk);
        cameFromSelf.set(nk, k);
        if (seenOther.has(nk)) return nk; // frontiers touch: nk is the meeting node
        next.push([nr, nc]);
      }
    }
    frontier.length = 0;
    Array.prototype.push.apply(frontier, next);
    return null;
  }

  while (frontierStart.length && frontierEnd.length) {
    // expand the smaller frontier first (classic bidirectional BFS optimization)
    let meet;
    if (frontierStart.length <= frontierEnd.length) {
      meet = expandLevel(frontierStart, seenStart, cameFromStart, seenEnd);
    } else {
      meet = expandLevel(frontierEnd, seenEnd, cameFromEnd, seenStart);
    }
    if (meet) {
      const left = [];
      let cur = meet;
      while (cur !== undefined) { left.push(cur); cur = cameFromStart.get(cur); }
      left.reverse(); // start ... meet
      const right = [];
      cur = cameFromEnd.get(meet);
      while (cur !== undefined) { right.push(cur); cur = cameFromEnd.get(cur); }
      return { visitedOrder, path: left.concat(right), found: true };
    }
  }
  return { visitedOrder, path: [], found: false };
}

// Recursive-backtracker maze generator on an odd-sized grid.
// Returns a rows x cols grid of 0 (passage) / 1 (wall).
function generateMaze(rows, cols, rng) {
  rng = rng || Math.random;
  const grid = Array.from({ length: rows }, () => Array(cols).fill(1));
  function carve(r, c) {
    grid[r][c] = 0;
    const dirs = [[-2, 0], [2, 0], [0, -2], [0, 2]];
    for (let i = dirs.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [dirs[i], dirs[j]] = [dirs[j], dirs[i]];
    }
    for (const [dr, dc] of dirs) {
      const nr = r + dr, nc = c + dc;
      if (nr > 0 && nr < rows - 1 && nc > 0 && nc < cols - 1 && grid[nr][nc] === 1) {
        grid[r + dr / 2][c + dc / 2] = 0;
        carve(nr, nc);
      }
    }
  }
  carve(1, 1);
  grid[0][1] = 0;
  grid[rows - 1][cols - 2] = 0;
  return grid;
}

const ALGORITHMS = { bfs, dfs, dijkstra, astar, bidirectionalBFS };

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { bfs, dfs, dijkstra, astar, bidirectionalBFS, generateMaze, ALGORITHMS, key, neighbors };
}
