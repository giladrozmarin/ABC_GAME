# NN Playground

A **from-scratch, zero-dependency neural network** — the backprop engine is
~150 lines of plain JavaScript with no libraries (no TensorFlow.js, no npm
install required) — trained **live in your browser** with a real-time
decision-boundary visualization, loss curve, and interactive controls.

## Why it's interesting

- **The whole ML stack is hand-written**: dense layers, forward pass,
  backprop, SGD, tanh/relu/sigmoid activations — all in `src/nn.js`, ~150
  lines, no dependencies at all (not even in `package.json`).
- **That same file runs unmodified in Node and in the browser** (UMD-style
  export), so it's both the engine powering the visualizer *and* the thing
  covered by automated unit tests.
- **Live visual feedback**: pick a dataset (XOR, circle, spiral, linear),
  pick a network architecture, watch the decision surface warp in real time
  as gradient descent runs, frame by frame, in front of you.
- **It actually learns the hard cases**: the two-spiral dataset is a classic
  stress test for MLPs and the default 8x8 tanh network solves it live.

## Run it

No build step, no server required:

```bash
open index.html      # macOS
# or just double-click index.html / drag it into a browser tab
```

(If your browser blocks local `<script src>` loading under `file://`, serve
it instead: `npx serve .` or `python3 -m http.server`, then open the printed
URL.)

## Test it

```bash
npm test
```

Runs `test/nn.test.js` (plain Node `assert`, no test framework dependency)
which verifies:
- forward pass output shape/range,
- that a single training step actually reduces loss,
- that the network converges and correctly solves **XOR** (the textbook
  proof a network has a working hidden layer + non-linearity + backprop),
- that every bundled toy dataset generator produces well-formed data.

## Project layout

```
index.html        interactive visualizer (canvas, vanilla JS, no deps)
src/nn.js         the neural network engine (Dense layer, Network, datasets)
test/nn.test.js   unit tests for src/nn.js
package.json      `npm test` entry point
```

## Controls

- **Dataset**: XOR / Circle / Spiral / Linear
- **Hidden layer sizes**: pick network capacity
- **Learning rate**: live-adjustable SGD step size
- **Play/Pause, Reset**: control the training loop
- Live stats: epoch count, MSE loss, classification accuracy, loss curve

---
Built solo, end-to-end (engine + tests + UI + docs), by agent **D** as an
entry in a timed multi-agent build competition.
