// Simple zero-dependency test runner (works with plain `node test/nn.test.js`).
const assert = require('assert');
const { Network, makeDataset } = require('../src/nn');

let passed = 0;
function test(name, fn) {
  try {
    fn();
    console.log('  ok -', name);
    passed++;
  } catch (e) {
    console.error('FAIL -', name);
    console.error(e);
    process.exitCode = 1;
  }
}

console.log('nn.js test suite');

test('predict returns correct output shape', () => {
  const net = new Network([2, 4, 1]);
  const out = net.predict([0.1, -0.2]);
  assert.strictEqual(out.length, 1);
  assert.ok(out[0] >= 0 && out[0] <= 1, 'sigmoid output should be in [0,1]');
});

test('trainStep reduces loss on a single repeated example', () => {
  const net = new Network([2, 8, 1]);
  const x = [0.5, 0.5];
  const y = [1];
  const firstLoss = net.trainStep(x, y, 0.5);
  let lastLoss = firstLoss;
  for (let i = 0; i < 200; i++) {
    lastLoss = net.trainStep(x, y, 0.5);
  }
  assert.ok(lastLoss < firstLoss, `expected loss to decrease: ${firstLoss} -> ${lastLoss}`);
  assert.ok(lastLoss < 0.05, `expected loss to converge near 0, got ${lastLoss}`);
});

test('network can learn XOR (classic non-linear separability test)', () => {
  const net = new Network([2, 8, 1], 'tanh', 'sigmoid');
  const data = [
    [[-1, -1], [0]],
    [[-1, 1], [1]],
    [[1, -1], [1]],
    [[1, 1], [0]],
  ];
  let loss = 1;
  for (let epoch = 0; epoch < 2000; epoch++) {
    loss = net.trainEpoch(data, 0.3);
  }
  for (const [x, y] of data) {
    const pred = net.predict(x)[0];
    assert.ok(Math.round(pred) === y[0], `XOR mismatch for ${x}: got ${pred}, want ${y[0]}`);
  }
  assert.ok(loss < 0.05, `expected converged loss < 0.05, got ${loss}`);
});

test('makeDataset produces requested size and valid labels for every dataset type', () => {
  for (const name of ['xor', 'circle', 'spiral', 'linear']) {
    const data = makeDataset(name, 50);
    assert.strictEqual(data.length, 50);
    for (const [x, y] of data) {
      assert.strictEqual(x.length, 2);
      assert.ok(y[0] === 0 || y[0] === 1);
    }
  }
});

console.log(`\n${passed} test(s) passed.`);
if (process.exitCode) {
  console.log('SOME TESTS FAILED');
} else {
  console.log('ALL TESTS PASSED');
}
