// Optional end-to-end smoke test using a real headless browser (Playwright).
// This is NOT required to run or judge the project (index.html has zero
// dependencies and needs no build step) -- it's an extra layer of proof
// that the UI actually works: loads with no console/page errors, trains
// live, reaches high accuracy on the hard spiral dataset, and responds to
// user clicks.
//
// Usage:
//   npm i -D playwright && npx playwright install chromium   # one-time
//   node scripts/smoke-test.js
const path = require('path');

async function main() {
  let chromium;
  try {
    ({ chromium } = require('playwright'));
  } catch (e) {
    console.error('Playwright is not installed. This script is optional --');
    console.error('the app itself has zero dependencies. To run this check:');
    console.error('  npm i -D playwright && npx playwright install chromium');
    process.exit(1);
  }

  const url = 'file://' + path.join(__dirname, '..', 'index.html');
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push('console.error: ' + msg.text());
  });

  console.log('Loading', url);
  await page.goto(url);
  await page.waitForTimeout(1500);

  const epochStart = await page.textContent('#epoch');
  if (Number(epochStart) <= 0) throw new Error('training did not start');
  console.log('training is running, epoch =', epochStart);

  // exercise the interactive click-to-add-point feature
  await page.click('#viz', { position: { x: 60, y: 60 } });
  await page.waitForTimeout(300);
  console.log('click-to-add-point handled without error');

  // let the default (hard) spiral dataset actually converge
  console.log('training on the two-spiral dataset for ~9s...');
  await page.waitForTimeout(9000);
  const acc = parseFloat(await page.textContent('#acc'));
  const epochEnd = await page.textContent('#epoch');
  console.log(`epoch=${epochEnd} accuracy=${acc}%`);

  await page.screenshot({ path: path.join(__dirname, '..', 'docs', 'screenshot.png') });

  await browser.close();

  if (errors.length) {
    console.error('FAIL: console/page errors detected:\n' + errors.join('\n'));
    process.exit(1);
  }
  if (!(acc >= 85)) {
    console.error(`FAIL: expected spiral accuracy >= 85%, got ${acc}%`);
    process.exit(1);
  }
  console.log('PASS: UI loaded, trained live, handled clicks, zero console errors.');
}

main().catch((e) => {
  console.error('FATAL', e);
  process.exit(1);
});
