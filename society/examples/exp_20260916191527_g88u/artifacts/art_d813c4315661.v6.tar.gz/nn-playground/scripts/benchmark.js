// Headless benchmark: trains the same engine used by index.html on every
// bundled dataset and reports convergence speed + final accuracy.
// Useful for judges/graders who want to verify the engine works without
// opening a browser.
const { Network, makeDataset } = require('../src/nn');

function accuracy(net, data) {
  let correct = 0;
  for (const [x, y] of data) {
    const pred = net.predict(x)[0] >= 0.5 ? 1 : 0;
    if (pred === y[0]) correct++;
  }
  return correct / data.length;
}

function run(name, { hidden = [8, 8], lr = 0.3, epochs = 400, target = 0.9 } = {}) {
  const data = makeDataset(name, 240);
  const net = new Network([2, ...hidden, 1], 'tanh', 'sigmoid');
  let converged = null;
  let loss = 1;
  for (let e = 1; e <= epochs; e++) {
    loss = net.trainEpoch(data, lr);
    if (converged === null && accuracy(net, data) >= target) converged = e;
  }
  const acc = accuracy(net, data);
  return { name, epochs, converged, acc, loss };
}

console.log('NN Playground — headless benchmark');
console.log('===================================');
const configs = [
  ['xor', {}],
  ['circle', {}],
  ['spiral', { hidden: [32, 16], lr: 0.05, epochs: 3000, target: 0.9 }],
  ['linear', {}],
];

let allGood = true;
for (const [name, opts] of configs) {
  const r = run(name, opts);
  const status = r.acc >= 0.85 ? 'PASS' : 'WEAK';
  if (status !== 'PASS') allGood = false;
  console.log(
    `${name.padEnd(8)} acc=${(r.acc * 100).toFixed(1)}%  final_loss=${r.loss.toFixed(4)}  ` +
    `converged_at_epoch=${r.converged ?? 'n/a'}  [${status}]`
  );
}
console.log('===================================');
console.log(allGood ? 'All datasets learned successfully.' : 'Some datasets did not reach target accuracy.');
process.exitCode = allGood ? 0 : 1;
