// Simple zero-dependency test runner (works with plain `node test/nn.test.js`).
const assert = require('assert');
const { Network, makeDataset } = require('../src/nn');

let passed = 0;
function test(name, fn) {
  try {
    fn();
    console.log('  ok -', name);
    passed++;
  } catch (e) {
    console.error('FAIL -', name);
    console.error(e);
    process.exitCode = 1;
  }
}

console.log('nn.js test suite');

test('predict returns correct output shape', () => {
  const net = new Network([2, 4, 1]);
  const out = net.predict([0.1, -0.2]);
  assert.strictEqual(out.length, 1);
  assert.ok(out[0] >= 0 && out[0] <= 1, 'sigmoid output should be in [0,1]');
});

test('trainStep reduces loss on a single repeated example', () => {
  const net = new Network([2, 8, 1]);
  const x = [0.5, 0.5];
  const y = [1];
  const firstLoss = net.trainStep(x, y, 0.5);
  let lastLoss = firstLoss;
  for (let i = 0; i < 200; i++) {
    lastLoss = net.trainStep(x, y, 0.5);
  }
  assert.ok(lastLoss < firstLoss, `expected loss to decrease: ${firstLoss} -> ${lastLoss}`);
  assert.ok(lastLoss < 0.05, `expected loss to converge near 0, got ${lastLoss}`);
});

test('network can learn XOR (classic non-linear separability test)', () => {
  const net = new Network([2, 8, 1], 'tanh', 'sigmoid');
  const data = [
    [[-1, -1], [0]],
    [[-1, 1], [1]],
    [[1, -1], [1]],
    [[1, 1], [0]],
  ];
  let loss = 1;
  for (let epoch = 0; epoch < 2000; epoch++) {
    loss = net.trainEpoch(data, 0.3);
  }
  for (const [x, y] of data) {
    const pred = net.predict(x)[0];
    assert.ok(Math.round(pred) === y[0], `XOR mismatch for ${x}: got ${pred}, want ${y[0]}`);
  }
  assert.ok(loss < 0.05, `expected converged loss < 0.05, got ${loss}`);
});

test('backprop gradients match numerical (finite-difference) gradients', () => {
  // Classic gradient-check: perturb one weight by +-eps, measure the change
  // in loss directly (no backprop involved), and confirm it matches what
  // backward() computed analytically. This is the standard sanity check
  // that a from-scratch backprop implementation is actually correct.
  const net = new Network([2, 5, 1], 'tanh', 'sigmoid');
  const x = [0.3, -0.7];
  const y = [1];

  function mseLoss() {
    const out = net.predict(x);
    let loss = 0;
    for (let i = 0; i < out.length; i++) {
      const err = out[i] - y[i];
      loss += err * err;
    }
    return loss / out.length;
  }

  const eps = 1e-5;
  let checked = 0;
  for (const layer of net.layers) {
    for (let o = 0; o < layer.outSize; o++) {
      for (let i = 0; i < layer.inSize; i += Math.max(1, Math.floor(layer.inSize / 2))) {
        const w0 = layer.W[o][i];

        layer.W[o][i] = w0 + eps;
        const lossPlus = mseLoss();
        layer.W[o][i] = w0 - eps;
        const lossMinus = mseLoss();
        layer.W[o][i] = w0; // restore before analytic pass
        const numericalGrad = (lossPlus - lossMinus) / (2 * eps);

        // Analytic gradient via backward(): dLoss/dW = (w_before - w_after) / lr
        const tinyLr = 1e-3;
        const before = layer.W[o][i];
        net.trainStep(x, y, tinyLr);
        const after = layer.W[o][i];
        const analyticGrad = (before - after) / tinyLr;
        layer.W[o][i] = before; // undo the tiny training step for this weight

        assert.ok(
          Math.abs(numericalGrad - analyticGrad) < 1e-2,
          `gradient mismatch: numerical=${numericalGrad.toFixed(6)} analytic=${analyticGrad.toFixed(6)}`
        );
        checked++;
      }
    }
  }
  assert.ok(checked > 0, 'expected to gradient-check at least one weight');
});

test('makeDataset produces requested size and valid labels for every dataset type', () => {
  for (const name of ['xor', 'circle', 'spiral', 'linear']) {
    const data = makeDataset(name, 50);
    assert.strictEqual(data.length, 50);
    for (const [x, y] of data) {
      assert.strictEqual(x.length, 2);
      assert.ok(y[0] === 0 || y[0] === 1);
    }
  }
});

console.log(`\n${passed} test(s) passed.`);
if (process.exitCode) {
  console.log('SOME TESTS FAILED');
} else {
  console.log('ALL TESTS PASSED');
}
