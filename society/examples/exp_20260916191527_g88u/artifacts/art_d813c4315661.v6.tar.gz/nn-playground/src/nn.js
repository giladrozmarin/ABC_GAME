// Minimal, dependency-free feed-forward neural network with backprop.
// Works in both Node (module.exports) and the browser (window.NN).
(function (root, factory) {
  const mod = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = mod;
  } else {
    root.NN = mod;
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function randn() {
    // Box-Muller
    let u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  const ACT = {
    tanh: {
      f: Math.tanh,
      d: (y) => 1 - y * y, // derivative in terms of output y
    },
    relu: {
      f: (x) => Math.max(0, x),
      d: (y) => (y > 0 ? 1 : 0),
    },
    sigmoid: {
      f: (x) => 1 / (1 + Math.exp(-x)),
      d: (y) => y * (1 - y),
    },
  };

  class Dense {
    constructor(inSize, outSize, activation) {
      this.inSize = inSize;
      this.outSize = outSize;
      this.activation = activation;
      // He/Xavier-ish init
      const scale = Math.sqrt(2 / inSize);
      this.W = Array.from({ length: outSize }, () =>
        Array.from({ length: inSize }, () => randn() * scale)
      );
      this.b = new Array(outSize).fill(0);
    }

    forward(x) {
      this.lastInput = x;
      const act = ACT[this.activation];
      const z = new Array(this.outSize);
      const y = new Array(this.outSize);
      for (let o = 0; o < this.outSize; o++) {
        let sum = this.b[o];
        const row = this.W[o];
        for (let i = 0; i < this.inSize; i++) sum += row[i] * x[i];
        z[o] = sum;
        y[o] = act.f(sum);
      }
      this.lastOutput = y;
      return y;
    }

    // dLoss/dOutput -> returns dLoss/dInput, mutates gradients (accumulated externally)
    backward(dOut, lr) {
      const act = ACT[this.activation];
      const dIn = new Array(this.inSize).fill(0);
      for (let o = 0; o < this.outSize; o++) {
        const dz = dOut[o] * act.d(this.lastOutput[o]);
        for (let i = 0; i < this.inSize; i++) {
          dIn[i] += this.W[o][i] * dz;
          this.W[o][i] -= lr * dz * this.lastInput[i];
        }
        this.b[o] -= lr * dz;
      }
      return dIn;
    }
  }

  class Network {
    constructor(sizes, hiddenActivation = 'tanh', outputActivation = 'sigmoid') {
      this.layers = [];
      for (let i = 0; i < sizes.length - 1; i++) {
        const isOut = i === sizes.length - 2;
        this.layers.push(
          new Dense(sizes[i], sizes[i + 1], isOut ? outputActivation : hiddenActivation)
        );
      }
    }

    predict(x) {
      let out = x;
      for (const layer of this.layers) out = layer.forward(out);
      return out;
    }

    // one SGD step on a single example, mean-squared-error loss. Returns loss.
    trainStep(x, target, lr) {
      const out = this.predict(x);
      let loss = 0;
      const dOut = new Array(out.length);
      for (let i = 0; i < out.length; i++) {
        const err = out[i] - target[i];
        loss += err * err;
        dOut[i] = 2 * err;
      }
      let grad = dOut;
      for (let l = this.layers.length - 1; l >= 0; l--) {
        grad = this.layers[l].backward(grad, lr);
      }
      return loss / out.length;
    }

    trainEpoch(data, lr) {
      let total = 0;
      for (const [x, y] of data) total += this.trainStep(x, y, lr);
      return total / data.length;
    }
  }

  // ---- Toy datasets, all 2D input -> 1D label in {0,1} ----
  function makeDataset(name, n = 200) {
    const pts = [];
    const rand = (a, b) => a + Math.random() * (b - a);
    if (name === 'xor') {
      for (let i = 0; i < n; i++) {
        const x = rand(-1, 1), y = rand(-1, 1);
        const label = (x > 0) !== (y > 0) ? 1 : 0;
        pts.push([[x, y], [label]]);
      }
    } else if (name === 'circle') {
      for (let i = 0; i < n; i++) {
        const x = rand(-1, 1), y = rand(-1, 1);
        const label = Math.sqrt(x * x + y * y) < 0.5 ? 1 : 0;
        pts.push([[x, y], [label]]);
      }
    } else if (name === 'spiral') {
      for (let i = 0; i < n; i++) {
        const label = i % 2;
        const r = (i / n) * 1.0;
        const t = (i / n) * 4 * Math.PI + (label ? Math.PI : 0);
        const noise = rand(-0.05, 0.05);
        const x = r * Math.sin(t) + noise;
        const y = r * Math.cos(t) + noise;
        pts.push([[x, y], [label]]);
      }
    } else if (name === 'linear') {
      for (let i = 0; i < n; i++) {
        const x = rand(-1, 1), y = rand(-1, 1);
        const label = y > 0.3 * x ? 1 : 0;
        pts.push([[x, y], [label]]);
      }
    } else {
      throw new Error('unknown dataset ' + name);
    }
    return pts;
  }

  return { Network, Dense, makeDataset, ACT, randn };
});
