# Nebula — Barnes-Hut Galaxy Simulator

A real-time N-body gravity simulator running entirely in the browser, built from
scratch in vanilla JavaScript + Canvas2D — no frameworks, no build step, no
dependencies. It implements a genuine **Barnes-Hut quadtree** approximation
algorithm (the same class of technique used in production astrophysics
simulators) so it can simulate thousands of mutually-gravitating bodies at
interactive frame rates, instead of the O(n²) brute-force approach most
toy simulators use.

## Highlights

- **Barnes-Hut quadtree** (`physics.mjs`) reduces per-step complexity from
  O(n²) to O(n log n), with a tunable `θ` (theta) opening-angle slider that
  lets you trade accuracy for performance live.
- **Leapfrog-style integrator** with softened gravity to avoid singularities
  on close encounters.
- **Deterministic seeded scenes**: spiral galaxy (central mass + orbiting
  disk), random gravitational cluster, and a binary-star system with an
  orbiting debris ring — all reproducible via a seeded PRNG.
- **Interactive controls**: live body count, simulation speed, θ
  accuracy/performance trade-off, motion trails toggle, zoom (scroll),
  and click-and-drag to fling new massive bodies into the simulation with
  a velocity proportional to your drag.
- **Zero dependencies, zero build step** — it's a static `index.html` plus
  one ES module. Also runs headless in Node for the automated test suite.
- **13 automated tests** (`test.mjs`) covering: deterministic RNG, Newton's
  third law, Barnes-Hut vs. brute-force accuracy, quadtree mass conservation,
  momentum conservation, orbital energy drift bounds, and scene generation
  invariants.

## Run it

No install required.

```bash
# from this directory
python3 -m http.server 8000
# then open http://localhost:8000/ in a browser
```

(Any static file server works — `npx serve`, `php -S`, etc. It must be
served over HTTP rather than opened via `file://` because it uses native
ES module imports.)

## Test

```bash
node test.mjs
```

Expected output: `13 passed, 0 failed`.

## Project layout

- `physics.mjs` — the physics/engine core: vector math, the Barnes-Hut
  quadtree (`buildTree`), the simulation stepper (`step`), a brute-force
  reference stepper for validation, energy/momentum diagnostics, and scene
  generators (`makeGalaxy`).
- `index.html` — canvas renderer, camera (pan/zoom), UI controls, and the
  animation loop. Imports `physics.mjs` directly as an ES module.
- `test.mjs` — dependency-free test suite (plain Node, no test framework
  needed) validating the physics engine's correctness.

## How the Barnes-Hut algorithm works here

Each simulation step builds a quadtree over the current body positions.
Every internal node stores the total mass and center of mass of the bodies
beneath it. When computing the force on a given body, the tree is walked
top-down: if a node is "far enough away" relative to its size (governed by
`θ`), its entire mass is treated as a single point at its center of mass
instead of recursing into every individual body — turning what would be
millions of pairwise checks into a much smaller number of tree traversals.
Lower `θ` values are more accurate (closer to brute force) but slower;
higher values are faster but blurrier. The test suite verifies that at
`θ = 0.4` the approximation tracks brute-force integration to within a
tight tolerance.

## Author

Built by agent A · 19gilad@gmail.com
