// test.mjs — zero-dependency test suite for the Nebula gravity engine.
// Run with: node test.mjs
import {
  step, stepBruteForce, buildTree, gravityForce, totalMomentum, totalEnergy,
  makeGalaxy, makeRng, vecSub, vecLen,
} from './physics.mjs';

let passed = 0, failed = 0;
function assert(cond, msg) {
  if (cond) { passed++; }
  else { failed++; console.error(`✗ FAIL: ${msg}`); }
}
function approx(a, b, eps, msg) {
  assert(Math.abs(a - b) <= eps, `${msg} (got ${a}, expected ~${b}, eps ${eps})`);
}

function cloneBodies(bodies) {
  return bodies.map(b => ({ pos: { ...b.pos }, vel: { ...b.vel }, mass: b.mass }));
}

// --- Test 1: deterministic RNG ---
{
  const r1 = makeRng(42), r2 = makeRng(42);
  const seqA = Array.from({ length: 5 }, () => r1());
  const seqB = Array.from({ length: 5 }, () => r2());
  assert(JSON.stringify(seqA) === JSON.stringify(seqB), 'makeRng is deterministic for a fixed seed');
  assert(seqA.every(v => v >= 0 && v < 1), 'makeRng produces values in [0,1)');
}

// --- Test 2: two-body symmetry (Newton's third law) ---
{
  const a = { pos: { x: 0, y: 0 }, mass: 10 };
  const b = { pos: { x: 100, y: 0 }, mass: 20 };
  const fAB = gravityForce(a, b);
  const fBA = gravityForce(b, a);
  approx(fAB.x, -fBA.x, 1e-9, 'gravityForce is equal and opposite (x)');
  approx(fAB.y, -fBA.y, 1e-9, 'gravityForce is equal and opposite (y)');
  assert(fAB.x > 0, 'gravityForce on a points toward b');
}

// --- Test 3: Barnes-Hut tree approximates brute force for a small cluster ---
{
  const rng = makeRng(7);
  const n = 25;
  const bodies = [];
  for (let i = 0; i < n; i++) {
    bodies.push({ pos: { x: (rng() - 0.5) * 400, y: (rng() - 0.5) * 400 }, vel: { x: 0, y: 0 }, mass: 5 + rng() * 20 });
  }
  const bhBodies = cloneBodies(bodies);
  const bfBodies = cloneBodies(bodies);
  step(bhBodies, 0.5, 0.4); // small theta = closer to exact
  stepBruteForce(bfBodies, 0.5);
  let maxErr = 0;
  for (let i = 0; i < n; i++) {
    const err = vecLen(vecSub(bhBodies[i].pos, bfBodies[i].pos));
    maxErr = Math.max(maxErr, err);
  }
  assert(maxErr < 1.0, `Barnes-Hut (theta=0.4) closely matches brute force, maxErr=${maxErr.toFixed(4)}`);
}

// --- Test 4: quadtree total mass equals sum of body masses ---
{
  const bodies = makeGalaxy({ n: 50, seed: 3 });
  const tree = buildTree(bodies);
  const sumMass = bodies.reduce((s, b) => s + b.mass, 0);
  approx(tree.mass, sumMass, 1e-6, 'quadtree root mass equals total system mass');
}

// --- Test 5: isolated two-body system conserves momentum over many steps ---
{
  const bodies = [
    { pos: { x: -50, y: 0 }, vel: { x: 0, y: -0.4 }, mass: 500 },
    { pos: { x: 50, y: 0 }, vel: { x: 0, y: 0.4 }, mass: 500 },
  ];
  const p0 = totalMomentum(bodies);
  for (let i = 0; i < 200; i++) step(bodies, 0.05, 0.5);
  const p1 = totalMomentum(bodies);
  approx(p1.x, p0.x, 1e-6, 'momentum conserved (x) in isolated 2-body system');
  approx(p1.y, p0.y, 1e-6, 'momentum conserved (y) in isolated 2-body system');
}

// --- Test 6: energy roughly conserved for a stable circular orbit ---
{
  const centralMass = 20000;
  const r = 200;
  const speed = Math.sqrt((6.674e-2 * centralMass) / r);
  const bodies = [
    { pos: { x: 0, y: 0 }, vel: { x: 0, y: 0 }, mass: centralMass },
    { pos: { x: r, y: 0 }, vel: { x: 0, y: speed }, mass: 1 },
  ];
  const e0 = totalEnergy(bodies);
  for (let i = 0; i < 500; i++) step(bodies, 0.02, 0.3);
  const e1 = totalEnergy(bodies);
  const relDrift = Math.abs((e1 - e0) / e0);
  assert(relDrift < 0.05, `orbital energy drift stays bounded over 500 steps (relDrift=${relDrift.toFixed(4)})`);
}

// --- Test 7: makeGalaxy produces the requested body count and finite values ---
{
  const bodies = makeGalaxy({ n: 120, seed: 9 });
  assert(bodies.length === 121, 'makeGalaxy returns n orbiting bodies + 1 central body');
  assert(bodies.every(b => Number.isFinite(b.pos.x) && Number.isFinite(b.pos.y)), 'all galaxy bodies have finite positions');
  assert(bodies.every(b => Number.isFinite(b.vel.x) && Number.isFinite(b.vel.y)), 'all galaxy bodies have finite velocities');
}

console.log(`\n${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
