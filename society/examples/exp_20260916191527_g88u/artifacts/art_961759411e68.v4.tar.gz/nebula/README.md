# Nebula — Barnes-Hut Galaxy Simulator

A real-time N-body gravity simulator running entirely in the browser, built from
scratch in vanilla JavaScript + Canvas2D — no frameworks, no build step, no
dependencies. It implements a genuine **Barnes-Hut quadtree** approximation
algorithm (the same class of technique used in production astrophysics
simulators) so it can simulate thousands of mutually-gravitating bodies at
interactive frame rates, instead of the O(n²) brute-force approach most
toy simulators use.

![Spiral galaxy with 400+ mutually-gravitating bodies, trails on](screenshot.png)

*Live Barnes-Hut quadtree overlay — the tree visibly subdivides where bodies are dense and stays coarse elsewhere:*

![Barnes-Hut quadtree overlay](screenshot-quadtree.png)

## Highlights

- **Barnes-Hut quadtree** (`physics.mjs`) reduces per-step complexity from
  O(n²) to O(n log n), with a tunable `θ` (theta) opening-angle slider that
  lets you trade accuracy for performance live.
- **Leapfrog-style integrator** with softened gravity to avoid singularities
  on close encounters.
- **Deterministic seeded scenes**: spiral galaxy (central mass + orbiting
  disk), random gravitational cluster, and a binary-star system with an
  orbiting debris ring — all reproducible via a seeded PRNG.
- **Live Barnes-Hut tree overlay**: toggle "Show Barnes-Hut tree" to watch
  the actual quadtree used for force approximation redraw every frame,
  subdividing densely where bodies cluster and staying coarse where space
  is empty — a genuine visualization of the algorithm doing its work, not
  just a claim in the README.
- **Physically-realistic accretion**: overlapping bodies merge into a
  single larger body, conserving total mass and momentum (perfectly
  inelastic collision), so galaxies visibly clump into fewer, bigger
  bodies over time. Toggleable.
- **Interactive controls**: live body count, simulation speed, θ
  accuracy/performance trade-off, motion trails toggle, zoom (scroll),
  and click-and-drag to fling new massive bodies into the simulation with
  a velocity proportional to your drag.
- **Zero dependencies, zero build step** — it's a static `index.html` plus
  one ES module. Also runs headless in Node for the automated test suite.
- **20 automated tests** (`test.mjs`) covering: deterministic RNG, Newton's
  third law, Barnes-Hut vs. brute-force accuracy, quadtree mass conservation,
  momentum conservation, orbital energy drift bounds, quadtree bounds
  extraction, collision-merge mass/momentum conservation, and scene
  generation invariants.

## Run it

No install, no server, no build step required:

```bash
# just open it directly in a browser
open index.html         # macOS
xdg-open index.html      # Linux
# or simply double-click index.html in a file browser
```

`index.html` loads `physics.inline.js` — a classic (non-module) script, so it
works straight from `file://` with no CORS/module restrictions and no local
server needed. (A static server also works fine if you prefer one, e.g.
`python3 -m http.server 8000`.)

## Test

```bash
node test.mjs
```

Expected output: `20 passed, 0 failed`.

## Project layout

- `physics.mjs` — the canonical physics/engine core (ES module): vector
  math, the Barnes-Hut quadtree (`buildTree`), the simulation stepper
  (`step`), a brute-force reference stepper for validation, collision
  merging (`resolveCollisions`), quadtree introspection for visualization
  (`collectQuadBounds`), energy/momentum diagnostics, and scene generators
  (`makeGalaxy`). This is what `test.mjs` imports.
- `physics.inline.js` — an auto-generated copy of `physics.mjs` with the
  `export` keywords stripped, loaded by `index.html` as a classic script so
  the page runs with zero server / zero build step over `file://`. Keep it
  in sync with `physics.mjs` if you touch the engine (`sed -e 's/^export
  function/function/' -e 's/^export const/const/' physics.mjs >
  physics.inline.js`).
- `index.html` — canvas renderer, camera (pan/zoom), UI controls (scene
  presets, live sliders, Barnes-Hut tree overlay, collision toggle), and
  the animation loop.
- `test.mjs` — dependency-free test suite (plain Node, no test framework
  needed) validating the physics engine's correctness; imports `physics.mjs`.

## How the Barnes-Hut algorithm works here

Each simulation step builds a quadtree over the current body positions.
Every internal node stores the total mass and center of mass of the bodies
beneath it. When computing the force on a given body, the tree is walked
top-down: if a node is "far enough away" relative to its size (governed by
`θ`), its entire mass is treated as a single point at its center of mass
instead of recursing into every individual body — turning what would be
millions of pairwise checks into a much smaller number of tree traversals.
Lower `θ` values are more accurate (closer to brute force) but slower;
higher values are faster but blurrier. The test suite verifies that at
`θ = 0.4` the approximation tracks brute-force integration to within a
tight tolerance.

## Author

Built by agent A · 19gilad@gmail.com
