// Zero-dependency test suite. Run with: node test.js
'use strict';
const assert = require('assert');
const { bfs, dfs, dijkstra, astar, generateMaze } = require('./algorithms.js');

let passed = 0, failed = 0;
function test(name, fn) {
  try {
    fn();
    console.log('  \x1b[32m✓\x1b[0m ' + name);
    passed++;
  } catch (err) {
    console.log('  \x1b[31m✗\x1b[0m ' + name);
    console.log('    ' + err.message);
    failed++;
  }
}

const openGrid = (rows, cols) => Array.from({ length: rows }, () => Array(cols).fill(0));

console.log('Pathfinding algorithms');
test('bfs finds shortest path on open grid', () => {
  const grid = openGrid(5, 5);
  const { path, found } = bfs(grid, [0, 0], [4, 4]);
  assert.ok(found);
  assert.strictEqual(path.length, 9); // Manhattan distance 8 + start = 9 nodes
});

test('astar finds a path of equal optimal length to bfs on open grid', () => {
  const grid = openGrid(6, 6);
  const a = astar(grid, [0, 0], [5, 5]);
  const b = bfs(grid, [0, 0], [5, 5]);
  assert.ok(a.found && b.found);
  assert.strictEqual(a.path.length, b.path.length);
});

test('dijkstra respects weighted terrain (prefers cheaper route)', () => {
  const grid = openGrid(3, 3);
  const weights = [
    [1, 1, 1],
    [1, 1, 1],
    [1, 1, 1],
  ];
  // Make the direct middle column expensive so it should route around if cheaper
  weights[1][1] = 10;
  const { found, cost } = dijkstra(grid, [0, 1], [2, 1], weights);
  assert.ok(found);
  // Going around (cost 1+1+1+1) should beat going straight through weight-10 cell (1+10)
  assert.ok(cost <= 5, 'expected dijkstra to route around expensive cell, cost=' + cost);
});

test('astar respects weighted terrain just like dijkstra', () => {
  const grid = openGrid(3, 3);
  const weights = [[1, 1, 1], [1, 10, 1], [1, 1, 1]];
  const { found, cost } = astar(grid, [0, 1], [2, 1], weights);
  assert.ok(found);
  assert.ok(cost <= 5, 'expected astar to route around expensive cell, cost=' + cost);
});

test('dfs finds *a* path (not necessarily shortest) when one exists', () => {
  const grid = openGrid(4, 4);
  const { found, path } = dfs(grid, [0, 0], [3, 3]);
  assert.ok(found);
  assert.ok(path.length >= 7);
});

test('returns found:false when target is walled off', () => {
  const grid = openGrid(3, 3);
  grid[0][1] = 1;
  grid[1][1] = 1;
  grid[1][0] = 1; // fully seal off [0][0]
  const { found } = bfs(grid, [0, 0], [2, 2]);
  assert.strictEqual(found, false);
});

console.log('\nMaze generation');
test('generateMaze produces a grid of the requested size', () => {
  const maze = generateMaze(11, 15);
  assert.strictEqual(maze.length, 11);
  assert.strictEqual(maze[0].length, 15);
});

test('generateMaze is solvable from entrance to exit', () => {
  let seed = 42;
  const rng = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return (seed % 10000) / 10000; };
  const maze = generateMaze(15, 15, rng);
  const { found } = bfs(maze, [0, 1], [14, 13]);
  assert.ok(found, 'generated maze should always be solvable');
});

test('generateMaze respects outer walls except entrance/exit', () => {
  const maze = generateMaze(9, 9);
  for (let c = 0; c < 9; c++) {
    if (c !== 1) assert.strictEqual(maze[0][c], 1, 'top row should be wall except entrance');
  }
});

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
