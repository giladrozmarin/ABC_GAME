# 🧭 Pathfinding & Maze Visualizer

An interactive, dependency-free pathfinding and maze-generation visualizer. Draw walls, drag the
start/end nodes, generate a random solvable maze, and watch **BFS**, **DFS**, **Dijkstra**, and
**A\*** explore the grid step by step with live stats (nodes visited, path length, runtime).

The core algorithms live in a single shared, framework-free module (`algorithms.js`) that is used
by both the browser UI (`index.html`) and a Node.js unit test suite (`test.js`) — so the logic you
see animated in the browser is exactly the logic that is tested.

## Features

- **4 algorithms**: Breadth-First Search, Depth-First Search, Dijkstra (weight-aware), A* (Manhattan
  heuristic, also weight-aware).
- **Interactive grid**: click/drag to draw or erase walls, drag the start (🟢) and end (🔴) nodes
  anywhere, right-click (or shift-click) to paint weighted "mud" terrain (cost 5).
- **Maze generator**: recursive-backtracker algorithm, guaranteed solvable (covered by a unit test).
- **Compare All Algorithms**: runs BFS/DFS/Dijkstra/A* on the current grid instantly and renders a
  results table (found?, nodes visited, path steps, path cost, time) with the best values
  highlighted — a great way to *see* why A*/Dijkstra beat DFS on cost, and why BFS/DFS visit more
  nodes than A*.
- **Live visualization**: adjustable speed, animated "visited" wavefront and highlighted shortest
  path, plus a stats bar (nodes visited / path length / path cost / elapsed ms).
- **Zero dependencies, zero build step**: pure HTML/CSS/vanilla JS. Just open `index.html`.
- **Tested core**: 9 unit tests covering correctness of every algorithm (including weighted terrain)
  and the maze generator (`node test.js`), run with plain Node.js `assert` — no test framework
  required.

## Run it

### Web UI (no install needed)
Just open `index.html` in any modern browser (double-click it, or run a static server):

```bash
# option 1: open directly
open index.html        # macOS
xdg-open index.html     # Linux

# option 2: serve it (avoids any local file:// quirks)
npx serve .
# or
python3 -m http.server 8000   # then visit http://localhost:8000
```

### Tests
```bash
npm test
# or
node test.js
```

Expected output: `9 passed, 0 failed`.

## How to use the visualizer

1. Pick an algorithm from the dropdown (A* is selected by default).
2. Click **Generate Maze** for an instant solvable maze, or click/drag on the grid to draw your own
   walls.
3. Drag the green (start) or red (end) cell to reposition them.
4. Click **▶ Visualize** to watch the algorithm explore the grid and reveal the resulting path.
5. Use **Clear Walls** to keep start/end but wipe walls, or **Reset Grid** to start fresh (also lets
   you change grid size).

## Project structure

```
project/
├── algorithms.js   # pure, dependency-free BFS/DFS/Dijkstra/A*/maze-gen (shared by UI + tests)
├── index.html       # interactive UI (grid rendering, drag-to-draw, animation loop)
├── test.js          # zero-dependency unit tests (node:assert)
├── package.json      # `npm test` entry point
└── README.md
```

## Design notes

- `algorithms.js` is written to run unmodified in both Node (`module.exports`) and the browser
  (classic `<script>` tag, top-level `function` declarations become globals) — no bundler needed.
- Dijkstra accepts an optional per-cell weight grid, so it's ready to be extended into a "terrain
  cost" mode (e.g. mud/sand tiles) with no algorithm changes.
- The maze generator carves on odd coordinates (recursive backtracker) and always punches an
  entrance/exit on the border, which a dedicated test verifies stays solvable.

---
Author: 19gilad@gmail.com
