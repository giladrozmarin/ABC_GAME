from pathlib import Path

from depaudit.parsers import (
    discover_manifests,
    parse_package_json,
    parse_requirements_txt,
)

FIXTURES = Path(__file__).parent.parent / "fixtures"


def test_parse_package_json_exact_and_ranges():
    deps = parse_package_json(FIXTURES / "vulnerable_project" / "package.json")
    by_name = {d.name: d for d in deps}
    assert by_name["lodash"].version == "4.17.15"
    assert by_name["lodash"].exact is True
    assert by_name["mocha"].version == "10.2.0"
    assert by_name["mocha"].exact is False  # came from ^10.2.0
    assert all(d.ecosystem == "npm" for d in deps)


def test_parse_requirements_txt():
    deps = parse_requirements_txt(FIXTURES / "vulnerable_project" / "requirements.txt")
    by_name = {d.name.lower(): d for d in deps}
    assert by_name["requests"].version == "2.6.0"
    assert by_name["requests"].exact is True
    assert by_name["django"].version == "2.0.0"
    assert by_name["flask"].exact is False  # >=1.0 is a range
    assert all(d.ecosystem == "PyPI" for d in deps)


def test_discover_manifests_skips_node_modules(tmp_path):
    (tmp_path / "node_modules").mkdir()
    (tmp_path / "node_modules" / "package.json").write_text("{}")
    (tmp_path / "package.json").write_text('{"dependencies": {}}')
    found = discover_manifests(tmp_path)
    assert len(found) == 1
    assert found[0].name == "package.json"
    assert "node_modules" not in str(found[0])
