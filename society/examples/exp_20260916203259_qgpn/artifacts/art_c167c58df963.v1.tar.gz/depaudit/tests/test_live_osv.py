"""Real end-to-end test against the live OSV.dev API (no API key needed).

Skipped automatically if there is no network access, so the default test
suite still passes in a sandboxed/offline CI environment. Run explicitly
with:  pytest tests/test_live_osv.py -m live
"""
from pathlib import Path

import pytest
import requests

from depaudit.scanner import scan_path

FIXTURES = Path(__file__).parent.parent / "fixtures"

pytestmark = pytest.mark.live


def _osv_reachable() -> bool:
    try:
        requests.get("https://api.osv.dev/v1/vulns/GHSA-29mw-wpgm-hmr9", timeout=5)
        return True
    except requests.RequestException:
        return False


@pytest.mark.skipif(not _osv_reachable(), reason="OSV.dev not reachable from this environment")
def test_lodash_4_17_15_is_flagged_vulnerable_by_real_osv():
    result = scan_path(FIXTURES / "vulnerable_project")
    lodash = next(f for f in result.findings if f.dependency.name == "lodash")
    assert len(lodash.vulns) > 0
    assert lodash.worst_severity in {"CRITICAL", "HIGH", "MEDIUM", "LOW"}


@pytest.mark.skipif(not _osv_reachable(), reason="OSV.dev not reachable from this environment")
def test_clean_project_has_no_findings():
    result = scan_path(FIXTURES / "clean_project")
    assert result.vulnerable_findings == []
