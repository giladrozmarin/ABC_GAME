from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .report import render_console, render_markdown
from .scanner import SEVERITY_ORDER, scan_path

EXIT_OK = 0
EXIT_VULNERABLE = 1
EXIT_ERROR = 2


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="depaudit",
        description=(
            "Scan a project's package.json / requirements.txt files for known "
            "vulnerabilities using the OSV.dev database, with no API key "
            "required."
        ),
    )
    p.add_argument("path", nargs="?", default=".", help="Directory to scan (default: current directory)")
    p.add_argument(
        "--format", choices=["console", "markdown"], default="console", help="Output format"
    )
    p.add_argument("--out", help="Write report to this file instead of stdout")
    p.add_argument(
        "--fail-on",
        choices=["CRITICAL", "HIGH", "MEDIUM", "LOW", "NEVER"],
        default="HIGH",
        help=(
            "Exit with a non-zero status if a finding at or above this "
            "severity is found (default: HIGH). Use NEVER for exit code 0 always."
        ),
    )
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    root = Path(args.path).resolve()
    if not root.exists():
        print(f"error: path does not exist: {root}", file=sys.stderr)
        return EXIT_ERROR

    try:
        result = scan_path(root)
    except Exception as exc:  # network errors, etc. - fail loudly but clearly
        print(f"error: scan failed: {exc}", file=sys.stderr)
        return EXIT_ERROR

    render = render_markdown if args.format == "markdown" else render_console
    output = render(result)

    if args.out:
        Path(args.out).write_text(output + "\n")
        print(f"Report written to {args.out}")
    else:
        print(output)

    if args.fail_on == "NEVER":
        return EXIT_OK

    threshold = SEVERITY_ORDER[args.fail_on]
    for f in result.vulnerable_findings:
        if SEVERITY_ORDER.get(f.worst_severity, 9) <= threshold:
            return EXIT_VULNERABLE
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
