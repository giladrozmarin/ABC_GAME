"""Thin client for the OSV.dev vulnerability database (https://osv.dev).

No API key required. Two endpoints are used:
  - POST /v1/querybatch  -> cheap batch lookup returning vuln ids per query
  - POST /v1/vulns/{id}  -> full details (summary, severity, fixed ranges)

We batch the detail lookups too (OSV has no batch-details endpoint, so we
just issue one GET per unique vuln id found - typically a small number).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import requests

BATCH_URL = "https://api.osv.dev/v1/querybatch"
VULN_URL = "https://api.osv.dev/v1/vulns/{id}"

# OSV requests recommend batching in chunks; keep well under limits.
CHUNK_SIZE = 100


@dataclass
class Vuln:
    id: str
    summary: str = ""
    severity: str = "UNKNOWN"
    cvss_score: Optional[float] = None
    fixed_versions: List[str] = field(default_factory=list)
    aliases: List[str] = field(default_factory=list)
    url: str = ""


_DB_SEVERITY_ALIASES = {
    "CRITICAL": "CRITICAL",
    "SEVERE": "HIGH",
    "HIGH": "HIGH",
    "MODERATE": "MEDIUM",
    "MEDIUM": "MEDIUM",
    "LOW": "LOW",
    "MINOR": "LOW",
}


def _normalize_severity(raw: str) -> str:
    return _DB_SEVERITY_ALIASES.get(raw.upper(), "UNKNOWN")


def _severity_from_score(score: float) -> str:
    if score >= 9.0:
        return "CRITICAL"
    if score >= 7.0:
        return "HIGH"
    if score >= 4.0:
        return "MEDIUM"
    if score > 0:
        return "LOW"
    return "UNKNOWN"


def query_batch(queries: List[dict], session: Optional[requests.Session] = None) -> List[List[str]]:
    """queries: list of {"package": {"name":..., "ecosystem":...}, "version":...}
    returns: list (same order) of lists of vuln ids.
    """
    session = session or requests.Session()
    results: List[List[str]] = []
    for i in range(0, len(queries), CHUNK_SIZE):
        chunk = queries[i : i + CHUNK_SIZE]
        resp = session.post(BATCH_URL, json={"queries": chunk}, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        for r in data.get("results", []):
            results.append([v["id"] for v in r.get("vulns", [])])
    return results


def fetch_vuln_details(vuln_ids: List[str], session: Optional[requests.Session] = None) -> Dict[str, Vuln]:
    session = session or requests.Session()
    out: Dict[str, Vuln] = {}
    for vid in vuln_ids:
        if vid in out:
            continue
        resp = session.get(VULN_URL.format(id=vid), timeout=30)
        if resp.status_code != 200:
            out[vid] = Vuln(id=vid, summary="(details unavailable)")
            continue
        data = resp.json()
        score = None
        severity = "UNKNOWN"
        for sev in data.get("severity", []) or []:
            if sev.get("type") == "CVSS_V3":
                # score field is a vector string sometimes; try numeric score key
                try:
                    score = float(sev.get("score"))
                except (TypeError, ValueError):
                    score = None
        db_severity = (data.get("database_specific") or {}).get("severity")
        if score is not None:
            severity = _severity_from_score(score)
        elif db_severity:
            severity = _normalize_severity(str(db_severity))

        fixed_versions: List[str] = []
        for affected in data.get("affected", []) or []:
            for rng in affected.get("ranges", []) or []:
                for ev in rng.get("events", []) or []:
                    if "fixed" in ev:
                        fixed_versions.append(ev["fixed"])
            for vers in affected.get("versions", []) or []:
                pass  # exact enumerated versions, not useful as "fixed"

        out[vid] = Vuln(
            id=vid,
            summary=(data.get("summary") or data.get("details") or "").strip().splitlines()[0][:200]
            if (data.get("summary") or data.get("details"))
            else "",
            severity=severity,
            cvss_score=score,
            fixed_versions=sorted(set(fixed_versions)),
            aliases=data.get("aliases", []) or [],
            url=f"https://osv.dev/vulnerability/{vid}",
        )
    return out
