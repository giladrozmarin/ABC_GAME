from __future__ import annotations

from .scanner import SEVERITY_ORDER, ScanResult

SEVERITY_EMOJI = {
    "CRITICAL": "[CRIT]",
    "HIGH": "[HIGH]",
    "MEDIUM": "[MED] ",
    "LOW": "[LOW] ",
    "UNKNOWN": "[????]",
}


def render_console(result: ScanResult) -> str:
    lines = []
    lines.append("depaudit report")
    lines.append("=" * 60)
    if not result.manifests_scanned:
        lines.append("No package.json or requirements.txt files found.")
        return "\n".join(lines)

    lines.append(f"Manifests scanned ({len(result.manifests_scanned)}):")
    for m in result.manifests_scanned:
        lines.append(f"  - {m}")
    lines.append("")
    lines.append(f"Dependencies checked: {len(result.dependencies)}")

    approx = [d for d in result.dependencies if not d.exact]
    if approx:
        lines.append(
            f"  ({len(approx)} used an approximate/resolved version because the "
            f"manifest specified a range like ^1.2.3 - actual installed "
            f"version may differ; run against a lockfile for full accuracy)"
        )

    vulnerable = result.vulnerable_findings
    counts = result.severity_counts()
    lines.append("")
    lines.append(
        f"Vulnerable dependencies: {len(vulnerable)} / {len(result.dependencies)}"
    )
    counts_str = "  ".join(f"{k}: {v}" for k, v in counts.items() if v)
    lines.append("  " + (counts_str if counts_str else "none"))
    lines.append("")

    vulnerable_sorted = sorted(
        vulnerable, key=lambda f: SEVERITY_ORDER.get(f.worst_severity, 9)
    )
    for f in vulnerable_sorted:
        d = f.dependency
        approx_tag = " (approx. version)" if not d.exact else ""
        lines.append(f"{d.name}@{d.version} [{d.ecosystem}]{approx_tag}  <- {d.source_file}")
        for v in f.vulns:
            fix = f"fixed in {', '.join(v.fixed_versions)}" if v.fixed_versions else "no fix published yet"
            summary = f" - {v.summary}" if v.summary else ""
            lines.append(f"    {SEVERITY_EMOJI.get(v.severity, v.severity)} {v.id} ({fix}){summary}")
            lines.append(f"           {v.url}")
        lines.append("")

    if not vulnerable:
        lines.append("No known vulnerabilities found for the resolved versions. Nice.")

    return "\n".join(lines)


def render_markdown(result: ScanResult) -> str:
    lines = ["# depaudit report", ""]
    if not result.manifests_scanned:
        lines.append("No `package.json` or `requirements.txt` files found.")
        return "\n".join(lines)

    lines.append(f"**Manifests scanned:** {len(result.manifests_scanned)}  ")
    for m in result.manifests_scanned:
        lines.append(f"- `{m}`")
    lines.append("")
    lines.append(f"**Dependencies checked:** {len(result.dependencies)}  ")

    vulnerable = result.vulnerable_findings
    counts = result.severity_counts()
    lines.append(f"**Vulnerable dependencies:** {len(vulnerable)}")
    lines.append("")
    lines.append("| Severity | Count |")
    lines.append("|---|---|")
    for k in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "UNKNOWN"):
        if counts.get(k):
            lines.append(f"| {k} | {counts[k]} |")
    lines.append("")

    if vulnerable:
        lines.append("## Findings")
        lines.append("")
        for f in sorted(vulnerable, key=lambda f: SEVERITY_ORDER.get(f.worst_severity, 9)):
            d = f.dependency
            approx_tag = " *(approximate version)*" if not d.exact else ""
            lines.append(f"### `{d.name}@{d.version}` ({d.ecosystem}){approx_tag}")
            lines.append(f"_source: `{d.source_file}`_")
            lines.append("")
            for v in f.vulns:
                fix = f"fixed in `{', '.join(v.fixed_versions)}`" if v.fixed_versions else "**no fix published yet**"
                lines.append(f"- **{v.severity}** [`{v.id}`]({v.url}) - {fix}")
                if v.summary:
                    lines.append(f"  - {v.summary}")
            lines.append("")
    else:
        lines.append("No known vulnerabilities found for the resolved versions.")

    return "\n".join(lines)
