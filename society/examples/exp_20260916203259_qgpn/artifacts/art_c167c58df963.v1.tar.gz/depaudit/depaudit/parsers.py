"""Parsers that extract (name, version, ecosystem, exact) tuples from
common manifest files.

`exact=True` means the version string is a pinned, exact version we can
query with full confidence. `exact=False` means we had to guess a
concrete version out of a range specifier (e.g. "^1.2.3" -> "1.2.3"); the
report clearly flags these as approximate so users aren't misled.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List


@dataclass
class Dependency:
    name: str
    version: str
    ecosystem: str  # "npm" or "PyPI"
    exact: bool
    source_file: str


_RANGE_PREFIX_RE = re.compile(r"^[\^~>=<\s]+")


def _clean_npm_version(spec: str) -> tuple[str, bool]:
    spec = spec.strip()
    exact = bool(re.match(r"^\d+\.\d+\.\d+", spec))
    cleaned = _RANGE_PREFIX_RE.sub("", spec)
    # strip anything after a space (e.g. "1.2.3 || 2.0.0") - take first
    cleaned = cleaned.split("||")[0].split(" ")[0].strip()
    if not re.match(r"^\d+\.\d+\.\d+", cleaned):
        return "", False
    return cleaned, exact


def parse_package_json(path: Path) -> List[Dependency]:
    data = json.loads(path.read_text())
    deps: List[Dependency] = []
    for section in ("dependencies", "devDependencies", "optionalDependencies"):
        for name, spec in (data.get(section) or {}).items():
            if not isinstance(spec, str):
                continue
            if spec.startswith(("git+", "http", "file:", "workspace:", "link:")):
                continue  # not resolvable to a registry version
            version, exact = _clean_npm_version(spec)
            if not version:
                continue
            deps.append(Dependency(name, version, "npm", exact, str(path)))
    return deps


_REQ_LINE_RE = re.compile(
    r"^\s*([A-Za-z0-9_.\-\[\]]+)\s*(==|>=|<=|~=|!=|>|<)\s*([0-9][A-Za-z0-9_.\-]*)"
)


def parse_requirements_txt(path: Path) -> List[Dependency]:
    deps: List[Dependency] = []
    for raw_line in path.read_text().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        line = line.split(";")[0].split("#")[0].strip()
        m = _REQ_LINE_RE.match(line)
        if not m:
            continue
        name, op, version = m.groups()
        name = name.split("[")[0]  # drop extras like package[extra]
        deps.append(Dependency(name, version, "PyPI", op == "==", str(path)))
    return deps


def discover_manifests(root: Path) -> List[Path]:
    found = []
    for pattern in ("package.json", "requirements.txt"):
        found.extend(sorted(root.rglob(pattern)))
    # skip node_modules / venv noise
    return [
        p
        for p in found
        if not any(
            part in {"node_modules", ".venv", "venv", "site-packages", "dist", "build"}
            for part in p.parts
        )
    ]


def parse_manifest(path: Path) -> List[Dependency]:
    if path.name == "package.json":
        return parse_package_json(path)
    if path.name == "requirements.txt":
        return parse_requirements_txt(path)
    return []
