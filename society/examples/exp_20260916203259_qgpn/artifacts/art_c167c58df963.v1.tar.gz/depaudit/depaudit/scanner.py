from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from . import osv
from .parsers import Dependency, discover_manifests, parse_manifest

SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}


@dataclass
class Finding:
    dependency: Dependency
    vulns: List[osv.Vuln] = field(default_factory=list)

    @property
    def worst_severity(self) -> str:
        if not self.vulns:
            return "NONE"
        return min((v.severity for v in self.vulns), key=lambda s: SEVERITY_ORDER.get(s, 9))


@dataclass
class ScanResult:
    manifests_scanned: List[str]
    dependencies: List[Dependency]
    findings: List[Finding]

    @property
    def vulnerable_findings(self) -> List[Finding]:
        return [f for f in self.findings if f.vulns]

    def severity_counts(self) -> dict:
        counts = {k: 0 for k in SEVERITY_ORDER}
        for f in self.vulnerable_findings:
            counts[f.worst_severity] += 1
        return counts


def scan_path(root: Path, session=None) -> ScanResult:
    manifests = discover_manifests(root)
    deps: List[Dependency] = []
    for m in manifests:
        deps.extend(parse_manifest(m))

    # de-dupe identical (name, version, ecosystem) across files but keep first source
    seen = {}
    unique_deps: List[Dependency] = []
    for d in deps:
        key = (d.name.lower(), d.version, d.ecosystem)
        if key in seen:
            continue
        seen[key] = True
        unique_deps.append(d)

    queries = [
        {"package": {"name": d.name, "ecosystem": d.ecosystem}, "version": d.version}
        for d in unique_deps
    ]

    findings: List[Finding] = []
    if unique_deps:
        batch_results = osv.query_batch(queries, session=session)
        all_ids = sorted({vid for ids in batch_results for vid in ids})
        details = osv.fetch_vuln_details(all_ids, session=session) if all_ids else {}
        for dep, ids in zip(unique_deps, batch_results):
            vulns = [details[i] for i in ids if i in details]
            vulns.sort(key=lambda v: SEVERITY_ORDER.get(v.severity, 9))
            findings.append(Finding(dependency=dep, vulns=vulns))
    else:
        findings = []

    return ScanResult(
        manifests_scanned=[str(m) for m in manifests],
        dependencies=unique_deps,
        findings=findings,
    )
