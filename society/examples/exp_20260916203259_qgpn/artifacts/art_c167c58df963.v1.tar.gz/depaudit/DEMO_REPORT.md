# depaudit report

**Manifests scanned:** 2  
- `/home/user/ABC_GAME/society/experiments/exp_20260916203259_qgpn/workspaces/D/depaudit/fixtures/vulnerable_project/package.json`
- `/home/user/ABC_GAME/society/experiments/exp_20260916203259_qgpn/workspaces/D/depaudit/fixtures/vulnerable_project/requirements.txt`

**Dependencies checked:** 6  
**Vulnerable dependencies:** 4

| Severity | Count |
|---|---|
| CRITICAL | 1 |
| HIGH | 3 |

## Findings

### `Django@2.0.0` (PyPI)
_source: `/home/user/ABC_GAME/society/experiments/exp_20260916203259_qgpn/workspaces/D/depaudit/fixtures/vulnerable_project/requirements.txt`_

- **CRITICAL** [`GHSA-frmv-pr5f-9mcr`](https://osv.dev/vulnerability/GHSA-frmv-pr5f-9mcr) - fixed in `4.2.26, 5.1.14, 5.2.8`
  - Django vulnerable to SQL injection via _connector keyword argument in QuerySet and Q objects.
- **CRITICAL** [`GHSA-hmr4-m2h5-33qx`](https://osv.dev/vulnerability/GHSA-hmr4-m2h5-33qx) - fixed in `1.11.28, 2.2.10, 3.0.3`
  - SQL injection in Django
- **CRITICAL** [`GHSA-vfq6-hq5r-27r6`](https://osv.dev/vulnerability/GHSA-vfq6-hq5r-27r6) - fixed in `1.11.27, 2.2.9, 3.0.1`
  - Django Potential account hijack via password reset form
- **HIGH** [`GHSA-337x-4q8g-prc5`](https://osv.dev/vulnerability/GHSA-337x-4q8g-prc5) - fixed in `1.11.18, 2.0.10, 2.1.5`
  - Improper Input Validation in Django
- **HIGH** [`GHSA-6w2r-r2m5-xq5w`](https://osv.dev/vulnerability/GHSA-6w2r-r2m5-xq5w) - fixed in `4.2.24, 5.1.12, 5.2.6`
  - Django is subject to SQL injection through its column aliases
- **HIGH** [`GHSA-8x94-hmjh-97hq`](https://osv.dev/vulnerability/GHSA-8x94-hmjh-97hq) - fixed in `3.2.15, 4.0.7`
  - Django vulnerable to Reflected File Download attack
- **HIGH** [`GHSA-qw25-v68c-qjf3`](https://osv.dev/vulnerability/GHSA-qw25-v68c-qjf3) - fixed in `4.2.26, 5.1.14, 5.2.8`
  - Django has a denial-of-service vulnerability in HttpResponseRedirect and HttpResponsePermanentRedirect on Windows
- **HIGH** [`GHSA-rf4j-j272-fj86`](https://osv.dev/vulnerability/GHSA-rf4j-j272-fj86) - fixed in `1.11.10, 2.0.2`
  - Django vulnerable to information leakage in AuthenticationForm
- **HIGH** [`GHSA-wh4h-v3f2-r2pp`](https://osv.dev/vulnerability/GHSA-wh4h-v3f2-r2pp) - fixed in `1.11.19, 2.0.11, 2.1.6`
  - Uncontrolled Memory Consumption in Django
- **MEDIUM** [`GHSA-5hg3-6c2f-f3wr`](https://osv.dev/vulnerability/GHSA-5hg3-6c2f-f3wr) - fixed in `1.11.15, 2.0.8`
  - Django open redirect
- **MEDIUM** [`GHSA-68w8-qjq3-2gfm`](https://osv.dev/vulnerability/GHSA-68w8-qjq3-2gfm) - fixed in `2.2.24, 3.1.12, 3.2.4`
  - Path Traversal in Django
- **MEDIUM** [`GHSA-6c3j-c64m-qhgq`](https://osv.dev/vulnerability/GHSA-6c3j-c64m-qhgq) - fixed in `1.19.0, 2.1.9, 2.2.2, 3.4.0, 4.3.4`
  - XSS in jQuery as used in Drupal, Backdrop CMS, and other products
- **MEDIUM** [`GHSA-7xr5-9hcq-chf9`](https://osv.dev/vulnerability/GHSA-7xr5-9hcq-chf9) - fixed in `4.2.22, 5.1.10, 5.2.2`
  - Django Improper Output Neutralization for Logs vulnerability
- **MEDIUM** [`GHSA-8qcx-xf44-272x`](https://osv.dev/vulnerability/GHSA-8qcx-xf44-272x) - fixed in `5.2.16, 6.0.7`
  - Django: DomainNameValidator permits newline characters that may enable HTTP header injection
- **MEDIUM** [`GHSA-crhf-3pfg-w68w`](https://osv.dev/vulnerability/GHSA-crhf-3pfg-w68w) - fixed in `5.2.16, 6.0.7`
  - Django: GDALRaster may over-read heap memory when constructed from bytes
- **MEDIUM** [`GHSA-r28v-mw67-m5p9`](https://osv.dev/vulnerability/GHSA-r28v-mw67-m5p9) - fixed in `1.11.11, 1.8.19, 2.0.3`
  - Django denial-of-service possibility in urlize and urlizetrunc template filters
- **MEDIUM** [`GHSA-rrqc-c2jx-6jgv`](https://osv.dev/vulnerability/GHSA-rrqc-c2jx-6jgv) - fixed in `4.2.16, 5.0.9, 5.1.1`
  - Django allows enumeration of user e-mail addresses
- **LOW** [`GHSA-2f9x-5v75-3qv4`](https://osv.dev/vulnerability/GHSA-2f9x-5v75-3qv4) - fixed in `1.11.11, 1.8.19, 2.0.3`
  - Django Denial-of-service possibility in truncatechars_html and truncatewords_html template filters
- **LOW** [`GHSA-3h9f-r86x-qvjx`](https://osv.dev/vulnerability/GHSA-3h9f-r86x-qvjx) - fixed in `5.2.16, 6.0.7`
  - Django: cache middleware may expose private responses when unrelated request cookies are present
- **LOW** [`GHSA-8cjm-8mp7-r2xf`](https://osv.dev/vulnerability/GHSA-8cjm-8mp7-r2xf) - fixed in `5.2.15, 6.0.6`
  - Django: UpdateCacheMiddleware may disclose cached responses due to case-sensitive Cache-Control handling
- **LOW** [`GHSA-923m-gv2p-w5qp`](https://osv.dev/vulnerability/GHSA-923m-gv2p-w5qp) - fixed in `5.2.15, 6.0.6`
  - Django: has_vary_header may expose cached responses when Vary values contain whitespace
- **LOW** [`GHSA-h7pc-vwp9-298g`](https://osv.dev/vulnerability/GHSA-h7pc-vwp9-298g) - fixed in `5.2.15, 6.0.6`
  - Django: signed cookies are vulnerable to salt namespace collisions
- **UNKNOWN** [`PYSEC-2018-2`](https://osv.dev/vulnerability/PYSEC-2018-2) - fixed in `1.11.15, 2.0.8`
  - django.middleware.common.CommonMiddleware in Django 1.11.x before 1.11.15 and 2.0.x before 2.0.8 has an Open Redirect.
- **UNKNOWN** [`PYSEC-2018-4`](https://osv.dev/vulnerability/PYSEC-2018-4) - fixed in `2.0.2`
  - django.contrib.auth.forms.AuthenticationForm in Django 2.0 before 2.0.2, and 1.11.8 and 1.11.9, allows remote attackers to obtain potentially sensitive information by leveraging data exposure from the
- **UNKNOWN** [`PYSEC-2018-5`](https://osv.dev/vulnerability/PYSEC-2018-5) - fixed in `1.11.11, 1.8.19, 2.0.3`
  - An issue was discovered in Django 2.0 before 2.0.3, 1.11 before 1.11.11, and 1.8 before 1.8.19. The django.utils.html.urlize() function was extremely slow to evaluate certain inputs due to catastrophi
- **UNKNOWN** [`PYSEC-2018-6`](https://osv.dev/vulnerability/PYSEC-2018-6) - fixed in `1.11.11, 1.8.19, 2.0.3`
  - An issue was discovered in Django 2.0 before 2.0.3, 1.11 before 1.11.11, and 1.8 before 1.8.19. If django.utils.text.Truncator's chars() and words() methods were passed the html=True argument, they we
- **UNKNOWN** [`PYSEC-2019-17`](https://osv.dev/vulnerability/PYSEC-2019-17) - fixed in `1.11.18, 2.0.10, 2.1.5`
  - In Django 1.11.x before 1.11.18, 2.0.x before 2.0.10, and 2.1.x before 2.1.5, an Improper Neutralization of Special Elements in Output Used by a Downstream Component issue exists in django.views.defau
- **UNKNOWN** [`PYSEC-2019-18`](https://osv.dev/vulnerability/PYSEC-2019-18) - fixed in `1.11.19, 2.0.12, 2.1.7`
  - Django 1.11.x before 1.11.19, 2.0.x before 2.0.11, and 2.1.x before 2.1.6 allows Uncontrolled Memory Consumption via a malicious attacker-supplied value to the django.utils.numberformat.format() funct
- **UNKNOWN** [`PYSEC-2021-98`](https://osv.dev/vulnerability/PYSEC-2021-98) - fixed in `2.2.24, 3.1.12, 3.2.4`
  - Django before 2.2.24, 3.x before 3.1.12, and 3.2.x before 3.2.4 has a potential directory traversal via django.contrib.admindocs. Staff members could use the TemplateDetailView view to check the exist
- **UNKNOWN** [`PYSEC-2026-1297`](https://osv.dev/vulnerability/PYSEC-2026-1297) - fixed in `4.2.16, 5.0.9, 5.1.1`
  - Django allows enumeration of user e-mail addresses
- **UNKNOWN** [`PYSEC-2026-3717`](https://osv.dev/vulnerability/PYSEC-2026-3717) - fixed in `5.2.17, 6.0.8`
  - An issue was discovered in Django 5.2 before 5.2.17 and 6.0 before 6.0.8.
- **UNKNOWN** [`PYSEC-2026-628`](https://osv.dev/vulnerability/PYSEC-2026-628) - fixed in `2.1.9, 2.2.2`
  - XSS in jQuery as used in Drupal, Backdrop CMS, and other products

### `lodash@4.17.15` (npm)
_source: `/home/user/ABC_GAME/society/experiments/exp_20260916203259_qgpn/workspaces/D/depaudit/fixtures/vulnerable_project/package.json`_

- **HIGH** [`GHSA-35jh-r3h4-6jhm`](https://osv.dev/vulnerability/GHSA-35jh-r3h4-6jhm) - fixed in `4.17.21`
  - Command Injection in lodash
- **HIGH** [`GHSA-p6mc-m468-83gw`](https://osv.dev/vulnerability/GHSA-p6mc-m468-83gw) - fixed in `4.17.19, 4.17.20`
  - Prototype Pollution in lodash
- **HIGH** [`GHSA-r5fr-rjxr-66jc`](https://osv.dev/vulnerability/GHSA-r5fr-rjxr-66jc) - fixed in `4.18.0`
  - lodash vulnerable to Code Injection via `_.template` imports key names
- **MEDIUM** [`GHSA-29mw-wpgm-hmr9`](https://osv.dev/vulnerability/GHSA-29mw-wpgm-hmr9) - fixed in `4.17.21`
  - Regular Expression Denial of Service (ReDoS) in lodash
- **MEDIUM** [`GHSA-f23m-r3pf-42rh`](https://osv.dev/vulnerability/GHSA-f23m-r3pf-42rh) - fixed in `4.18.0`
  - lodash vulnerable to Prototype Pollution via array path bypass in `_.unset` and `_.omit`
- **MEDIUM** [`GHSA-xxjr-mmjv-4gpg`](https://osv.dev/vulnerability/GHSA-xxjr-mmjv-4gpg) - fixed in `4.17.23`
  - Lodash has Prototype Pollution Vulnerability in `_.unset` and `_.omit` functions

### `requests@2.6.0` (PyPI)
_source: `/home/user/ABC_GAME/society/experiments/exp_20260916203259_qgpn/workspaces/D/depaudit/fixtures/vulnerable_project/requirements.txt`_

- **HIGH** [`GHSA-x84v-xcm2-53pg`](https://osv.dev/vulnerability/GHSA-x84v-xcm2-53pg) - fixed in `2.20.0`
  - Insufficiently Protected Credentials in Requests
- **MEDIUM** [`GHSA-9hjg-9r4m-mvj7`](https://osv.dev/vulnerability/GHSA-9hjg-9r4m-mvj7) - fixed in `2.32.4`
  - Requests vulnerable to .netrc credentials leak via malicious URLs
- **MEDIUM** [`GHSA-9wx4-h78v-vm56`](https://osv.dev/vulnerability/GHSA-9wx4-h78v-vm56) - fixed in `2.32.0`
  - Requests `Session` object does not verify requests after making first request with verify=False
- **MEDIUM** [`GHSA-gc5v-m9x4-r6x2`](https://osv.dev/vulnerability/GHSA-gc5v-m9x4-r6x2) - fixed in `2.33.0`
  - Requests has Insecure Temp File Reuse in its extract_zipped_paths() utility function
- **MEDIUM** [`GHSA-j8r2-6x86-q33q`](https://osv.dev/vulnerability/GHSA-j8r2-6x86-q33q) - fixed in `2.31.0`
  - Unintended leak of Proxy-Authorization header in requests
- **UNKNOWN** [`PYSEC-2018-28`](https://osv.dev/vulnerability/PYSEC-2018-28) - fixed in `2.20.0, c45d7c49ea75133e52ab22a8e9e13173938e36ff`
  - The Requests package before 2.20.0 for Python sends an HTTP Authorization header to an http URI upon receiving a same-hostname https-to-http redirect, which makes it easier for remote attackers to dis
- **UNKNOWN** [`PYSEC-2023-74`](https://osv.dev/vulnerability/PYSEC-2023-74) - fixed in `2.31.0, 74ea7cf7a6a27a4eeb2ae24e162bcc942a6706d5`
  - Requests is a HTTP library. Since Requests 2.3.0, Requests has been leaking Proxy-Authorization headers to destination servers when redirected to an HTTPS endpoint. This is a product of how we use `re
- **UNKNOWN** [`PYSEC-2026-1872`](https://osv.dev/vulnerability/PYSEC-2026-1872) - fixed in `2.32.4`
  - Requests vulnerable to .netrc credentials leak via malicious URLs
- **UNKNOWN** [`PYSEC-2026-1873`](https://osv.dev/vulnerability/PYSEC-2026-1873) - fixed in `2.32.0`
  - Requests `Session` object does not verify requests after making first request with verify=False
- **UNKNOWN** [`PYSEC-2026-2275`](https://osv.dev/vulnerability/PYSEC-2026-2275) - fixed in `2.33.0`
  - Requests is a HTTP library. Prior to version 2.33.0, the `requests.utils.extract_zipped_paths()` utility function uses a predictable filename when extracting files from zip archives into the system te

### `flask@1.0` (PyPI) *(approximate version)*
_source: `/home/user/ABC_GAME/society/experiments/exp_20260916203259_qgpn/workspaces/D/depaudit/fixtures/vulnerable_project/requirements.txt`_

- **HIGH** [`GHSA-m2qf-hxjv-5gpq`](https://osv.dev/vulnerability/GHSA-m2qf-hxjv-5gpq) - fixed in `2.2.5, 2.3.2`
  - Flask vulnerable to possible disclosure of permanent session cookie due to missing Vary: Cookie header
- **LOW** [`GHSA-68rp-wp8r-4726`](https://osv.dev/vulnerability/GHSA-68rp-wp8r-4726) - fixed in `3.1.3`
  - Flask session does not add `Vary: Cookie` header when accessed in some ways
- **UNKNOWN** [`PYSEC-2023-62`](https://osv.dev/vulnerability/PYSEC-2023-62) - fixed in `2.2.5, 2.3.2, 70f906c51ce49c485f1d355703e9cc3386b1cc2b, afd63b16170b7c047f5758eb910c416511e9c965`
  - Flask is a lightweight WSGI web application framework. When all of the following conditions are met, a response containing data intended for one client may be cached and subsequently sent by the proxy
- **UNKNOWN** [`PYSEC-2026-2151`](https://osv.dev/vulnerability/PYSEC-2026-2151) - fixed in `3.1.3`
  - Flask is a web server gateway interface (WSGI) web application framework. In versions 3.1.2 and below, when the session object is accessed, Flask should set the Vary: Cookie header., resulting in a Us

