# depaudit

**A dependency vulnerability scanner for developers, with no API key, no
sign-up, and no lock-in to a specific SaaS.**

## Who this is for

Any developer or small team who wants to answer "are any of the packages
listed in my `package.json` / `requirements.txt` known-vulnerable?" *before*
committing, shipping, or doing a security review — without installing a
heavyweight SaaS agent, creating an account, or sending code anywhere.
Think: a solo developer doing due diligence on a client project, a student
checking a course repo, or a CI pipeline that wants a quick free gate.

## The concrete problem it solves

- `npm audit` / `pip-audit` exist, but they require you to actually install
  the dependencies first (full `npm install` / a resolved venv). If you just
  cloned a repo, or you're reviewing someone else's `package.json` before
  deciding whether to even install it, there's no quick way to check.
- GitHub Dependabot requires you to push the repo to GitHub and enable a
  feature; not everyone wants that, and it doesn't work on an arbitrary local
  folder.
- Commercial tools (Snyk, etc.) require accounts, tokens, and often rate-limit
  or paywall real usage.

`depaudit` reads the manifest file directly (no install step), asks the free,
public [OSV.dev](https://osv.dev) vulnerability database (Google-run,
aggregates GHSA/PYSEC/NVD/etc., no API key required) whether each declared
version has known vulnerabilities, and prints a clear, actionable report:
severity, a one-line summary, the exact version that fixes it, and a link to
full details. It also sets a non-zero exit code so it's immediately usable as
a CI gate.

## What it actually does (and its honest limitations)

- Supports **npm** (`package.json`: dependencies, devDependencies,
  optionalDependencies; and `package-lock.json` v1/v2/v3 for exact resolved
  versions) and **Python** (`requirements.txt`).
- Recursively scans a directory for these files (skipping `node_modules`,
  `venv`, etc). When both `package.json` and `package-lock.json` exist in the
  same directory, depaudit automatically prefers the lockfile's exact
  resolved versions over the manifest's version ranges.
- Queries the real OSV.dev API for every unique `(name, version, ecosystem)`
  pair, then fetches full vulnerability details (severity, fixed version,
  summary, link) for every vulnerability id found.
- **Limitation — version ranges are approximated.** If your `package.json`
  says `"lodash": "^4.17.15"`, depaudit checks the *literal* version
  `4.17.15` written in the manifest, not whatever your lockfile actually
  resolved to. This is clearly flagged in the report as "(approximate
  version)" — depaudit does not silently pretend to know what you have
  installed. For maximum accuracy, pin exact versions or point depaudit at a
  resolved manifest.
- **Limitation — Python lockfiles not supported yet** (`poetry.lock`,
  `Pipfile.lock`). npm's `package-lock.json` *is* supported (see above); the
  parser is isolated in `depaudit/parsers.py` so adding another lockfile
  format is a small, contained change.
- **Limitation — transitive dependencies are not resolved.** Only what's
  literally declared in the manifest is checked (this is also true of
  reading any manifest without installing).
- Severity comes straight from OSV/GHSA CVSS scores or database-provided
  severity, normalized to CRITICAL/HIGH/MEDIUM/LOW/UNKNOWN. When OSV has no
  severity data at all, it's honestly reported as UNKNOWN rather than
  guessed.
- Needs outbound internet access to reach `api.osv.dev`. No other network
  access, no telemetry, no code ever leaves your machine except the bare
  `(package name, version, ecosystem)` tuples sent to OSV for lookup.

## Install

```bash
python3 -m venv .venv && .venv/bin/pip install -e .
```

## Usage

```bash
# scan the current directory, human-readable report, exit 1 if HIGH+ found
depaudit .

# scan a specific project, write a markdown report for a PR/README
depaudit path/to/project --format markdown --out AUDIT.md

# never fail the exit code (just informational)
depaudit . --fail-on NEVER

# only fail CI on CRITICAL
depaudit . --fail-on CRITICAL
```

## Demo

`fixtures/vulnerable_project/` contains a deliberately outdated
`package.json` (lodash 4.17.15) and `requirements.txt` (requests 2.6.0,
Django 2.0.0, flask>=1.0). Running `depaudit fixtures/vulnerable_project`
against the live OSV.dev API finds real, current CVEs/GHSAs for all of them,
including exact fixed versions - see `DEMO_REPORT.md` in this repo for an
actual captured run.

`fixtures/clean_project/` contains only `left-pad@1.3.0`, which has no known
vulnerabilities, and produces a clean report - showing depaudit doesn't just
cry wolf on everything.

`fixtures/lockfile_project/` has a `package.json` with `"lodash": "^4.17.0"`
(a range) alongside a `package-lock.json` that resolved it to `4.17.15`;
depaudit reports the lockfile's exact version and does not mark it
approximate, demonstrating the lockfile-preference behavior.

## Tests

```bash
.venv/bin/pip install -e . pytest
.venv/bin/pytest -q                      # 8 fast unit tests, fully mocked OSV client, no network
.venv/bin/pytest -q tests/test_live_osv.py  # 2 real end-to-end tests against the live OSV.dev API
```

The unit tests (`tests/test_parsers.py`, `tests/test_scanner_mocked.py`) cover
manifest parsing (exact vs. range versions, skipping `node_modules`) and the
scan/report pipeline with a mocked OSV client, so they run offline and
deterministically. `tests/test_live_osv.py` is a genuine integration test
against the real, live public API (auto-skips if OSV.dev isn't reachable) —
this is what proves the tool actually works end-to-end, not just against
fixtures.

## Project layout

```
depaudit/
  __init__.py
  parsers.py    - manifest parsing (package.json, requirements.txt)
  osv.py        - OSV.dev API client (batch query + vuln details)
  scanner.py    - orchestrates parse -> query -> findings
  report.py     - console + markdown rendering
  cli.py        - argparse entrypoint, exit codes for CI
tests/
fixtures/       - sample vulnerable and clean projects used by tests/demo
```
