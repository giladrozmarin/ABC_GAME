"""CSV parsing and merchant-name normalization for bank/credit-card exports."""
from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass
from datetime import date, datetime
from typing import Iterable, List, Optional

DATE_FORMATS = [
    "%Y-%m-%d",
    "%m/%d/%Y",
    "%m/%d/%y",
    "%d/%m/%Y",
    "%B %d, %Y",
    "%b %d, %Y",
    "%Y/%m/%d",
]

# Common column-name aliases seen across bank/credit-card CSV exports.
DATE_ALIASES = ["date", "transaction date", "posted date", "posting date", "trans date"]
DESC_ALIASES = ["description", "desc", "name", "merchant", "payee", "details", "memo"]
AMOUNT_ALIASES = ["amount", "debit", "amount debit", "transaction amount", "value"]

# Column names that are *always* an unsigned "money out" figure by
# convention (a "Debit"/"Withdrawal" column never represents a deposit),
# as opposed to a generic "Amount" column that may mix expenses (negative)
# and income/refunds/payroll (positive) in one signed field.
UNSIGNED_DEBIT_ALIASES = ["debit", "amount debit", "withdrawal", "money out"]


@dataclass
class Transaction:
    date: date
    description: str
    merchant: str
    amount: float  # positive = money spent (expense)
    raw_description: str


class ParseError(ValueError):
    pass


def _parse_date(value: str) -> Optional[date]:
    value = value.strip()
    if not value:
        return None
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    # last resort: ISO-ish with time component
    try:
        return datetime.fromisoformat(value).date()
    except ValueError:
        return None


def _find_column(fieldnames: List[str], aliases: List[str]) -> Optional[str]:
    lower_map = {f.lower().strip(): f for f in fieldnames}
    for alias in aliases:
        if alias in lower_map:
            return lower_map[alias]
    # fuzzy contains match as fallback
    for f in fieldnames:
        fl = f.lower().strip()
        for alias in aliases:
            if alias in fl:
                return f
    return None


_PREFIX_PATTERNS = [
    re.compile(r"^PAYPAL\s*\*\s*", re.I),
    re.compile(r"^SQ\s*\*\s*", re.I),  # Square
    re.compile(r"^TST\*\s*", re.I),  # Toast
    re.compile(r"^APLPAY\s+", re.I),  # Apple Pay
    re.compile(r"^GOOGLE\s*\*\s*", re.I),
]

_NOISE_PATTERNS = [
    re.compile(r"\bPOS\b", re.I),
    re.compile(r"\bDEBIT CARD PURCHASE\b", re.I),
    re.compile(r"\bRECURRING PAYMENT\b", re.I),
    re.compile(r"\bAUTOPAY\b", re.I),
    re.compile(r"\bACH\b", re.I),
    re.compile(r"\bPAYMENT\b", re.I),
    re.compile(r"\bPURCHASE\b", re.I),
    re.compile(r"\b\d{2}/\d{2}\b"),  # embedded dates like 05/12
    re.compile(r"#\d+"),
    re.compile(r"\*\S+"),  # e.g. NETFLIX*ABC123 -> strip *ABC123
    re.compile(r"\b\d{4,}\b"),  # long numeric IDs
    re.compile(r"\s{2,}"),
]


def normalize_merchant(description: str) -> str:
    """Collapse a raw transaction description into a stable merchant key.

    Bank exports append store numbers, transaction IDs, and dates to an
    otherwise-consistent merchant name. We strip that noise so repeated
    charges from the same merchant group together.
    """
    text = description.upper().strip()
    for pattern in _PREFIX_PATTERNS:
        text = pattern.sub("", text)
    for pattern in _NOISE_PATTERNS:
        text = pattern.sub(" ", text)
    # keep only leading alphanumeric words, drop city/state suffixes that
    # banks often tack on (heuristic: keep first 3 tokens)
    tokens = [t for t in re.split(r"[\s,]+", text) if t]
    tokens = [t for t in tokens if not t.isdigit()]
    key = " ".join(tokens[:3]).strip()
    return key or text.strip()


def _sniff_delimiter(csv_text: str) -> str:
    """Detect the field delimiter. Most US bank exports use commas, but
    some European bank exports (and Excel's regional CSV export) use
    semicolons or tabs instead. Without this, those files silently parse
    to zero transactions instead of raising a clear error."""
    sample = csv_text[:4096]
    try:
        return csv.Sniffer().sniff(sample, delimiters=",;\t").delimiter
    except csv.Error:
        return ","


def parse_transactions(csv_text: str) -> List[Transaction]:
    # Strip a UTF-8 BOM if present (common from Excel/Windows exports).
    if csv_text.startswith("﻿"):
        csv_text = csv_text[1:]
    delimiter = _sniff_delimiter(csv_text)
    reader = csv.DictReader(io.StringIO(csv_text), delimiter=delimiter)
    if not reader.fieldnames:
        raise ParseError("CSV has no header row / no columns detected.")

    date_col = _find_column(reader.fieldnames, DATE_ALIASES)
    desc_col = _find_column(reader.fieldnames, DESC_ALIASES)
    amount_col = _find_column(reader.fieldnames, AMOUNT_ALIASES)

    missing = [
        name
        for name, col in [("date", date_col), ("description", desc_col), ("amount", amount_col)]
        if col is None
    ]
    if missing:
        raise ParseError(
            f"Could not find column(s) for: {', '.join(missing)}. "
            f"Found columns: {reader.fieldnames}"
        )

    rows = list(reader)

    # --- Pass 1: figure out this file's sign convention for the amount
    # column, since bank exports are inconsistent about it. ---
    column_is_unsigned_debit = _find_column([amount_col], UNSIGNED_DEBIT_ALIASES) is not None
    parsed_amounts: List[Optional[float]] = []
    for row in rows:
        raw_amount = (row.get(amount_col) or "").strip()
        parsed_amounts.append(_parse_amount(raw_amount))
    # Decide the file's sign convention by MAJORITY VOTE across all rows,
    # not just "is there any negative value at all". Two real conventions
    # exist in the wild:
    #   - checking/debit accounts: expenses negative, deposits/payroll
    #     positive (majority of rows negative)
    #   - credit-card statements: purchases positive, occasional
    #     payments/refunds/credits negative (majority of rows positive)
    # The old "any negative present -> negative is spend" rule broke badly
    # on the second case: a single refund row on an otherwise-all-positive
    # credit card statement flipped the whole file's convention, silently
    # dropping every real charge and keeping only the refund (misclassified
    # as spend) -- found via adversarial testing, worse than the earlier
    # payroll-deposit bug because it under-reports to near-zero instead of
    # over-reporting one bogus entry.
    negative_count = sum(1 for a in parsed_amounts if a is not None and a < 0)
    positive_count = sum(1 for a in parsed_amounts if a is not None and a > 0)
    if column_is_unsigned_debit:
        treat_positive_as_spend = True
    elif negative_count == 0 and positive_count == 0:
        treat_positive_as_spend = True  # no signal either way; harmless default
    else:
        # Majority sign is treated as "spend"; ties keep the historical
        # default (negative = spend) so the original payroll regression
        # test is unaffected.
        treat_positive_as_spend = positive_count > negative_count

    # --- Pass 2: build transactions using that convention. ---
    transactions: List[Transaction] = []
    for row, amount in zip(rows, parsed_amounts):
        raw_date = (row.get(date_col) or "").strip()
        raw_desc = (row.get(desc_col) or "").strip()
        if not raw_date or not raw_desc or amount is None:
            continue

        d = _parse_date(raw_date)
        if d is None:
            continue

        if column_is_unsigned_debit:
            # Unsigned column: whatever sign shows up, its magnitude is the
            # spend (these columns don't carry refunds/deposits by design).
            spend = abs(amount)
        elif treat_positive_as_spend:
            # Credit-card-style convention: positive = purchase, negative =
            # payment/refund/credit. Do NOT treat the negative rows as
            # spend here (that was the bug: it silently dropped every real
            # charge on a file with even one refund row).
            if amount <= 0:
                continue
            spend = amount
        else:
            # Checking/debit-style convention: negative = purchase,
            # positive = deposit/refund/payroll.
            if amount >= 0:
                continue
            spend = -amount

        if spend <= 0:
            continue

        transactions.append(
            Transaction(
                date=d,
                description=raw_desc,
                merchant=normalize_merchant(raw_desc),
                amount=round(spend, 2),
                raw_description=raw_desc,
            )
        )

    return transactions


def _parse_amount(raw_amount: str) -> Optional[float]:
    raw_amount = raw_amount.strip()
    if not raw_amount:
        return None
    cleaned = raw_amount.replace("$", "").replace(",", "")
    if cleaned.startswith("(") and cleaned.endswith(")"):
        cleaned = "-" + cleaned[1:-1]
    try:
        return float(cleaned)
    except ValueError:
        return None
