"""Command-line entry point for SubSleuth."""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict

from .core import parse_transactions, detect_subscriptions, CSVFormatError
from .report import to_terminal_table, to_markdown, to_html


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="subsleuth",
        description=(
            "Find recurring subscription charges hiding in a bank/credit-card "
            "CSV export. 100%% local — your data never leaves your machine."
        ),
    )
    p.add_argument("csv_path", help="Path to a transactions CSV export")
    p.add_argument(
        "--min-occurrences", type=int, default=3,
        help="Minimum number of matching charges required to call it a subscription (default: 3)",
    )
    p.add_argument(
        "--amount-tolerance", type=float, default=0.15,
        help="Fractional tolerance for grouping charges of slightly different amounts (default: 0.15)",
    )
    p.add_argument("--markdown-out", help="Write a Markdown report to this path")
    p.add_argument("--html-out", help="Write a self-contained HTML report to this path")
    p.add_argument("--json-out", help="Write raw detection results as JSON to this path")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        transactions = parse_transactions(args.csv_path)
    except CSVFormatError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    except FileNotFoundError:
        print(f"error: file not found: {args.csv_path}", file=sys.stderr)
        return 1

    subs = detect_subscriptions(
        transactions,
        min_occurrences=args.min_occurrences,
        amount_tolerance=args.amount_tolerance,
    )

    print(f"Parsed {len(transactions)} spend transactions from {args.csv_path}\n")
    print(to_terminal_table(subs))

    if args.markdown_out:
        with open(args.markdown_out, "w") as fh:
            fh.write(to_markdown(subs, args.csv_path))
        print(f"\nMarkdown report written to {args.markdown_out}")

    if args.html_out:
        with open(args.html_out, "w") as fh:
            fh.write(to_html(subs, args.csv_path))
        print(f"HTML report written to {args.html_out}")

    if args.json_out:
        payload = [
            {**asdict(s), "first_seen": s.first_seen.isoformat(), "last_seen": s.last_seen.isoformat(),
             "dates": [d.isoformat() for d in s.dates]}
            for s in subs
        ]
        with open(args.json_out, "w") as fh:
            json.dump(payload, fh, indent=2)
        print(f"JSON results written to {args.json_out}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
