"""Render detected subscriptions as a terminal table, Markdown, and HTML report."""
from __future__ import annotations

import html
from collections import defaultdict

from .core import Subscription, total_annualized_cost


def to_terminal_table(subs: list[Subscription]) -> str:
    if not subs:
        return "No recurring subscriptions detected."
    headers = ["Merchant", "Freq", "Occ", "Last $", "Annual $", "First seen", "Last seen", "Price change"]
    rows = []
    for s in subs:
        change = f"+{s.price_increase_pct}%" if (s.price_increase_pct or 0) > 0 else (
            f"{s.price_increase_pct}%" if s.price_increase_pct else "-"
        )
        rows.append([
            s.merchant.title(),
            s.frequency,
            str(s.occurrences),
            f"{s.last_amount:.2f}",
            f"{s.annualized_cost:.2f}",
            s.first_seen.isoformat(),
            s.last_seen.isoformat(),
            change,
        ])
    widths = [max(len(h), *(len(r[i]) for r in rows)) for i, h in enumerate(headers)]
    lines = []
    lines.append("  ".join(h.ljust(widths[i]) for i, h in enumerate(headers)))
    lines.append("  ".join("-" * w for w in widths))
    for r in rows:
        lines.append("  ".join(c.ljust(widths[i]) for i, c in enumerate(r)))
    lines.append("")
    lines.append(f"TOTAL detected recurring spend (annualized): ${total_annualized_cost(subs):.2f}")
    return "\n".join(lines)


def to_markdown(subs: list[Subscription], source_file: str) -> str:
    lines = [
        "# SubSleuth Report",
        "",
        f"Source file: `{source_file}`",
        "",
        f"**{len(subs)} recurring subscriptions detected, "
        f"totaling an estimated ${total_annualized_cost(subs):.2f}/year.**",
        "",
        "| Merchant | Frequency | Occurrences | Last charge | Annualized | First seen | Last seen | Price change |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for s in subs:
        change = "-"
        if s.price_increase_pct:
            sign = "+" if s.price_increase_pct > 0 else ""
            flag = " ⚠️" if s.price_increase_pct > 0 else ""
            change = f"{sign}{s.price_increase_pct}%{flag}"
        lines.append(
            f"| {s.merchant.title()} | {s.frequency} | {s.occurrences} | "
            f"${s.last_amount:.2f} | ${s.annualized_cost:.2f} | {s.first_seen} | "
            f"{s.last_seen} | {change} |"
        )
    lines.append("")
    lines.append("## Notes")
    lines.append("")
    lines.append(
        "- 'Annualized' extrapolates the most recent charge amount at the detected "
        "frequency (e.g. monthly x 12)."
    )
    lines.append(
        "- Price change ⚠️ flags merchants whose charge increased between the first "
        "and most recent occurrence in this file — a common silent price hike."
    )
    lines.append(
        "- This tool only reads the CSV you give it. Nothing is uploaded anywhere."
    )
    return "\n".join(lines)


def to_html(subs: list[Subscription], source_file: str) -> str:
    by_cat: dict[str, float] = defaultdict(float)
    for s in subs:
        by_cat[s.category] += s.annualized_cost

    def row(s: Subscription) -> str:
        change = ""
        if s.price_increase_pct:
            cls = "up" if s.price_increase_pct > 0 else "down"
            sign = "+" if s.price_increase_pct > 0 else ""
            change = f'<span class="{cls}">{sign}{s.price_increase_pct}%</span>'
        return (
            "<tr>"
            f"<td>{html.escape(s.merchant.title())}</td>"
            f"<td>{html.escape(s.category)}</td>"
            f"<td>{html.escape(s.frequency)}</td>"
            f"<td>{s.occurrences}</td>"
            f"<td>${s.last_amount:.2f}</td>"
            f"<td>${s.annualized_cost:.2f}</td>"
            f"<td>{s.first_seen}</td>"
            f"<td>{s.last_seen}</td>"
            f"<td>{change}</td>"
            "</tr>"
        )

    cat_rows = "".join(
        f"<li>{html.escape(cat)}: <b>${cost:.2f}</b>/yr</li>"
        for cat, cost in sorted(by_cat.items(), key=lambda kv: -kv[1])
    )
    rows_html = "".join(row(s) for s in subs) if subs else (
        '<tr><td colspan="9">No recurring subscriptions detected.</td></tr>'
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>SubSleuth Report</title>
<style>
  body {{ font-family: -apple-system, Segoe UI, Roboto, sans-serif; margin: 2rem; color: #1a1a1a; background: #fafafa; }}
  h1 {{ margin-bottom: 0; }}
  .subtitle {{ color: #555; margin-top: 0.25rem; }}
  .total {{ font-size: 1.3rem; margin: 1rem 0; padding: 0.75rem 1rem; background: #fff3cd; border-radius: 8px; display: inline-block; }}
  table {{ border-collapse: collapse; width: 100%; margin-top: 1rem; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }}
  th, td {{ padding: 0.5rem 0.75rem; text-align: left; border-bottom: 1px solid #eee; }}
  th {{ background: #f0f0f0; }}
  .up {{ color: #c0392b; font-weight: bold; }}
  .down {{ color: #27ae60; font-weight: bold; }}
  ul {{ line-height: 1.6; }}
  footer {{ margin-top: 2rem; color: #777; font-size: 0.85rem; }}
</style>
</head>
<body>
  <h1>SubSleuth Report</h1>
  <p class="subtitle">Source: {html.escape(source_file)}</p>
  <div class="total">{len(subs)} recurring subscriptions found &mdash; est. <b>${total_annualized_cost(subs):.2f}/year</b></div>
  <h2>By category</h2>
  <ul>{cat_rows}</ul>
  <h2>Detail</h2>
  <table>
    <tr><th>Merchant</th><th>Category</th><th>Frequency</th><th>Occ.</th><th>Last charge</th><th>Annualized</th><th>First seen</th><th>Last seen</th><th>Price change</th></tr>
    {rows_html}
  </table>
  <footer>Generated locally by SubSleuth. No data leaves your machine.</footer>
</body>
</html>
"""
