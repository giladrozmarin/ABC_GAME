"""Best-effort, cosmetic-only merchant category tagging.

This module never influences subscription detection (detector.py has no
dependency on it) — it only adds a human-friendly label for the report/UI,
so grouping subscriptions by category (streaming, fitness, software, ...)
doesn't risk introducing false positives/negatives into the core detector.
"""
from __future__ import annotations

CATEGORY_KEYWORDS: dict[str, list[str]] = {
    "Streaming & Media": [
        "NETFLIX", "HULU", "DISNEY", "SPOTIFY", "APPLE MUSIC", "APPLE TV",
        "YOUTUBE", "HBO", "PARAMOUNT", "PEACOCK", "PANDORA", "AUDIBLE",
        "PRIME VIDEO", "CRUNCHYROLL", "TWITCH",
    ],
    "Fitness & Health": [
        "FITNESS", "GYM", "YOGA", "PELOTON", "PLANET FITNESS", "24HR",
        "CROSSFIT", "STRAVA",
    ],
    "Software & Cloud": [
        "ADOBE", "MICROSOFT", "GOOGLE", "ICLOUD", "DROPBOX", "GITHUB",
        "SLACK", "ZOOM", "NOTION", "OPENAI", "CHATGPT", "AWS", "CLAUDE",
        "ANTHROPIC",
    ],
    "Insurance": ["GEICO", "PROGRESSIVE", "STATE FARM", "ALLSTATE", "INSURANCE", "INS"],
    "Shopping & Membership": ["AMAZON PRIME", "PRIME", "COSTCO", "SAMS CLUB"],
    "News & Reading": ["NYTIMES", "WSJ", "WASHINGTONPOST", "KINDLE UNLIMITED", "MEDIUM"],
}


def categorize(merchant_label: str) -> str:
    """Best-effort category tag for a merchant string. Falls back to 'Other'."""
    upper = merchant_label.upper()
    for category, keywords in CATEGORY_KEYWORDS.items():
        for kw in keywords:
            if kw in upper:
                return category
    return "Other"


def category_breakdown(subscriptions) -> dict[str, float]:
    """Given a list of detector.Subscription, return {category: total_monthly_cost}."""
    totals: dict[str, float] = {}
    for s in subscriptions:
        cat = categorize(s.merchant)
        totals[cat] = totals.get(cat, 0.0) + s.estimated_monthly_cost
    return dict(sorted(totals.items(), key=lambda kv: -kv[1]))
