"""Human-readable report rendering."""
from __future__ import annotations

import json
from typing import List

from .detector import Subscription, summarize


def to_json(subscriptions: List[Subscription]) -> str:
    payload = {
        "summary": summarize(subscriptions),
        "subscriptions": [s.to_dict() for s in subscriptions],
    }
    return json.dumps(payload, indent=2)


def to_text(subscriptions: List[Subscription]) -> str:
    lines = []
    summary = summarize(subscriptions)
    lines.append("SubSleuth report")
    lines.append("=" * 60)
    if not subscriptions:
        lines.append("No recurring subscriptions detected in this statement.")
        return "\n".join(lines)

    lines.append(
        f"Found {summary['subscription_count']} active recurring charge(s)  |  "
        f"~${summary['estimated_total_monthly_cost']:.2f}/mo  |  "
        f"~${summary['estimated_total_annual_cost']:.2f}/yr"
    )
    if summary["price_hikes_detected"]:
        lines.append(f"⚠ {summary['price_hikes_detected']} price increase(s) detected")
    if summary.get("likely_cancelled_count"):
        lines.append(
            f"ℹ {summary['likely_cancelled_count']} previously-recurring charge(s) look cancelled "
            f"(no charge for 2x+ their usual interval) — excluded from totals above"
        )
    lines.append("-" * 60)

    active = [s for s in subscriptions if not s.likely_cancelled]
    cancelled = [s for s in subscriptions if s.likely_cancelled]

    for s in active:
        lines.append(f"{s.merchant}  ({s.frequency}, {s.occurrences}x seen)")
        lines.append(
            f"    avg ${s.average_amount:.2f}/charge  ->  "
            f"~${s.estimated_monthly_cost:.2f}/mo  (~${s.estimated_annual_cost:.2f}/yr)"
        )
        lines.append(f"    first: {s.first_seen}   last: {s.last_seen}   next due (est.): {s.next_due_date}")
        if s.price_hike:
            ph = s.price_hike
            lines.append(
                f"    ⚠ PRICE HIKE: ${ph['previous_amount']:.2f} -> "
                f"${ph['new_amount']:.2f}  (+{ph['increase_pct']:.1f}%)"
            )
        lines.append("")

    if cancelled:
        lines.append("Likely already cancelled (not counted above):")
        for s in cancelled:
            lines.append(f"  {s.merchant}  last charged {s.last_seen} (was {s.frequency}, ${s.average_amount:.2f})")
        lines.append("")

    return "\n".join(lines)
