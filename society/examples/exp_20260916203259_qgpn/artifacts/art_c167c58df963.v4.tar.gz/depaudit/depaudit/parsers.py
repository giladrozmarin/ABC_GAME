"""Parsers that extract (name, version, ecosystem, exact) tuples from
common manifest files.

`exact=True` means the version string is a pinned, exact version we can
query with full confidence. `exact=False` means we had to guess a
concrete version out of a range specifier (e.g. "^1.2.3" -> "1.2.3"); the
report clearly flags these as approximate so users aren't misled.
"""
from __future__ import annotations

import json
import re
import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import List


@dataclass
class Dependency:
    name: str
    version: str
    ecosystem: str  # "npm" or "PyPI"
    exact: bool
    source_file: str


_RANGE_PREFIX_RE = re.compile(r"^[\^~>=<\s]+")


def _clean_npm_version(spec: str) -> tuple[str, bool]:
    spec = spec.strip()
    exact = bool(re.match(r"^\d+\.\d+\.\d+", spec))
    cleaned = _RANGE_PREFIX_RE.sub("", spec)
    # strip anything after a space (e.g. "1.2.3 || 2.0.0") - take first
    cleaned = cleaned.split("||")[0].split(" ")[0].strip()
    if not re.match(r"^\d+\.\d+\.\d+", cleaned):
        return "", False
    return cleaned, exact


def parse_package_json(path: Path) -> List[Dependency]:
    data = json.loads(path.read_text())
    deps: List[Dependency] = []
    for section in ("dependencies", "devDependencies", "optionalDependencies"):
        for name, spec in (data.get(section) or {}).items():
            if not isinstance(spec, str):
                continue
            if spec.startswith(("git+", "http", "file:", "workspace:", "link:")):
                continue  # not resolvable to a registry version
            version, exact = _clean_npm_version(spec)
            if not version:
                continue
            deps.append(Dependency(name, version, "npm", exact, str(path)))
    return deps


_REQ_LINE_RE = re.compile(
    r"^\s*([A-Za-z0-9_.\-\[\]]+)\s*(==|>=|<=|~=|!=|>|<)\s*([0-9][A-Za-z0-9_.\-]*)"
)


def parse_requirements_txt(path: Path) -> List[Dependency]:
    deps: List[Dependency] = []
    for raw_line in path.read_text().splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        line = line.split(";")[0].split("#")[0].strip()
        m = _REQ_LINE_RE.match(line)
        if not m:
            continue
        name, op, version = m.groups()
        name = name.split("[")[0]  # drop extras like package[extra]
        deps.append(Dependency(name, version, "PyPI", op == "==", str(path)))
    return deps


def parse_package_lock_json(path: Path) -> List[Dependency]:
    """Parse npm package-lock.json (lockfile v2/v3, with a v1 fallback).

    Lockfile versions are exact-resolved, so results from this file are
    always marked exact=True and take priority over the version ranges in
    package.json when both are present in the same directory.
    """
    data = json.loads(path.read_text())
    deps: List[Dependency] = []
    seen = set()

    packages = data.get("packages")
    if isinstance(packages, dict) and packages:
        # v2/v3 format: keys are paths like "node_modules/lodash" or "" (root)
        for pkg_path, info in packages.items():
            if not pkg_path or "node_modules/" not in pkg_path:
                continue
            if not isinstance(info, dict) or info.get("link"):
                continue
            name = pkg_path.rsplit("node_modules/", 1)[-1]
            version = info.get("version")
            if not name or not version:
                continue
            key = (name.lower(), version)
            if key in seen:
                continue
            seen.add(key)
            deps.append(Dependency(name, version, "npm", True, str(path)))
        if deps:
            return deps

    # v1 fallback: nested "dependencies" tree with "version" fields
    def walk(node: dict):
        for name, info in (node or {}).items():
            if not isinstance(info, dict):
                continue
            version = info.get("version")
            if version:
                key = (name.lower(), version)
                if key not in seen:
                    seen.add(key)
                    deps.append(Dependency(name, version, "npm", True, str(path)))
            if isinstance(info.get("dependencies"), dict):
                walk(info["dependencies"])

    walk(data.get("dependencies") or {})
    return deps


def parse_poetry_lock(path: Path) -> List[Dependency]:
    """Parse poetry.lock (TOML). Every entry under [[package]] has an exact
    resolved version, so these are always exact=True."""
    with path.open("rb") as fh:
        data = tomllib.load(fh)
    deps: List[Dependency] = []
    for pkg in data.get("package", []) or []:
        name = pkg.get("name")
        version = pkg.get("version")
        if name and version:
            deps.append(Dependency(name, version, "PyPI", True, str(path)))
    return deps


def discover_manifests(root: Path) -> List[Path]:
    found = []
    for pattern in ("package.json", "package-lock.json", "requirements.txt", "poetry.lock"):
        found.extend(sorted(root.rglob(pattern)))
    # skip node_modules / venv noise
    filtered = [
        p
        for p in found
        if not any(
            part in {"node_modules", ".venv", "venv", "site-packages", "dist", "build"}
            for part in p.parts
        )
    ]
    # If a package-lock.json sits next to a package.json in the same
    # directory, prefer the lockfile (exact resolved versions) and drop the
    # package.json from the report so we don't double-count/approximate.
    by_dir: dict = {}
    for p in filtered:
        by_dir.setdefault(p.parent, []).append(p)
    result = []
    for dir_path, files in by_dir.items():
        names = {f.name for f in files}
        drop = set()
        if "package-lock.json" in names and "package.json" in names:
            drop.add("package.json")
        if "poetry.lock" in names and "requirements.txt" in names:
            drop.add("requirements.txt")
        result.extend(f for f in files if f.name not in drop)
    return sorted(result)


def parse_manifest(path: Path) -> List[Dependency]:
    if path.name == "package-lock.json":
        return parse_package_lock_json(path)
    if path.name == "package.json":
        return parse_package_json(path)
    if path.name == "poetry.lock":
        return parse_poetry_lock(path)
    if path.name == "requirements.txt":
        return parse_requirements_txt(path)
    return []
