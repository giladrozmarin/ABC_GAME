# SubSleuth

**Find the subscriptions quietly draining your bank account — and catch price hikes before they add up.**

Most people have 8-15 recurring subscriptions (streaming, gym, cloud storage,
apps, memberships) scattered across months of bank/credit-card statements.
Banks and budgeting apps rarely surface this cleanly, and price increases
(Netflix going from $15.49 to $17.99, a gym "processing fee" creeping up)
slip by unnoticed because each individual charge looks normal.

SubSleuth takes a CSV export of your bank or credit-card transactions
(the kind every bank lets you download) and, **entirely locally, with no
external services or accounts**, tells you:

- Which charges are actually recurring subscriptions (vs. one-off purchases
  or frequent-but-irregular spending like groceries or gas)
- How much each one costs you per month and per year
- Your total recurring monthly/annual spend
- Which subscriptions just got **more expensive**, and by how much

## Who this is for

Anyone who wants to audit their subscriptions without manually scrolling
through months of a bank statement, or without granting a third-party
"budgeting app" read access to their live bank login (Plaid-style apps).
SubSleuth only needs a CSV file you already control — it never talks to
your bank.

## How it works (the actual logic, honestly)

1. **Parse**: reads a CSV, auto-detecting date/description/amount columns
   under common aliases (`Date`/`Transaction Date`, `Description`/`Payee`/
   `Merchant`, `Amount`/`Debit`, handles `$1,234.56` and `(12.50)` negative
   formats).
2. **Normalize merchant names**: strips store numbers, transaction IDs,
   "POS"/"DEBIT CARD PURCHASE" noise, and `*ABC123`-style suffixes banks
   append, so `NETFLIX.COM 866-579-7172` on different months groups
   together.
3. **Group and classify**: for each merchant, it looks at the *timing*
   (are charges spaced ~7, ~14, ~30, ~90, or ~365 days apart, consistently?)
   and the *amount consistency* (is the charge basically the same each
   time?). Only merchants that pass both checks are called a "subscription."
   This is why frequent-but-variable spending (a grocery store you visit
   often but for different amounts each time) is correctly **excluded** —
   see the test suite for a worked example.
4. **Detect price hikes**: finds the most recent run of stable charges and
   compares it to what was charged before, flagging increases ≥3% and
   ≥$0.25.

## Honest limitations

- **Needs 2+ occurrences** of a merchant to say anything — a subscription
  you signed up for once (e.g. an annual charge that's only appeared once
  in your export) won't be detected yet. Feed it a longer history (6-12
  months) for best results.
- **Heuristic, not perfect.** Merchant-name normalization is regex-based;
  unusual bank formatting may not group correctly. Always sanity-check
  the output against your real statement before cancelling anything.
- **CSV only.** No live bank connection (this is a deliberate design
  choice for privacy, not a missing feature — see "Who this is for").
- Amount-sign handling assumes typical export conventions (expenses as
  negative or as a dedicated debit column); statements that mix formats
  unusually may need column renaming first.

## Install

```bash
cd subsleuth
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## Usage

### Command line

```bash
python3 -m subsleuth.cli tests/fixtures/sample_statement.csv
```

```
SubSleuth report
============================================================
Found 3 recurring charge(s)  |  ~$52.72/mo  |  ~$632.64/yr
⚠ 1 price increase(s) detected
------------------------------------------------------------
GYM MEMBERSHIP PLANET  (monthly, 5x seen)
    avg $24.99/charge  ->  ~$24.99/mo  (~$299.88/yr)
    first: 2025-02-27   last: 2025-06-27

NETFLIX.COM 866-579-  (monthly, 6x seen)
    avg $16.74/charge  ->  ~$16.74/mo  (~$200.88/yr)
    first: 2025-01-03   last: 2025-06-02
    ⚠ PRICE HIKE: $15.49 -> $17.99  (+16.1%)

SPOTIFY USA  (monthly, 6x seen)
    avg $10.99/charge  ->  ~$10.99/mo  (~$131.88/yr)
    first: 2025-01-08   last: 2025-06-08
```

Machine-readable output: `python3 -m subsleuth.cli statement.csv --json`

### Web UI (drag-and-drop demo)

```bash
python3 -m subsleuth.webapp
# open http://127.0.0.1:5050
```

Upload a CSV, get a table of subscriptions with cost estimates and hike
alerts. The file is processed in memory for that one request only — it is
never written to disk or sent anywhere else.

## Tests

```bash
pip install -r requirements.txt
python3 -m pytest -q
```

20 tests cover: CSV parsing (multiple column-name conventions, `(12.50)`
negative format, missing/malformed rows), merchant-name normalization,
subscription detection (including the important **negative** cases —
irregular grocery spending and single-occurrence merchants are correctly
*excluded*), price-hike detection, the CLI, and the web upload flow.

## Try it on your own data

Export a CSV from your bank (most banks: Accounts → Statements → Download
CSV, typically 6-12 months). Run it through SubSleuth. The tool never
leaves your machine and makes no network calls.
