import io
import os

from subsleuth.webapp import app

FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "sample_statement.csv")


def test_get_index():
    client = app.test_client()
    resp = client.get("/")
    assert resp.status_code == 200
    assert b"SubSleuth" in resp.data


def test_upload_csv_shows_results():
    client = app.test_client()
    with open(FIXTURE, "rb") as f:
        data = {"csv_file": (io.BytesIO(f.read()), "sample_statement.csv")}
        resp = client.post("/", data=data, content_type="multipart/form-data")
    assert resp.status_code == 200
    assert b"NETFLIX" in resp.data
    assert b"recurring charge" in resp.data


def test_upload_no_file_shows_error():
    client = app.test_client()
    resp = client.post("/", data={}, content_type="multipart/form-data")
    assert resp.status_code == 200
    assert b"choose a CSV file" in resp.data
