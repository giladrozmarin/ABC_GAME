"""Command-line entry point: `subsleuth statement.csv`"""
from __future__ import annotations

import argparse
import sys

from .detector import find_subscriptions
from .parser import ParseError, parse_transactions
from .report import to_json, to_text


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="subsleuth",
        description="Find recurring subscriptions and price hikes hiding in a bank/credit-card CSV export.",
    )
    parser.add_argument("csv_file", help="Path to a CSV export (date, description, amount columns).")
    parser.add_argument("--json", action="store_true", help="Output machine-readable JSON instead of text.")
    args = parser.parse_args(argv)

    try:
        with open(args.csv_file, "r", encoding="utf-8-sig") as f:
            csv_text = f.read()
    except OSError as e:
        print(f"Error reading file: {e}", file=sys.stderr)
        return 1

    try:
        transactions = parse_transactions(csv_text)
    except ParseError as e:
        print(f"Could not parse CSV: {e}", file=sys.stderr)
        return 1

    if not transactions:
        print("No usable transactions found in that file.", file=sys.stderr)
        return 1

    subscriptions = find_subscriptions(transactions)
    output = to_json(subscriptions) if args.json else to_text(subscriptions)
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
