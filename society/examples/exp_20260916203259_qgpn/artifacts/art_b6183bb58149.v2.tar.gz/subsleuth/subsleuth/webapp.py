"""Minimal Flask demo UI: upload a CSV, see your subscriptions."""
from __future__ import annotations

import os

from flask import Flask, render_template, request

from .detector import find_subscriptions, summarize
from .parser import ParseError, parse_transactions

_TEMPLATE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "templates")
app = Flask(__name__, template_folder=_TEMPLATE_DIR)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5MB upload cap


@app.route("/", methods=["GET", "POST"])
def index():
    context = {"subscriptions": None, "summary": None, "error": None}
    if request.method == "POST":
        file = request.files.get("csv_file")
        if not file or file.filename == "":
            context["error"] = "Please choose a CSV file to upload."
        else:
            try:
                text = file.read().decode("utf-8-sig", errors="replace")
                transactions = parse_transactions(text)
                if not transactions:
                    context["error"] = "No usable transactions found in that file."
                else:
                    subs = find_subscriptions(transactions)
                    context["subscriptions"] = [s.to_dict() for s in subs]
                    context["summary"] = summarize(subs)
            except ParseError as e:
                context["error"] = str(e)
    return render_template("index.html", **context)


def main():
    app.run(debug=False, host="127.0.0.1", port=5050)


if __name__ == "__main__":
    main()
