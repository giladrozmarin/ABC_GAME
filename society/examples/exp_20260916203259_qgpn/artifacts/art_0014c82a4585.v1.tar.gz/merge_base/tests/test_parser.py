import os

import pytest

from subsleuth.parser import ParseError, normalize_merchant, parse_transactions

FIXTURE_DIR = os.path.join(os.path.dirname(__file__), "fixtures")


def load_fixture(name):
    with open(os.path.join(FIXTURE_DIR, name), encoding="utf-8") as f:
        return f.read()


def test_parses_sample_statement():
    text = load_fixture("sample_statement.csv")
    txs = parse_transactions(text)
    assert len(txs) == 25
    assert all(t.amount > 0 for t in txs)  # expenses normalized to positive
    first = txs[0]
    assert first.date.isoformat() == "2025-01-03"
    assert first.amount == 15.49


def test_normalize_merchant_strips_noise():
    a = normalize_merchant("NETFLIX.COM 866-579-7172")
    b = normalize_merchant("NETFLIX.COM 866-579-7172")
    assert a == b

    c = normalize_merchant("SPOTIFY USA")
    assert "SPOTIFY" in c


def test_normalize_merchant_groups_star_suffix_ids():
    a = normalize_merchant("NETFLIX*AB12CD3")
    b = normalize_merchant("NETFLIX*XY99ZZ1")
    assert a == b


def test_missing_columns_raise_parse_error():
    bad_csv = "foo,bar\n1,2\n"
    with pytest.raises(ParseError):
        parse_transactions(bad_csv)


def test_alternate_column_names_and_parens_negative():
    csv_text = (
        "Transaction Date,Payee,Transaction Amount\n"
        "01/15/2025,ACME CORP,(12.50)\n"
        "02/15/2025,ACME CORP,(12.50)\n"
    )
    txs = parse_transactions(csv_text)
    assert len(txs) == 2
    assert txs[0].amount == 12.50


def test_skips_rows_with_missing_fields():
    csv_text = "Date,Description,Amount\n2025-01-01,,-10.00\n2025-01-02,ACME,-5.00\n"
    txs = parse_transactions(csv_text)
    assert len(txs) == 1


def test_generic_amount_column_excludes_deposits():
    # Regression test: a signed single "Amount" column commonly has
    # negative = purchase, positive = deposit/refund/payroll. Positive
    # rows must NOT be treated as spend, otherwise things like payroll
    # deposits get misdetected as (very expensive) "subscriptions".
    csv_text = (
        "Date,Description,Amount\n"
        "2025-01-01,NETFLIX.COM,-15.99\n"
        "2025-01-15,PAYROLL DIRECT DEP,2450.00\n"
        "2025-02-01,NETFLIX.COM,-15.99\n"
        "2025-01-29,REFUND FROM ACME,25.00\n"
    )
    txs = parse_transactions(csv_text)
    descs = [t.description for t in txs]
    assert "PAYROLL DIRECT DEP" not in descs
    assert "REFUND FROM ACME" not in descs
    assert all(t.amount > 0 for t in txs)
    assert len(txs) == 2  # only the two Netflix charges


def test_unsigned_debit_column_treats_positive_as_spend():
    # A column explicitly named "Debit" is unsigned by convention: every
    # value in it already represents money out, so positive values there
    # ARE real spend (unlike a generic signed "Amount" column).
    csv_text = "Date,Description,Debit\n2025-01-01,GYM MEMBERSHIP,45.00\n2025-02-01,GYM MEMBERSHIP,45.00\n"
    txs = parse_transactions(csv_text)
    assert len(txs) == 2
    assert txs[0].amount == 45.00
