import csv
import io
import os

from subsleuth.detector import find_subscriptions
from subsleuth.exporter import to_csv, to_ics
from subsleuth.parser import parse_transactions

FIXTURE_DIR = os.path.join(os.path.dirname(__file__), "fixtures")


def load_fixture(name):
    with open(os.path.join(FIXTURE_DIR, name), encoding="utf-8") as f:
        return f.read()


def _subs():
    txs = parse_transactions(load_fixture("sample_statement.csv"))
    return find_subscriptions(txs)


def test_ics_contains_valid_calendar_structure():
    ics = to_ics(_subs())
    assert ics.startswith("BEGIN:VCALENDAR")
    assert ics.strip().endswith("END:VCALENDAR")
    assert ics.count("BEGIN:VEVENT") == ics.count("END:VEVENT")
    assert ics.count("BEGIN:VEVENT") == len(_subs())


def test_ics_events_reference_each_merchant():
    ics = to_ics(_subs())
    assert "Netflix" in ics or "NETFLIX" in ics.upper()
    assert "SUMMARY:" in ics
    assert "DTSTART;VALUE=DATE:" in ics


def test_ics_reminder_is_before_next_due_date():
    subs = _subs()
    ics = to_ics(subs, reminder_days_before=3)
    netflix = next(s for s in subs if "NETFLIX" in s.merchant)
    expected_reminder = (netflix.next_due_date.replace(day=netflix.next_due_date.day)).isoformat()
    # reminder date should be strictly earlier than the predicted charge date
    from datetime import timedelta
    reminder_date = netflix.next_due_date - timedelta(days=3)
    assert reminder_date.strftime("%Y%m%d") in ics


def test_csv_export_has_header_and_rows_for_each_subscription():
    subs = _subs()
    csv_text = to_csv(subs)
    rows = list(csv.reader(io.StringIO(csv_text)))
    assert rows[0][0] == "merchant"
    assert len(rows) == len(subs) + 1


def test_csv_export_includes_price_hike_columns():
    subs = _subs()
    csv_text = to_csv(subs)
    rows = list(csv.DictReader(io.StringIO(csv_text)))
    netflix_row = next(r for r in rows if "NETFLIX" in r["merchant"])
    assert netflix_row["price_hike_previous"] != ""
    assert float(netflix_row["price_hike_new"]) == 17.99


def test_empty_subscriptions_still_produce_valid_ics_and_csv():
    assert to_ics([]).strip() == "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//SubSleuth//Subscription Renewal Reminders//EN\r\nCALSCALE:GREGORIAN\r\nEND:VCALENDAR"
    csv_text = to_csv([])
    rows = list(csv.reader(io.StringIO(csv_text)))
    assert len(rows) == 1  # header only
