"""Human-readable report rendering."""
from __future__ import annotations

import json
from typing import List

from .detector import Subscription, summarize


def to_json(subscriptions: List[Subscription]) -> str:
    payload = {
        "summary": summarize(subscriptions),
        "subscriptions": [s.to_dict() for s in subscriptions],
    }
    return json.dumps(payload, indent=2)


def to_text(subscriptions: List[Subscription]) -> str:
    lines = []
    summary = summarize(subscriptions)
    lines.append("SubSleuth report")
    lines.append("=" * 60)
    if not subscriptions:
        lines.append("No recurring subscriptions detected in this statement.")
        return "\n".join(lines)

    lines.append(
        f"Found {summary['subscription_count']} recurring charge(s), "
        f"{summary['active_count']} still active  |  "
        f"~${summary['estimated_total_monthly_cost']:.2f}/mo  |  "
        f"~${summary['estimated_total_annual_cost']:.2f}/yr (active only)"
    )
    if summary["price_hikes_detected"]:
        lines.append(f"⚠ {summary['price_hikes_detected']} price increase(s) detected")
    lines.append("-" * 60)

    for s in subscriptions:
        status = "CANCELLED?" if s.likely_cancelled else "active"
        lines.append(f"{s.merchant}  ({s.frequency}, {s.occurrences}x seen)  [{status}]")
        lines.append(
            f"    avg ${s.average_amount:.2f}/charge  ->  "
            f"~${s.estimated_monthly_cost:.2f}/mo  (~${s.estimated_annual_cost:.2f}/yr)"
        )
        lines.append(f"    first: {s.first_seen}   last: {s.last_seen}")
        if s.price_hike:
            ph = s.price_hike
            lines.append(
                f"    ⚠ PRICE HIKE: ${ph['previous_amount']:.2f} -> "
                f"${ph['new_amount']:.2f}  (+{ph['increase_pct']:.1f}%)"
            )
        lines.append("")

    return "\n".join(lines)
