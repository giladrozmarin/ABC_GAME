"""Detect recurring subscriptions and price hikes from parsed transactions."""
from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Dict, List, Optional

from .parser import Transaction

# (label, min_days, max_days, occurrences_per_year)
FREQUENCY_BANDS = [
    ("weekly", 5, 9, 52),
    ("biweekly", 10, 18, 26),
    ("monthly", 24, 36, 12),
    ("quarterly", 80, 100, 4),
    ("yearly", 350, 380, 1),
]

AMOUNT_CV_THRESHOLD = 0.15  # coefficient of variation above this => not a subscription
INTERVAL_CV_THRESHOLD = 0.3
PRICE_HIKE_MIN_PCT = 0.03
PRICE_HIKE_MIN_ABS = 0.25


@dataclass
class Subscription:
    merchant: str
    frequency: str
    occurrences: int
    first_seen: date
    last_seen: date
    average_amount: float
    latest_amount: float
    estimated_monthly_cost: float
    estimated_annual_cost: float
    total_paid_in_period: float
    next_due_date: Optional[date] = None
    price_hike: Optional[dict] = None
    transactions: List[Transaction] = field(default_factory=list)
    likely_cancelled: bool = False

    def to_dict(self) -> dict:
        d = {
            "merchant": self.merchant,
            "frequency": self.frequency,
            "occurrences": self.occurrences,
            "first_seen": self.first_seen.isoformat(),
            "last_seen": self.last_seen.isoformat(),
            "average_amount": round(self.average_amount, 2),
            "latest_amount": round(self.latest_amount, 2),
            "estimated_monthly_cost": round(self.estimated_monthly_cost, 2),
            "estimated_annual_cost": round(self.estimated_annual_cost, 2),
            "total_paid_in_period": round(self.total_paid_in_period, 2),
            "next_due_date": self.next_due_date.isoformat() if self.next_due_date else None,
            "likely_cancelled": self.likely_cancelled,
        }
        if self.price_hike:
            d["price_hike"] = self.price_hike
        return d


def _classify_frequency(intervals: List[int]) -> Optional[tuple]:
    if not intervals:
        return None
    median = statistics.median(intervals)
    for label, lo, hi, per_year in FREQUENCY_BANDS:
        if lo <= median <= hi:
            return label, per_year
    return None


def _coefficient_of_variation(values: List[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = statistics.mean(values)
    if mean == 0:
        return float("inf")
    stdev = statistics.pstdev(values)
    return stdev / mean


def group_by_merchant(transactions: List[Transaction]) -> Dict[str, List[Transaction]]:
    groups: Dict[str, List[Transaction]] = {}
    for t in transactions:
        groups.setdefault(t.merchant, []).append(t)
    for group in groups.values():
        group.sort(key=lambda t: t.date)
    return groups


def find_subscriptions(
    transactions: List[Transaction], today: Optional[date] = None
) -> List[Subscription]:
    """Analyze transactions and return the list of detected subscriptions,
    sorted by estimated monthly cost (highest first).

    `today` defaults to the most recent transaction date in the file, and is
    used to flag subscriptions that were likely already cancelled: if it's
    been more than ~2x their normal billing interval since the last charge,
    we assume it stopped (so it isn't double-counted in the "you're
    currently paying for this" totals).
    """
    if today is None:
        today = max((t.date for t in transactions), default=date.today())

    groups = group_by_merchant(transactions)
    results: List[Subscription] = []

    for merchant, txs in groups.items():
        if len(txs) < 2:
            continue

        amounts = [t.amount for t in txs]
        if _coefficient_of_variation(amounts) > AMOUNT_CV_THRESHOLD:
            continue  # amounts too irregular to be a fixed subscription

        dates = [t.date for t in txs]
        intervals = [(dates[i + 1] - dates[i]).days for i in range(len(dates) - 1)]
        if intervals and _coefficient_of_variation([float(i) for i in intervals]) > INTERVAL_CV_THRESHOLD:
            continue  # timing too irregular

        classification = _classify_frequency(intervals)
        if classification is None:
            continue
        frequency, occurrences_per_year = classification

        typical_interval_days = round(statistics.median(intervals)) if intervals else 30
        next_due_date = dates[-1] + timedelta(days=typical_interval_days)
        likely_cancelled = (today - dates[-1]).days > typical_interval_days * 2 + 10

        average_amount = statistics.mean(amounts)
        latest_amount = amounts[-1]
        estimated_monthly = average_amount * occurrences_per_year / 12
        estimated_annual = average_amount * occurrences_per_year

        price_hike = None
        if len(amounts) >= 2:
            # Find where the "current price" plateau begins (trailing run of
            # amounts close to the latest charge), then compare it to
            # whatever was charged immediately before that plateau. This
            # catches a one-time step up (e.g. $15.49 -> $17.99) without
            # being skewed by how many months have passed since the hike.
            plateau_start = len(amounts) - 1
            while plateau_start > 0 and abs(amounts[plateau_start - 1] - latest_amount) <= max(
                PRICE_HIKE_MIN_ABS, latest_amount * PRICE_HIKE_MIN_PCT
            ):
                plateau_start -= 1
            if plateau_start > 0:
                baseline = statistics.mean(amounts[:plateau_start])
                if baseline > 0:
                    delta = latest_amount - baseline
                    pct = delta / baseline
                    if delta >= PRICE_HIKE_MIN_ABS and pct >= PRICE_HIKE_MIN_PCT:
                        price_hike = {
                            "previous_amount": round(baseline, 2),
                            "new_amount": round(latest_amount, 2),
                            "increase_amount": round(delta, 2),
                            "increase_pct": round(pct * 100, 1),
                        }

        results.append(
            Subscription(
                merchant=merchant,
                frequency=frequency,
                occurrences=len(txs),
                first_seen=dates[0],
                last_seen=dates[-1],
                average_amount=average_amount,
                latest_amount=latest_amount,
                estimated_monthly_cost=estimated_monthly,
                estimated_annual_cost=estimated_annual,
                total_paid_in_period=sum(amounts),
                next_due_date=next_due_date,
                price_hike=price_hike,
                transactions=txs,
                likely_cancelled=likely_cancelled,
            )
        )

    results.sort(key=lambda s: s.estimated_monthly_cost, reverse=True)
    return results


def summarize(subscriptions: List[Subscription]) -> dict:
    active = [s for s in subscriptions if not s.likely_cancelled]
    total_monthly = sum(s.estimated_monthly_cost for s in active)
    total_annual = sum(s.estimated_annual_cost for s in active)
    hikes = [s for s in subscriptions if s.price_hike]
    return {
        "subscription_count": len(subscriptions),
        "active_count": len(active),
        # Cost totals only count subscriptions we believe are still active,
        # so a cancelled gym membership from 8 months ago doesn't inflate
        # "what you're currently paying" totals.
        "estimated_total_monthly_cost": round(total_monthly, 2),
        "estimated_total_annual_cost": round(total_annual, 2),
        "price_hikes_detected": len(hikes),
    }
