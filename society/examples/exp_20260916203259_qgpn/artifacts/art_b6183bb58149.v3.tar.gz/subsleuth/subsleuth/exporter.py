"""Export detected subscriptions as a calendar (.ics) or CSV, so users get
actionable renewal reminders instead of just a report they read once."""
from __future__ import annotations

import csv
import io
import uuid
from datetime import date, datetime, timedelta
from typing import List

from .detector import Subscription

REMINDER_DAYS_BEFORE = 3


def _fold_ics_line(line: str) -> str:
    # RFC5545 requires long lines to be folded at 75 octets; our lines are
    # short enough in practice, but keep this simple and correct anyway.
    return line


def to_ics(subscriptions: List[Subscription], reminder_days_before: int = REMINDER_DAYS_BEFORE) -> str:
    """Build an .ics calendar with one all-day event per subscription per
    predicted renewal, placed `reminder_days_before` days before the
    predicted charge date, so the user can decide to cancel in time.
    Import this file into Google Calendar / Apple Calendar / Outlook.
    """
    now = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//SubSleuth//Subscription Renewal Reminders//EN",
        "CALSCALE:GREGORIAN",
    ]

    for s in subscriptions:
        if not s.next_due_date:
            continue
        reminder_date = s.next_due_date - timedelta(days=reminder_days_before)
        dtstart = reminder_date.strftime("%Y%m%d")
        dtend = (reminder_date + timedelta(days=1)).strftime("%Y%m%d")
        uid = f"{uuid.uuid5(uuid.NAMESPACE_DNS, s.merchant + s.next_due_date.isoformat())}@subsleuth"
        summary = f"{s.merchant.title()} renews ~{s.next_due_date.isoformat()} (${s.latest_amount:.2f})"
        description = (
            f"SubSleuth detected a {s.frequency} charge from {s.merchant} "
            f"(avg ${s.average_amount:.2f}). Predicted next charge: "
            f"{s.next_due_date.isoformat()}. Decide now if you want to keep or cancel it."
        )
        lines += [
            "BEGIN:VEVENT",
            f"UID:{uid}",
            f"DTSTAMP:{now}",
            f"DTSTART;VALUE=DATE:{dtstart}",
            f"DTEND;VALUE=DATE:{dtend}",
            f"SUMMARY:{_fold_ics_line(summary)}",
            f"DESCRIPTION:{_fold_ics_line(description)}",
            "END:VEVENT",
        ]

    lines.append("END:VCALENDAR")
    return "\r\n".join(lines) + "\r\n"


def to_csv(subscriptions: List[Subscription]) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(
        [
            "merchant",
            "frequency",
            "occurrences",
            "first_seen",
            "last_seen",
            "average_amount",
            "latest_amount",
            "estimated_monthly_cost",
            "estimated_annual_cost",
            "next_due_date",
            "price_hike_previous",
            "price_hike_new",
            "price_hike_pct",
        ]
    )
    for s in subscriptions:
        d = s.to_dict()
        ph = d.get("price_hike") or {}
        writer.writerow(
            [
                d["merchant"],
                d["frequency"],
                d["occurrences"],
                d["first_seen"],
                d["last_seen"],
                d["average_amount"],
                d["latest_amount"],
                d["estimated_monthly_cost"],
                d["estimated_annual_cost"],
                d["next_due_date"],
                ph.get("previous_amount", ""),
                ph.get("new_amount", ""),
                ph.get("increase_pct", ""),
            ]
        )
    return buf.getvalue()
