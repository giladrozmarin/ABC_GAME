"""Minimal Flask demo UI: upload a CSV, see your subscriptions, download a
renewal-reminder calendar or CSV report."""
from __future__ import annotations

import os

from flask import Flask, Response, render_template, request

from .categorize import categorize, category_breakdown
from .detector import find_subscriptions, summarize
from .exporter import to_csv, to_ics
from .parser import ParseError, parse_transactions

_TEMPLATE_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "templates")
app = Flask(__name__, template_folder=_TEMPLATE_DIR)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5MB upload cap


def _analyze(file_storage):
    text = file_storage.read().decode("utf-8-sig", errors="replace")
    transactions = parse_transactions(text)
    if not transactions:
        raise ParseError("No usable transactions found in that file.")
    return find_subscriptions(transactions)


@app.route("/", methods=["GET", "POST"])
def index():
    context = {"subscriptions": None, "summary": None, "error": None, "categories": None}
    if request.method == "POST":
        file = request.files.get("csv_file")
        if not file or file.filename == "":
            context["error"] = "Please choose a CSV file to upload."
        else:
            try:
                subs = _analyze(file)
                sub_dicts = [s.to_dict() for s in subs]
                for s, d in zip(subs, sub_dicts):
                    d["category"] = categorize(s.merchant)
                context["subscriptions"] = sub_dicts
                context["summary"] = summarize(subs)
                context["categories"] = category_breakdown([s for s in subs if not s.likely_cancelled])
            except ParseError as e:
                context["error"] = str(e)
    return render_template("index.html", **context)


@app.route("/export/ics", methods=["POST"])
def export_ics():
    file = request.files.get("csv_file")
    if not file or file.filename == "":
        return "Please choose a CSV file.", 400
    try:
        subs = _analyze(file)
    except ParseError as e:
        return str(e), 400
    body = to_ics(subs)
    return Response(
        body,
        mimetype="text/calendar",
        headers={"Content-Disposition": "attachment; filename=subsleuth_renewals.ics"},
    )


@app.route("/export/csv", methods=["POST"])
def export_csv():
    file = request.files.get("csv_file")
    if not file or file.filename == "":
        return "Please choose a CSV file.", 400
    try:
        subs = _analyze(file)
    except ParseError as e:
        return str(e), 400
    body = to_csv(subs)
    return Response(
        body,
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=subsleuth_report.csv"},
    )


def main():
    app.run(debug=False, host="127.0.0.1", port=5050)


if __name__ == "__main__":
    main()
