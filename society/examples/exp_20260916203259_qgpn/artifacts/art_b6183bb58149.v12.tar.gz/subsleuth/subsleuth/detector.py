"""Detect recurring subscriptions and price hikes from parsed transactions."""
from __future__ import annotations

import statistics
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Dict, List, Optional

from .parser import Transaction

# (label, min_days, max_days, occurrences_per_year)
FREQUENCY_BANDS = [
    ("weekly", 5, 9, 52),
    ("biweekly", 10, 18, 26),
    ("monthly", 24, 36, 12),
    ("quarterly", 80, 100, 4),
    ("yearly", 350, 380, 1),
]

AMOUNT_CV_THRESHOLD = 0.15  # coefficient of variation above this => not a subscription
MIN_GAP_MATCH_RATIO = 0.7  # fraction of individual gaps (not just the average!) that must fit a band
PRICE_HIKE_MIN_PCT = 0.03
PRICE_HIKE_MIN_ABS = 0.25


@dataclass
class Subscription:
    merchant: str
    frequency: str
    occurrences: int
    first_seen: date
    last_seen: date
    average_amount: float
    latest_amount: float
    estimated_monthly_cost: float
    estimated_annual_cost: float
    total_paid_in_period: float
    next_due_date: Optional[date] = None
    price_hike: Optional[dict] = None
    likely_cancelled: bool = False
    transactions: List[Transaction] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = {
            "merchant": self.merchant,
            "frequency": self.frequency,
            "occurrences": self.occurrences,
            "first_seen": self.first_seen.isoformat(),
            "last_seen": self.last_seen.isoformat(),
            "average_amount": round(self.average_amount, 2),
            "latest_amount": round(self.latest_amount, 2),
            "estimated_monthly_cost": round(self.estimated_monthly_cost, 2),
            "estimated_annual_cost": round(self.estimated_annual_cost, 2),
            "total_paid_in_period": round(self.total_paid_in_period, 2),
            "next_due_date": self.next_due_date.isoformat() if self.next_due_date else None,
            "likely_cancelled": self.likely_cancelled,
        }
        if self.price_hike:
            d["price_hike"] = self.price_hike
        return d


def _classify_frequency(intervals: List[int]) -> Optional[tuple]:
    """Pick the best-fitting billing cadence for a merchant's charge dates.

    Credit: this per-gap matching approach (require most *individual* gaps
    to fit a band, not just the average/median) was contributed by teammate
    A after testing against noisy synthetic data — it catches real
    subscriptions with one irregular gap (e.g. a skipped/late charge) while
    still rejecting merchants whose gaps are only regular "on average" by
    coincidence (e.g. two unrelated purchase patterns that happen to
    average out to ~30 days apart).
    """
    if not intervals:
        return None
    best = None  # (label, per_year, ratio)
    for label, lo, hi, per_year in FREQUENCY_BANDS:
        matching = sum(1 for d in intervals if lo <= d <= hi)
        ratio = matching / len(intervals)
        if ratio < MIN_GAP_MATCH_RATIO:
            continue
        if best is None or ratio > best[2]:
            best = (label, per_year, ratio)
    if best is None:
        return None
    return best[0], best[1]


def _coefficient_of_variation(values: List[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = statistics.mean(values)
    if mean == 0:
        return float("inf")
    stdev = statistics.pstdev(values)
    return stdev / mean


def group_by_merchant(transactions: List[Transaction]) -> Dict[str, List[Transaction]]:
    groups: Dict[str, List[Transaction]] = {}
    for t in transactions:
        groups.setdefault(t.merchant, []).append(t)
    for group in groups.values():
        group.sort(key=lambda t: t.date)
    return groups


def find_subscriptions(transactions: List[Transaction], as_of_date: Optional[date] = None) -> List[Subscription]:
    """Analyze transactions and return the list of detected subscriptions,
    sorted by estimated monthly cost (highest first).

    `as_of_date` is the reference "today" used to decide whether a
    subscription looks like it was already cancelled (no charge for more
    than 2x its expected billing interval). Defaults to the most recent
    transaction date in the file, since we can't assume the statement is
    up to the current wall-clock date.
    """
    if not transactions:
        return []

    if as_of_date is None:
        as_of_date = max(t.date for t in transactions)

    groups = group_by_merchant(transactions)
    results: List[Subscription] = []

    for merchant, txs in groups.items():
        if len(txs) < 2:
            continue

        amounts = [t.amount for t in txs]
        if _coefficient_of_variation(amounts) > AMOUNT_CV_THRESHOLD:
            continue  # amounts too irregular to be a fixed subscription

        dates = [t.date for t in txs]
        intervals = [(dates[i + 1] - dates[i]).days for i in range(len(dates) - 1)]

        classification = _classify_frequency(intervals)
        if classification is None:
            continue
        frequency, occurrences_per_year = classification

        typical_interval_days = round(statistics.median(intervals)) if intervals else 30
        next_due_date = dates[-1] + timedelta(days=typical_interval_days)
        days_since_last_charge = (as_of_date - dates[-1]).days
        likely_cancelled = days_since_last_charge > typical_interval_days * 2

        average_amount = statistics.mean(amounts)
        latest_amount = amounts[-1]
        estimated_monthly = average_amount * occurrences_per_year / 12
        estimated_annual = average_amount * occurrences_per_year

        price_hike = None
        if len(amounts) >= 2:
            # Find where the "current price" plateau begins (trailing run of
            # amounts close to the latest charge), then compare it to
            # whatever was charged immediately before that plateau. This
            # catches a one-time step up (e.g. $15.49 -> $17.99) without
            # being skewed by how many months have passed since the hike.
            plateau_start = len(amounts) - 1
            while plateau_start > 0 and abs(amounts[plateau_start - 1] - latest_amount) <= max(
                PRICE_HIKE_MIN_ABS, latest_amount * PRICE_HIKE_MIN_PCT
            ):
                plateau_start -= 1
            if plateau_start > 0:
                baseline = statistics.mean(amounts[:plateau_start])
                if baseline > 0:
                    delta = latest_amount - baseline
                    pct = delta / baseline
                    if delta >= PRICE_HIKE_MIN_ABS and pct >= PRICE_HIKE_MIN_PCT:
                        price_hike = {
                            "previous_amount": round(baseline, 2),
                            "new_amount": round(latest_amount, 2),
                            "increase_amount": round(delta, 2),
                            "increase_pct": round(pct * 100, 1),
                        }

        results.append(
            Subscription(
                merchant=merchant,
                frequency=frequency,
                occurrences=len(txs),
                first_seen=dates[0],
                last_seen=dates[-1],
                average_amount=average_amount,
                latest_amount=latest_amount,
                estimated_monthly_cost=estimated_monthly,
                estimated_annual_cost=estimated_annual,
                total_paid_in_period=sum(amounts),
                next_due_date=next_due_date,
                price_hike=price_hike,
                likely_cancelled=likely_cancelled,
                transactions=txs,
            )
        )

    results.sort(key=lambda s: s.estimated_monthly_cost, reverse=True)
    return results


def summarize(subscriptions: List[Subscription]) -> dict:
    active = [s for s in subscriptions if not s.likely_cancelled]
    cancelled = [s for s in subscriptions if s.likely_cancelled]
    total_monthly = sum(s.estimated_monthly_cost for s in active)
    total_annual = sum(s.estimated_annual_cost for s in active)
    hikes = [s for s in subscriptions if s.price_hike]
    return {
        "subscription_count": len(active),
        "estimated_total_monthly_cost": round(total_monthly, 2),
        "estimated_total_annual_cost": round(total_annual, 2),
        "price_hikes_detected": len(hikes),
        "likely_cancelled_count": len(cancelled),
    }
