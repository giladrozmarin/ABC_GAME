"""SubSleuth: find recurring subscriptions and price hikes hiding in your bank CSV export."""

__version__ = "0.1.0"
