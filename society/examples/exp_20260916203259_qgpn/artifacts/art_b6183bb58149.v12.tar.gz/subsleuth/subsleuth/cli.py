"""Command-line entry point: `subsleuth statement.csv`"""
from __future__ import annotations

import argparse
import sys

from .detector import find_subscriptions
from .exporter import to_csv, to_ics
from .parser import ParseError, parse_transactions
from .report import to_json, to_text


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="subsleuth",
        description="Find recurring subscriptions and price hikes hiding in a bank/credit-card CSV export.",
    )
    parser.add_argument("csv_file", help="Path to a CSV export (date, description, amount columns).")
    parser.add_argument("--json", action="store_true", help="Output machine-readable JSON instead of text.")
    parser.add_argument(
        "--ics", metavar="FILE", help="Write a calendar (.ics) of renewal reminders to FILE, importable into Google/Apple/Outlook calendars."
    )
    parser.add_argument("--csv-out", metavar="FILE", help="Write the subscription report as a CSV file to FILE.")
    args = parser.parse_args(argv)

    try:
        with open(args.csv_file, "r", encoding="utf-8-sig") as f:
            csv_text = f.read()
    except OSError as e:
        print(f"Error reading file: {e}", file=sys.stderr)
        return 1

    try:
        transactions = parse_transactions(csv_text)
    except ParseError as e:
        print(f"Could not parse CSV: {e}", file=sys.stderr)
        return 1

    if not transactions:
        print("No usable transactions found in that file.", file=sys.stderr)
        return 1

    subscriptions = find_subscriptions(transactions)
    output = to_json(subscriptions) if args.json else to_text(subscriptions)
    print(output)

    if args.ics:
        with open(args.ics, "w", encoding="utf-8") as f:
            f.write(to_ics(subscriptions))
        print(f"\nWrote calendar reminders to {args.ics}", file=sys.stderr)

    if args.csv_out:
        with open(args.csv_out, "w", encoding="utf-8", newline="") as f:
            f.write(to_csv(subscriptions))
        print(f"Wrote CSV report to {args.csv_out}", file=sys.stderr)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
