import os

from subsleuth.detector import find_subscriptions, summarize
from subsleuth.parser import parse_transactions

FIXTURE_DIR = os.path.join(os.path.dirname(__file__), "fixtures")


def load_fixture(name):
    with open(os.path.join(FIXTURE_DIR, name), encoding="utf-8") as f:
        return f.read()


def test_detects_known_subscriptions_from_sample_statement():
    txs = parse_transactions(load_fixture("sample_statement.csv"))
    subs = find_subscriptions(txs)
    merchants = {s.merchant for s in subs}

    assert any("NETFLIX" in m for m in merchants)
    assert any("SPOTIFY" in m for m in merchants)
    assert any("GYM" in m or "PLANET FITNESS" in m for m in merchants)


def test_excludes_irregular_grocery_spending():
    txs = parse_transactions(load_fixture("sample_statement.csv"))
    subs = find_subscriptions(txs)
    merchants = {s.merchant for s in subs}
    # Trader Joe's is visited often but with highly variable amounts and
    # irregular timing -> should NOT be classified as a subscription.
    assert not any("TRADER JOE" in m for m in merchants)


def test_excludes_single_occurrence_merchants():
    txs = parse_transactions(load_fixture("sample_statement.csv"))
    subs = find_subscriptions(txs)
    merchants = {s.merchant for s in subs}
    # Amazon Prime only appears once in the sample -> can't confirm recurrence.
    assert not any("AMAZON" in m for m in merchants)


def test_netflix_price_hike_detected():
    txs = parse_transactions(load_fixture("sample_statement.csv"))
    subs = find_subscriptions(txs)
    netflix = next(s for s in subs if "NETFLIX" in s.merchant)
    assert netflix.price_hike is not None
    assert netflix.price_hike["new_amount"] == 17.99
    assert netflix.price_hike["previous_amount"] == 15.49
    assert netflix.price_hike["increase_pct"] > 0


def test_spotify_has_no_price_hike():
    txs = parse_transactions(load_fixture("sample_statement.csv"))
    subs = find_subscriptions(txs)
    spotify = next(s for s in subs if "SPOTIFY" in s.merchant)
    assert spotify.price_hike is None


def test_monthly_cost_estimate_is_reasonable_for_netflix():
    txs = parse_transactions(load_fixture("sample_statement.csv"))
    subs = find_subscriptions(txs)
    netflix = next(s for s in subs if "NETFLIX" in s.merchant)
    assert netflix.frequency == "monthly"
    # average amount is between the two price points seen
    assert 15.0 <= netflix.estimated_monthly_cost <= 18.5


def test_summarize_totals_match_subscriptions():
    txs = parse_transactions(load_fixture("sample_statement.csv"))
    subs = find_subscriptions(txs)
    summary = summarize(subs)
    assert summary["subscription_count"] == len(subs)
    expected_monthly = round(sum(s.estimated_monthly_cost for s in subs), 2)
    assert summary["estimated_total_monthly_cost"] == expected_monthly
    assert summary["price_hikes_detected"] == sum(1 for s in subs if s.price_hike)


def test_empty_transaction_list_yields_no_subscriptions():
    assert find_subscriptions([]) == []


def test_likely_cancelled_subscription_is_flagged_and_excluded_from_totals():
    txs = parse_transactions(load_fixture("cancelled_subscription.csv"))
    subs = find_subscriptions(txs)

    hulu = next(s for s in subs if "HULU" in s.merchant)
    spotify = next(s for s in subs if "SPOTIFY" in s.merchant)

    assert hulu.likely_cancelled is True
    assert spotify.likely_cancelled is False

    summary = summarize(subs)
    # Only the still-active Spotify subscription should count toward totals.
    assert summary["subscription_count"] == 1
    assert summary["likely_cancelled_count"] == 1
    assert summary["estimated_total_monthly_cost"] == round(spotify.estimated_monthly_cost, 2)


def test_one_skipped_charge_still_detected_as_subscription():
    """A subscription with one irregular gap (e.g. a failed-then-retried
    charge skipping a month) should still be detected as recurring, because
    most of its individual gaps are regular -- even though the *average*
    gap and its coefficient of variation would look too noisy under a
    naive average-only check. Regression test for the per-gap matching
    contributed by teammate A."""
    txs = parse_transactions(load_fixture("one_skipped_month.csv"))
    subs = find_subscriptions(txs)
    merchants = {s.merchant for s in subs}
    assert any("DISNEY" in m for m in merchants)
    disney = next(s for s in subs if "DISNEY" in s.merchant)
    assert disney.frequency == "monthly"


def test_adversarial_mixed_signs_fixture_end_to_end():
    """End-to-end regression test (fixture contributed by C via adversarial
    testing) for a credit-card-style file: mostly-positive charges with a
    minority of negative refund/payment rows. RENT PAYMENT LLC (12 charges,
    one accompanied by an unrelated refund row elsewhere in the file) must
    still be detected at its correct $1500/mo amount, GYMCO MEMBERSHIP must
    be flagged as likely cancelled (stops in May), and SNEAKY CHARGE CO's
    irregular gaps must keep it excluded."""
    txs = parse_transactions(load_fixture("adversarial_mixed_signs.csv"))
    subs = find_subscriptions(txs)
    merchants = {s.merchant for s in subs}

    rent = next(s for s in subs if "RENT" in s.merchant)
    assert rent.average_amount == 1500.00
    assert rent.occurrences == 12
    assert not rent.likely_cancelled

    gymco = next(s for s in subs if "GYMCO" in s.merchant)
    assert gymco.likely_cancelled is True

    assert not any("SNEAKY" in m for m in merchants)


def test_cross_validation_against_independent_1yr_synthetic_statement():
    """Second, independently-authored 185-transaction synthetic 1-year
    statement (contributed by teammate A) used as a cross-validation
    fixture: confirms detection generalizes beyond our own sample data,
    and confirms the payroll-deposit parsing bug fix holds end-to-end
    (payroll must never appear as a detected subscription)."""
    txs = parse_transactions(load_fixture("sample_transactions_1yr.csv"))
    subs = find_subscriptions(txs)
    merchants = {s.merchant for s in subs}

    assert not any("PAYROLL" in m for m in merchants)
    assert any("NETFLIX" in m for m in merchants)
    assert any("SPOTIFY" in m for m in merchants)
    assert any("ADOBE" in m for m in merchants)
    assert any("ICLOUD" in m or "APPLE" in m for m in merchants)


def test_as_of_date_override_changes_cancellation_detection():
    txs = parse_transactions(load_fixture("cancelled_subscription.csv"))
    from datetime import date

    # As of right after Hulu's last charge, it should not yet look cancelled.
    subs = find_subscriptions(txs, as_of_date=date(2025, 4, 20))
    hulu = next(s for s in subs if "HULU" in s.merchant)
    assert hulu.likely_cancelled is False
