"""Verify SubSleuth works against realistic export formats from different
banks/card issuers, not just one synthetic fixture. Real exports vary in:
column names, sign conventions (debit-negative vs charge-positive), and
merchant-description noise (payment-processor prefixes like SQ *, PAYPAL *,
APLPAY)."""
import os

from subsleuth.detector import find_subscriptions
from subsleuth.parser import parse_transactions

FIXTURE_DIR = os.path.join(os.path.dirname(__file__), "fixtures")


def load_fixture(name):
    with open(os.path.join(FIXTURE_DIR, name), encoding="utf-8") as f:
        return f.read()


def test_chase_style_export_with_extra_columns_and_processor_prefixes():
    txs = parse_transactions(load_fixture("chase_style.csv"))
    assert len(txs) == 11
    subs = find_subscriptions(txs)
    merchants = {s.merchant for s in subs}

    # PAYPAL *NETFLIX ... and APLPAY SPOTIFY ... must be recognized despite
    # payment-processor prefixes and an embedded phone-like numeric ID.
    assert any("NETFLIX" in m for m in merchants)
    assert any("SPOTIFY" in m for m in merchants)
    # Coffee shop: same merchant, irregular amount/timing -> not a subscription.
    assert not any("BLUE BOTTLE" in m for m in merchants)


def test_amex_style_export_with_positive_charge_amounts():
    txs = parse_transactions(load_fixture("amex_style.csv"))
    assert len(txs) == 7
    assert all(t.amount > 0 for t in txs)
    subs = find_subscriptions(txs)
    merchants = {s.merchant for s in subs}

    assert any("ADOBE" in m for m in merchants)
    assert not any("UBER" in m for m in merchants)  # irregular trips, not a subscription

    adobe = next(s for s in subs if "ADOBE" in s.merchant)
    assert adobe.price_hike is not None
    assert adobe.price_hike["new_amount"] == 59.99
