import json
import os
import subprocess
import sys

FIXTURE = os.path.join(os.path.dirname(__file__), "fixtures", "sample_statement.csv")
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "subsleuth.cli", *args],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
    )


def test_cli_text_output():
    result = run_cli(FIXTURE)
    assert result.returncode == 0
    assert "NETFLIX" in result.stdout
    assert "PRICE HIKE" in result.stdout


def test_cli_json_output():
    result = run_cli(FIXTURE, "--json")
    assert result.returncode == 0
    payload = json.loads(result.stdout)
    assert payload["summary"]["subscription_count"] > 0
    assert any("NETFLIX" in s["merchant"] for s in payload["subscriptions"])


def test_cli_missing_file_errors_cleanly():
    result = run_cli("does_not_exist.csv")
    assert result.returncode == 1
    assert "Error reading file" in result.stderr
