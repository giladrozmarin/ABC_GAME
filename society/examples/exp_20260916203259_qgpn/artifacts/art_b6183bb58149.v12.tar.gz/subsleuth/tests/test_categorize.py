from subsleuth.categorize import categorize, category_breakdown
from subsleuth.detector import Subscription
from datetime import date


def test_categorize_known_merchants():
    assert categorize("NETFLIX.COM 866-579-7172") == "Streaming & Media"
    assert categorize("GEICO *AUTO INS PMT") == "Insurance"
    assert categorize("24HR FITNESS CLUB") == "Fitness & Health"


def test_categorize_unknown_falls_back_to_other():
    assert categorize("SOME RANDOM MERCHANT XYZ") == "Other"


def _sub(merchant, monthly_cost):
    return Subscription(
        merchant=merchant, frequency="monthly", occurrences=3,
        first_seen=date(2025, 1, 1), last_seen=date(2025, 3, 1),
        average_amount=monthly_cost, latest_amount=monthly_cost,
        estimated_monthly_cost=monthly_cost, estimated_annual_cost=monthly_cost * 12,
        total_paid_in_period=monthly_cost * 3,
    )


def test_category_breakdown_sums_by_category():
    subs = [_sub("NETFLIX", 15.0), _sub("SPOTIFY", 10.0), _sub("GEICO INS", 100.0)]
    breakdown = category_breakdown(subs)
    assert breakdown["Streaming & Media"] == 25.0
    assert breakdown["Insurance"] == 100.0
