import csv
import os
from datetime import date, timedelta

import pytest

from subsleuth.core import (
    Transaction,
    detect_subscriptions,
    normalize_merchant,
    parse_transactions,
    CSVFormatError,
)

SAMPLE_CSV = os.path.join(os.path.dirname(__file__), "..", "sample_data", "sample_transactions.csv")


def make_monthly(desc, amount, start, count, step_days=30):
    txs = []
    d = start
    for _ in range(count):
        txs.append(Transaction(date=d, description=desc, amount=amount))
        d = d + timedelta(days=step_days)
    return txs


def test_normalize_merchant_strips_noise():
    a = normalize_merchant("NETFLIX.COM 866-579-7172 CA")
    b = normalize_merchant("NETFLIX.COM 866-111-2222 CA")
    assert a == b
    assert "NETFLIX" in a


def test_normalize_merchant_strips_reference_numbers():
    a = normalize_merchant("AMAZON.COM*ZX99YQ")
    b = normalize_merchant("AMAZON.COM*AB12CD")
    # different one-off purchase refs still collapse to same merchant key
    assert a == b


def test_detects_simple_monthly_subscription():
    txs = make_monthly("NETFLIX.COM 866-579-7172", 15.99, date(2025, 1, 5), 6)
    subs = detect_subscriptions(txs, min_occurrences=3)
    assert len(subs) == 1
    s = subs[0]
    assert s.frequency == "monthly"
    assert s.occurrences == 6
    assert s.annualized_cost == pytest.approx(15.99 * 12, rel=0.01)


def test_ignores_one_off_purchase():
    txs = [
        Transaction(date=date(2025, 1, 1), description="BEST BUY 001", amount=899.0),
    ]
    subs = detect_subscriptions(txs, min_occurrences=3)
    assert subs == []


def test_ignores_irregular_charges():
    # Uber rides: same merchant, wildly different amounts and spacing
    dates = [date(2025, 1, 3), date(2025, 1, 19), date(2025, 2, 27), date(2025, 4, 11)]
    amounts = [12.30, 8.10, 31.50, 19.75]
    txs = [Transaction(date=d, description="UBER TRIP", amount=a) for d, a in zip(dates, amounts)]
    subs = detect_subscriptions(txs, min_occurrences=3)
    assert subs == []


def test_detects_yearly_subscription():
    txs = [
        Transaction(date=date(2023, 3, 1), description="AMAZON PRIME*A1", amount=139.0),
        Transaction(date=date(2024, 3, 1), description="AMAZON PRIME*B2", amount=139.0),
        Transaction(date=date(2025, 3, 1), description="AMAZON PRIME*C3", amount=139.0),
    ]
    subs = detect_subscriptions(txs, min_occurrences=3)
    assert len(subs) == 1
    assert subs[0].frequency == "yearly"
    assert subs[0].annualized_cost == pytest.approx(139.0)


def test_detects_price_increase():
    txs = (
        make_monthly("GYM DUES", 44.99, date(2025, 1, 1), 4)
        + make_monthly("GYM DUES", 49.99, date(2025, 5, 1), 3)
    )
    subs = detect_subscriptions(txs, min_occurrences=3)
    assert len(subs) == 1
    s = subs[0]
    assert s.price_increase_pct is not None
    assert s.price_increase_pct > 0


def test_below_min_occurrences_not_reported():
    txs = make_monthly("NETFLIX.COM", 15.99, date(2025, 1, 5), 2)
    subs = detect_subscriptions(txs, min_occurrences=3)
    assert subs == []


def test_refunds_and_negative_amounts_excluded_by_parser(tmp_path):
    csv_path = tmp_path / "tx.csv"
    with open(csv_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Date", "Description", "Amount"])
        w.writerow(["2025-01-01", "NETFLIX.COM", "15.99"])
        w.writerow(["2025-02-01", "NETFLIX.COM", "15.99"])
        w.writerow(["2025-03-01", "NETFLIX.COM", "15.99"])
        w.writerow(["2025-03-05", "REFUND", "-15.99"])
    txs = parse_transactions(str(csv_path))
    assert all(t.amount > 0 for t in txs)
    assert len(txs) == 3


def test_parse_sample_csv_end_to_end():
    txs = parse_transactions(SAMPLE_CSV)
    subs = detect_subscriptions(txs, min_occurrences=3)
    merchants = {s.merchant for s in subs}
    assert any("NETFLIX" in m for m in merchants)
    assert any("SPOTIFY" in m for m in merchants)
    assert any("FITNESS" in m for m in merchants)
    assert any("PRIME" in m for m in merchants)
    assert any("GEICO" in m for m in merchants)
    # one-off Amazon purchases and irregular Uber rides must not appear
    assert not any(m.startswith("BEST BUY") for m in merchants)
    assert not any("UBER" in m for m in merchants)
    # Netflix should show a detected price increase
    netflix = next(s for s in subs if "NETFLIX" in s.merchant)
    assert netflix.price_increase_pct is not None and netflix.price_increase_pct > 0


def test_malformed_csv_raises():
    import tempfile
    with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as f:
        f.write("foo,bar\n1,2\n")
        path = f.name
    with pytest.raises(CSVFormatError):
        parse_transactions(path)
