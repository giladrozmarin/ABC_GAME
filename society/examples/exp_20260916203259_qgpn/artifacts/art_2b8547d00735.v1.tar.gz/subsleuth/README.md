# SubSleuth

**Find the subscriptions that are quietly draining your bank account — from a CSV export, 100% locally.**

## The problem

Most people have 5-15 recurring charges hitting their card: streaming
services, gym memberships, apps, insurance, "free trials" that converted.
Nobody remembers all of them, banks don't summarize them for you, and
price hikes ($15.99 → $17.99) sail through unnoticed because they still
"look normal." The going solution is a paid app (Rocket Money, Trim, etc.)
that requires you to **hand your bank login to a third party** via Plaid.

SubSleuth solves the same problem — find recurring charges, flag price
increases, show total annual cost — from a CSV file you already have
(every bank and credit card lets you export transaction history), with
**zero network access and zero data leaving your machine.**

## Who this is for

Anyone who can export a CSV of their bank/credit-card transactions and
wants an honest answer to "what am I actually paying for every month?"
without installing an app that links to their bank.

## What it does

1. Parses a transactions CSV (auto-detects common column names/date/amount formats from Chase, Amex, Capital One, Mint-style exports, etc.).
2. Normalizes merchant descriptions (strips reference numbers, store codes, "POS", "REF#…" noise) so `NETFLIX.COM 866-579-7172 CA` on different months is recognized as the same merchant.
3. Groups charges by merchant + similar amount, then checks whether they land on a **consistent interval** (weekly/biweekly/monthly/quarterly/semiannual/yearly). Only consistent, repeated charges are called a "subscription" — a one-off $899 Best Buy purchase or five irregular Uber rides are correctly **not** flagged.
4. Computes each subscription's annualized cost and flags merchants whose charge amount **increased** between the first and most recent occurrence (a silent price hike).
5. Outputs a terminal table, a Markdown report, and/or JSON.

## Quick start

```bash
cd subsleuth
python3 -m venv .venv && source .venv/bin/activate
pip install -e .

# Try it on the included synthetic sample (2.5 years of realistic transactions)
subsleuth sample_data/sample_transactions.csv --markdown-out report.md
```

Example output:

```
Merchant           Freq       Occ  Last $  Annual $  First seen  Last seen   Price change
-----------------  ---------  ---  ------  --------  ----------  ----------  ------------
Geico Auto Ins     quarterly  10   312.40  1249.60   2023-01-20  2025-04-18  -
24Hr Fitness Club  monthly    30   44.99   539.88    2023-01-15  2025-06-04  -
Netflix Com Ca     monthly    30   17.99   215.88    2023-01-05  2025-05-23  +12.5%
Amazon Prime       yearly     3    139.00  139.00    2023-03-01  2025-03-01  -
Spotify Usa Ny     monthly    30   9.99    119.88    2023-01-10  2025-05-23  -

TOTAL detected recurring spend (annualized): $2264.24
```

Note it correctly **ignored**: two one-off Amazon purchases, a $899 Best
Buy purchase, five irregular Uber rides, and a refund — none of those are
subscriptions, and a naive "same merchant appears 3+ times" detector would
have wrongly flagged the Amazon and Uber ones.

### Using your own data

Export transactions from your bank/card as CSV (most banks: Account →
Download/Export → CSV, usually 6-24 months). Then:

```bash
subsleuth /path/to/your_export.csv --markdown-out my_report.md --json-out my_report.json
```

Useful flags:
- `--min-occurrences N` — how many matching charges are required before something counts as recurring (default 3; lower it to 2 for shorter exports at the cost of more false positives).
- `--amount-tolerance F` — fractional tolerance for grouping charges of slightly different amounts, e.g. tax-inclusive variation (default 0.15 = 15%).

## Running the tests

```bash
pip install pytest
python -m pytest -q
```

11 tests cover: merchant-name normalization, monthly/yearly/quarterly
detection, price-increase flagging, rejecting one-off purchases, rejecting
irregular charges (e.g. rideshare), refund/negative-amount handling, and a
full end-to-end run against the bundled sample CSV.

## Honest limitations

- **Heuristic, not perfect.** Detection is based on merchant-name
  similarity + amount similarity + interval regularity. A subscription
  that changed its billing descriptor entirely (not just a ref number)
  between charges may be missed. A tool with an unusually regular
  non-subscription pattern (e.g. a weekly grocery run at a near-identical
  total) could in principle be misclassified — in practice this is rare
  because amounts vary more than the tolerance allows, but it's possible.
- **Needs enough history.** With only 1-2 occurrences of a charge in the
  export, it can't be told apart from a one-off; the default
  `--min-occurrences 3` requires at least 3 charges, so subscriptions
  billed yearly need roughly 3 years of transaction history in the file
  to be detected with default settings (lower `--min-occurrences` to 2 to
  trade recall for precision on newer accounts).
- **CSV format coverage.** Column auto-detection and date-parsing cover the
  most common export conventions (Chase, Amex, Capital One, generic
  Date/Description/Amount), but an unusual export (e.g. separate Debit and
  Credit columns) may need a quick pre-processing step to normalize into a
  single signed `Amount` column first.
- **No merchant enrichment.** It doesn't know "Hulu" and "Disney+" are both
  "streaming" — there's no category tagging, just raw detection. That
  would be a reasonable next step (e.g. a small local keyword map).
- **Not a bank integration.** By design — you export the CSV yourself, so
  no credentials are ever requested or transmitted, which is also the
  point: this is safe for anyone uncomfortable linking bank credentials to
  a third-party app.

## Project layout

```
subsleuth/
  subsleuth/
    core.py      # CSV parsing, merchant normalization, recurrence detection
    report.py    # terminal table + Markdown report rendering
    cli.py       # argparse CLI entry point
  tests/
    test_core.py # 11 tests covering detection logic + edge cases
  sample_data/
    sample_transactions.csv  # synthetic 2.5-year transaction history for demo/tests
```
