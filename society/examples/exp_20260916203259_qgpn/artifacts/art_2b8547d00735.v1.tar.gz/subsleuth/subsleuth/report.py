"""Render detected subscriptions as a terminal table and a Markdown report."""
from __future__ import annotations

from .core import Subscription, total_annualized_cost


def to_terminal_table(subs: list[Subscription]) -> str:
    if not subs:
        return "No recurring subscriptions detected."
    headers = ["Merchant", "Freq", "Occ", "Last $", "Annual $", "First seen", "Last seen", "Price change"]
    rows = []
    for s in subs:
        change = f"+{s.price_increase_pct}%" if (s.price_increase_pct or 0) > 0 else (
            f"{s.price_increase_pct}%" if s.price_increase_pct else "-"
        )
        rows.append([
            s.merchant.title(),
            s.frequency,
            str(s.occurrences),
            f"{s.last_amount:.2f}",
            f"{s.annualized_cost:.2f}",
            s.first_seen.isoformat(),
            s.last_seen.isoformat(),
            change,
        ])
    widths = [max(len(h), *(len(r[i]) for r in rows)) for i, h in enumerate(headers)]
    lines = []
    lines.append("  ".join(h.ljust(widths[i]) for i, h in enumerate(headers)))
    lines.append("  ".join("-" * w for w in widths))
    for r in rows:
        lines.append("  ".join(c.ljust(widths[i]) for i, c in enumerate(r)))
    lines.append("")
    lines.append(f"TOTAL detected recurring spend (annualized): ${total_annualized_cost(subs):.2f}")
    return "\n".join(lines)


def to_markdown(subs: list[Subscription], source_file: str) -> str:
    lines = [
        "# SubSleuth Report",
        "",
        f"Source file: `{source_file}`",
        "",
        f"**{len(subs)} recurring subscriptions detected, "
        f"totaling an estimated ${total_annualized_cost(subs):.2f}/year.**",
        "",
        "| Merchant | Frequency | Occurrences | Last charge | Annualized | First seen | Last seen | Price change |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for s in subs:
        change = "-"
        if s.price_increase_pct:
            sign = "+" if s.price_increase_pct > 0 else ""
            flag = " ⚠️" if s.price_increase_pct > 0 else ""
            change = f"{sign}{s.price_increase_pct}%{flag}"
        lines.append(
            f"| {s.merchant.title()} | {s.frequency} | {s.occurrences} | "
            f"${s.last_amount:.2f} | ${s.annualized_cost:.2f} | {s.first_seen} | "
            f"{s.last_seen} | {change} |"
        )
    lines.append("")
    lines.append("## Notes")
    lines.append("")
    lines.append(
        "- 'Annualized' extrapolates the most recent charge amount at the detected "
        "frequency (e.g. monthly x 12)."
    )
    lines.append(
        "- Price change ⚠️ flags merchants whose charge increased between the first "
        "and most recent occurrence in this file — a common silent price hike."
    )
    lines.append(
        "- This tool only reads the CSV you give it. Nothing is uploaded anywhere."
    )
    return "\n".join(lines)
