"""SubSleuth: find recurring subscription charges hiding in your bank/card CSV export."""

__version__ = "0.1.0"
