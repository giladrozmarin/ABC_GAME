"""Core logic: parse transaction CSVs and detect recurring subscription charges."""
from __future__ import annotations

import csv
import re
import statistics
from dataclasses import dataclass, field
from datetime import datetime, date
from typing import Iterable, Optional

# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------

DATE_HEADER_CANDIDATES = [
    "date", "transaction date", "posted date", "posting date", "trans date",
]
DESC_HEADER_CANDIDATES = [
    "description", "desc", "memo", "name", "payee", "merchant", "transaction",
]
AMOUNT_HEADER_CANDIDATES = [
    "amount", "debit", "amount debit", "transaction amount", "value",
]

DATE_FORMATS = [
    "%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y", "%m-%d-%Y", "%d-%m-%Y",
    "%Y/%m/%d", "%m/%d/%y", "%d %b %Y", "%b %d, %Y", "%d/%m/%y",
]


@dataclass
class Transaction:
    date: date
    description: str
    amount: float  # positive = money spent (outflow)


class CSVFormatError(ValueError):
    pass


def _find_header(fieldnames: list[str], candidates: list[str]) -> Optional[str]:
    lower_map = {fn.strip().lower(): fn for fn in fieldnames}
    for cand in candidates:
        if cand in lower_map:
            return lower_map[cand]
    # fuzzy: substring match
    for fn_lower, fn in lower_map.items():
        for cand in candidates:
            if cand in fn_lower:
                return fn
    return None


def _parse_date(raw: str) -> Optional[date]:
    raw = raw.strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(raw, fmt).date()
        except ValueError:
            continue
    return None


def _parse_amount(raw: str) -> Optional[float]:
    if raw is None:
        return None
    s = raw.strip()
    if not s:
        return None
    negative = False
    if s.startswith("(") and s.endswith(")"):
        negative = True
        s = s[1:-1]
    s = s.replace("$", "").replace(",", "").replace("USD", "").strip()
    if s.startswith("-"):
        negative = True
        s = s[1:]
    elif s.startswith("+"):
        s = s[1:]
    try:
        val = float(s)
    except ValueError:
        return None
    return -val if negative else val


def parse_transactions(csv_path: str) -> list[Transaction]:
    """Parse a bank/card CSV export into a list of Transaction (outflows only).

    Handles common column-name variants and date/amount formats. Only
    transactions representing money leaving the account (spend) are kept;
    refunds/deposits (negative amounts under the "Debit is positive" convention,
    detected heuristically) are dropped from recurring-charge detection.
    """
    with open(csv_path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        if not reader.fieldnames:
            raise CSVFormatError("CSV file has no header row")
        fieldnames = [f for f in reader.fieldnames if f is not None]
        date_col = _find_header(fieldnames, DATE_HEADER_CANDIDATES)
        desc_col = _find_header(fieldnames, DESC_HEADER_CANDIDATES)
        amount_col = _find_header(fieldnames, AMOUNT_HEADER_CANDIDATES)
        if not date_col or not desc_col or not amount_col:
            raise CSVFormatError(
                f"Could not detect required columns (date/description/amount) "
                f"in header: {fieldnames}. Found date={date_col}, desc={desc_col}, "
                f"amount={amount_col}."
            )

        transactions: list[Transaction] = []
        for row in reader:
            d = _parse_date(row.get(date_col, "") or "")
            amt = _parse_amount(row.get(amount_col, "") or "")
            desc = (row.get(desc_col, "") or "").strip()
            if d is None or amt is None or not desc:
                continue
            # Only keep outflows (spend). Convention: positive amount = spend
            # in most exports (debit-positive). Skip zero and negative (refunds).
            if amt <= 0:
                continue
            transactions.append(Transaction(date=d, description=desc, amount=amt))
    if not transactions:
        raise CSVFormatError(
            "No valid spend transactions were parsed from the file. Check the "
            "date/amount formats match one of the supported conventions."
        )
    return transactions


# ---------------------------------------------------------------------------
# Merchant name normalization
# ---------------------------------------------------------------------------

_NOISE_PATTERNS = [
    r"\bPOS\b", r"\bDEBIT\b", r"\bPURCHASE\b", r"\bRECURRING\b", r"\bPAYMENT\b",
    r"\bREF\s*#?\s*\w*", r"\bAUTH\s*#?\s*\w*", r"\bCARD\s*\d*", r"\bTRAN\w*",
    r"#\d+", r"\*\d+", r"\d{4,}", r"\bXX+\d*\b",
]
_NOISE_RE = re.compile("|".join(_NOISE_PATTERNS), re.IGNORECASE)


def normalize_merchant(description: str) -> str:
    """Collapse a raw transaction description into a canonical merchant key."""
    s = description.upper()
    s = s.replace("*", " ").replace("-", " ").replace("_", " ")
    s = _NOISE_RE.sub(" ", s)
    s = re.sub(r"[^A-Z0-9 ]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    raw_tokens = [t for t in s.split(" ") if t]

    def is_code_token(idx: int, tok: str) -> bool:
        if tok.isdigit():
            return True
        has_digit = any(c.isdigit() for c in tok)
        has_alpha = any(c.isalpha() for c in tok)
        # Reference/order codes: short alphanumeric mixes that aren't the
        # leading token (leading tokens like "24HR" or "7ELEVEN" are real
        # brand names and should be kept).
        if idx > 0 and has_digit and has_alpha and len(tok) <= 10:
            return True
        return False

    tokens = [t for i, t in enumerate(raw_tokens) if not is_code_token(i, t)]
    # keep first 3 significant tokens as the key (merchant names rarely need more)
    key = " ".join(tokens[:3])
    return key or (raw_tokens[0] if raw_tokens else s)


# ---------------------------------------------------------------------------
# Recurrence detection
# ---------------------------------------------------------------------------

FREQUENCY_BANDS = [
    ("weekly", 6, 8, 52),
    ("biweekly", 12, 16, 26),
    ("monthly", 26, 35, 12),
    ("quarterly", 80, 100, 4),
    ("semiannual", 160, 200, 2),
    ("yearly", 340, 390, 1),
]


@dataclass
class Subscription:
    merchant: str
    sample_description: str
    frequency: str
    occurrences: int
    first_seen: date
    last_seen: date
    first_amount: float
    last_amount: float
    avg_amount: float
    annualized_cost: float
    price_increase_pct: Optional[float]
    amounts: list[float] = field(default_factory=list)
    dates: list[date] = field(default_factory=list)


def _classify_frequency(median_interval_days: float) -> Optional[tuple[str, int]]:
    for name, lo, hi, per_year in FREQUENCY_BANDS:
        if lo <= median_interval_days <= hi:
            return name, per_year
    return None


def detect_subscriptions(
    transactions: Iterable[Transaction],
    min_occurrences: int = 3,
    amount_tolerance: float = 0.15,
    interval_tolerance_days: float = 6.0,
) -> list[Subscription]:
    """Group transactions by normalized merchant + stable amount, then keep
    only groups whose charge dates fall on a consistent recurring interval.
    """
    groups: dict[str, list[Transaction]] = {}
    for tx in transactions:
        key = normalize_merchant(tx.description)
        groups.setdefault(key, []).append(tx)

    subscriptions: list[Subscription] = []
    for key, txs in groups.items():
        txs = sorted(txs, key=lambda t: t.date)
        if len(txs) < min_occurrences:
            continue

        # Split into sub-clusters by amount similarity (handles a merchant
        # with two different-priced recurring plans, e.g. Netflix upgrade).
        clusters: list[list[Transaction]] = []
        for tx in txs:
            placed = False
            for cluster in clusters:
                ref = cluster[-1].amount
                if ref == 0:
                    continue
                if abs(tx.amount - ref) / max(ref, 0.01) <= amount_tolerance:
                    cluster.append(tx)
                    placed = True
                    break
            if not placed:
                clusters.append([tx])

        for cluster in clusters:
            if len(cluster) < min_occurrences:
                continue
            cluster = sorted(cluster, key=lambda t: t.date)
            intervals = [
                (cluster[i + 1].date - cluster[i].date).days
                for i in range(len(cluster) - 1)
            ]
            if not intervals or any(iv <= 0 for iv in intervals):
                continue
            median_iv = statistics.median(intervals)
            spread = max(intervals) - min(intervals) if len(intervals) > 1 else 0
            classified = _classify_frequency(median_iv)
            if classified is None:
                continue
            # require reasonably consistent spacing
            if len(intervals) > 1 and spread > (median_iv * 0.5 + interval_tolerance_days):
                continue
            freq_name, per_year = classified
            amounts = [t.amount for t in cluster]
            avg_amount = sum(amounts) / len(amounts)
            first_amt, last_amt = amounts[0], amounts[-1]
            price_increase_pct = None
            if first_amt > 0 and abs(last_amt - first_amt) / first_amt > 0.01:
                price_increase_pct = round((last_amt - first_amt) / first_amt * 100, 1)
            subscriptions.append(
                Subscription(
                    merchant=key,
                    sample_description=cluster[-1].description,
                    frequency=freq_name,
                    occurrences=len(cluster),
                    first_seen=cluster[0].date,
                    last_seen=cluster[-1].date,
                    first_amount=first_amt,
                    last_amount=last_amt,
                    avg_amount=round(avg_amount, 2),
                    annualized_cost=round(last_amt * per_year, 2),
                    price_increase_pct=price_increase_pct,
                    amounts=amounts,
                    dates=[t.date for t in cluster],
                )
            )

    subscriptions.sort(key=lambda s: s.annualized_cost, reverse=True)
    return subscriptions


def total_annualized_cost(subs: list[Subscription]) -> float:
    return round(sum(s.annualized_cost for s in subs), 2)
