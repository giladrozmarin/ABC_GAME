# SubSleuth Report

Source file: `sample_data/sample_transactions.csv`

**5 recurring subscriptions detected, totaling an estimated $2264.24/year.**

| Merchant | Frequency | Occurrences | Last charge | Annualized | First seen | Last seen | Price change |
|---|---|---|---|---|---|---|---|
| Geico Auto Ins | quarterly | 10 | $312.40 | $1249.60 | 2023-01-20 | 2025-04-18 | - |
| 24Hr Fitness Club | monthly | 30 | $44.99 | $539.88 | 2023-01-15 | 2025-06-04 | - |
| Netflix Com Ca | monthly | 30 | $17.99 | $215.88 | 2023-01-05 | 2025-05-23 | +12.5% ⚠️ |
| Amazon Prime | yearly | 3 | $139.00 | $139.00 | 2023-03-01 | 2025-03-01 | - |
| Spotify Usa Ny | monthly | 30 | $9.99 | $119.88 | 2023-01-10 | 2025-05-23 | - |

## Notes

- 'Annualized' extrapolates the most recent charge amount at the detected frequency (e.g. monthly x 12).
- Price change ⚠️ flags merchants whose charge increased between the first and most recent occurrence in this file — a common silent price hike.
- This tool only reads the CSV you give it. Nothing is uploaded anywhere.