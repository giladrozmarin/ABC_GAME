# SubScope

**Find every subscription quietly draining your bank account — from a CSV
you already have.**

## The problem

Most people underestimate how much they spend on recurring
subscriptions/memberships by 2-3x. Netflix, Spotify, iCloud, a gym you
stopped going to, a meal kit you forgot to cancel, an app trial that started
billing — they're scattered across months of bank/credit-card history, in
amounts small enough that nobody sits down and manually reconciles them.
Apps like Rocket Money solve this but require you to link your bank
credentials to a third-party service (a real privacy/security cost) and are
subscriptions themselves.

**SubScope does the same job from a CSV file you export yourself, runs
entirely on your machine, and never sends your data anywhere.**

## What it actually does

Point it at a CSV export from your bank or credit card (every bank has an
"export transactions" button) and it:

1. Parses the export, tolerating the messy variety of real bank CSV formats
   (different column names, a single signed "Amount" column vs. separate
   "Debit"/"Credit" columns, different date formats, `($12.34)`-style
   negative amounts, etc).
2. Normalizes merchant descriptions (`NETFLIX.COM 8885062929 CA` and
   `NETFLIX.COM*A8X2K` become the same merchant) so charges from the same
   company group together even when the reference number changes every
   month.
3. Groups charges by merchant **and** amount, and only calls something a
   subscription if the *individual* gaps between charges are regular
   (weekly / biweekly / monthly / quarterly / semiannual / annual, within
   tolerance) — not just "this merchant charged me a similar amount a
   couple of times." This is what keeps it from flagging your weekly coffee
   habit or sporadic Amazon orders as a "subscription."
4. Flags **price increases** (e.g. Netflix going from $15.99 to $17.99).
5. Flags subscriptions that have likely already been **cancelled** (no
   charge for more than 2x their normal billing period) so you don't
   double-count spend you already stopped.
6. Estimates your **monthly and annual burn** from currently-active
   subscriptions, and predicts the next charge date for each.
7. Outputs a plain-text summary, a JSON report (for scripting/other tools),
   or a self-contained HTML dashboard you can open in any browser.

## Who this is for

Anyone who has ever been surprised by their bank statement — but concretely:
freelancers/individuals doing a personal finance cleanup, people trying to
cut expenses before a big purchase, or anyone who wants a second opinion on
"what am I actually paying for every month" without linking their real bank
credentials into a random app.

## Quickstart

```bash
cd subscope
pip install -e .

# export a CSV from your bank (checking or credit card), then:
subscope path/to/transactions.csv                       # human-readable report
subscope path/to/transactions.csv --format html -o report.html   # dashboard
subscope path/to/transactions.csv --format json -o report.json   # for scripts
```

No install needed either — it also runs directly:

```bash
python3 -m subscope.cli path/to/transactions.csv
```

### Or use the local web UI (no terminal skills required)

```bash
subscope-web
```

This opens `http://127.0.0.1:8765` in your browser with a drag-and-drop
upload form; drop your CSV in and get the same HTML dashboard back
instantly. It's a plain-stdlib `http.server`, runs only on localhost, and
never sends your file anywhere else — this is for the "I want to hand this
to a non-technical friend/relative" case.

### Try it right now with the included sample data

A realistic 1-year synthetic bank export is included at
`tests/sample_data/sample_transactions.csv` (185 transactions: 6 genuine
subscriptions — including one with a price increase and one that was
cancelled — plus realistic noise: irregular Amazon purchases, a variable
daily coffee habit, payroll deposits, and a one-off Best Buy purchase, none
of which should be flagged).

```bash
subscope tests/sample_data/sample_transactions.csv
```

Expected output (abridged):

```
Detected 6 recurring charge(s), 5 still active.
Estimated monthly burn:  $340.70
Estimated annual burn:   $4088.40
⚠ 1 subscription(s) had a price change.

- HELLOFRESH ...        weekly,  $59.94/charge  [active]
- ADOBE CREATIVE CLOUD  annual,  $599.88/charge [active]
- ANYTIME FITNESS       monthly, $44.99/charge  [CANCELLED?]
- NETFLIX.COM           monthly, $17.99/charge  [active] — price change $15.99 -> $17.99
- SPOTIFY USA           monthly, $9.99/charge   [active]
- APPLE.COM/BILL ICLOUD monthly, $2.99/charge   [active]
```

Note what it correctly does *not* flag: ~90 irregular Amazon and coffee-shop
purchases, 24 payroll deposits, and a single one-off Best Buy purchase. That
precision (no false positives on noisy real-world data) is the hard part of
this problem and is covered by tests.

## Where do I get a CSV?

Every major bank and credit card issuer supports exporting recent
transactions as CSV from their web portal (usually under
"Statements & documents" or "Download transactions"). SubScope doesn't
need or want your bank login — you export the file yourself and it never
leaves your machine.

## How detection works (so you can trust or distrust it)

See `subscope/detector.py`. In short: transactions are grouped by a
normalized merchant name, then split into amount-clusters (to separate a
subscription from unrelated purchases at the same merchant). A cluster is
called "recurring" only if it has at least 2-3 charges (2 for
annual/semiannual, since a year of data rarely contains 3) **and** at least
75% of the gaps between consecutive charges land within tolerance of a
known cadence (weekly/biweekly/monthly/quarterly/semiannual/annual). This
"most individual gaps must match" rule (not just the average) is
specifically what prevents coincidentally-similar-amount, irregularly-timed
purchases from being misclassified — see
`tests/test_detector.py::test_irregular_amount_purchases_are_not_flagged`
and `::test_irregular_timing_same_amount_is_not_flagged`.

## Honest limitations

- **Heuristic, not ground truth.** It infers subscriptions from patterns in
  transaction data; it cannot see your actual subscription list. Always
  double check before cancelling anything.
- **Needs history.** A subscription needs 2-3 charges in your export to be
  detected at all — a brand new subscription with 1 charge won't be caught
  yet (by design: 1 data point isn't a pattern).
- **Amount-column sign convention.** For CSVs with a single signed "Amount"
  column, SubScope assumes the common checking/debit-card convention
  (negative = money out). A minority of exports (mostly some credit-card
  statements) use the opposite convention; if your report looks inverted
  (everything shows as a deposit), that's why — export with separate
  Debit/Credit columns instead if your bank offers it, or flip signs before
  running.
- **Currency.** Amounts are parsed as plain numbers; multi-currency
  statements are not automatically converted.
- **"Likely cancelled" is a heuristic** based on elapsed time vs. billing
  period; a subscription paused right at the edge of the window may be
  mis-flagged either way.
- Merchant-name normalization is regex-based and tuned on common US bank
  statement patterns; unusual formats may under- or over-merge.

## Tests

```bash
pip install pytest
python3 -m pytest -v
```

23 tests cover CSV parsing edge cases (date formats, debit/credit columns,
parenthesized negatives, malformed rows), merchant-name normalization,
detector behavior (monthly/weekly/annual cadences, price-increase
detection, cancellation detection, and — most importantly — that noisy,
non-recurring spending is *not* misclassified as a subscription), and the
local web UI's upload/error handling.

## Project layout

```
subscope/
  subscope/
    parser.py    # CSV -> Transaction objects, format-tolerant
    detector.py  # Transaction list -> Subscription objects
    report.py    # Subscription list -> text / JSON / HTML
    cli.py        # `subscope` command
    webapp.py     # `subscope-web` local drag-and-drop UI
  tests/
    test_parser.py
    test_detector.py
    test_webapp.py
    sample_data/sample_transactions.csv
```

## Roadmap (not built yet — being honest about scope)

- OFX/QFX and PDF statement import (currently CSV only).
- Category tagging (streaming, fitness, software, etc).
- A "what if I cancel these" savings projector.
- Multi-account merge (checking + 2 credit cards in one report).
