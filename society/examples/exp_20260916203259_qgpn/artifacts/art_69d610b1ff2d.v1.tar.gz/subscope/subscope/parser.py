"""Parse bank/credit-card CSV exports into a normalized list of Transactions.

Real-world bank CSVs vary wildly in column names and layout. This parser
tries to be forgiving: it looks for common header spellings for date,
description and amount (or separate debit/credit columns), and falls back
to sensible heuristics when headers are ambiguous.
"""
from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass
from datetime import date, datetime
from typing import List, Optional, Sequence


@dataclass
class Transaction:
    date: date
    description: str
    amount: float  # positive = money spent (outflow); negative = inflow/refund
    raw_description: str
    row_number: int


DATE_FORMATS = [
    "%Y-%m-%d",
    "%m/%d/%Y",
    "%d/%m/%Y",
    "%m-%d-%Y",
    "%d-%m-%Y",
    "%Y/%m/%d",
    "%b %d, %Y",
    "%d %b %Y",
    "%m/%d/%y",
    "%d/%m/%y",
]

DATE_HEADER_CANDIDATES = ["date", "transaction date", "posted date", "posting date", "trans date"]
DESC_HEADER_CANDIDATES = ["description", "memo", "name", "merchant", "payee", "details", "narrative"]
AMOUNT_HEADER_CANDIDATES = ["amount", "transaction amount", "value"]
DEBIT_HEADER_CANDIDATES = ["debit", "withdrawal", "money out", "amount debit"]
CREDIT_HEADER_CANDIDATES = ["credit", "deposit", "money in", "amount credit"]


class ParseError(ValueError):
    pass


def _norm_header(h: str) -> str:
    return re.sub(r"\s+", " ", h.strip().lower())


def _find_header(headers: Sequence[str], candidates: Sequence[str]) -> Optional[int]:
    normed = [_norm_header(h) for h in headers]
    for cand in candidates:
        for i, h in enumerate(normed):
            if h == cand:
                return i
    for cand in candidates:
        for i, h in enumerate(normed):
            if cand in h:
                return i
    return None


def _parse_date(value: str) -> Optional[date]:
    value = value.strip()
    if not value:
        return None
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    # ISO datetime with time component
    try:
        return datetime.fromisoformat(value.split(" ")[0]).date()
    except ValueError:
        return None


def _parse_amount(value: str) -> Optional[float]:
    if value is None:
        return None
    v = value.strip()
    if v == "":
        return None
    neg = False
    if v.startswith("(") and v.endswith(")"):
        neg = True
        v = v[1:-1]
    v = v.replace("$", "").replace(",", "").replace("€", "").replace("£", "").strip()
    if v.endswith("-"):
        neg = True
        v = v[:-1]
    if v.startswith("-"):
        neg = True
        v = v[1:]
    if v.startswith("+"):
        v = v[1:]
    try:
        num = float(v)
    except ValueError:
        return None
    return -num if neg else num


def parse_csv(text: str) -> List[Transaction]:
    """Parse CSV text into Transactions.

    Sign convention: positive amount = money spent (an outflow, i.e. a
    candidate subscription charge). Most bank exports list purchases as
    negative numbers or in a "debit" column; both are normalized to positive
    "spent" amounts here. Refunds/deposits end up negative.
    """
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    reader = csv.reader(io.StringIO(text), dialect)
    rows = [r for r in reader if any(c.strip() for c in r)]
    if not rows:
        raise ParseError("CSV file is empty")

    headers = rows[0]
    data_rows = rows[1:]

    date_idx = _find_header(headers, DATE_HEADER_CANDIDATES)
    desc_idx = _find_header(headers, DESC_HEADER_CANDIDATES)
    amount_idx = _find_header(headers, AMOUNT_HEADER_CANDIDATES)
    debit_idx = _find_header(headers, DEBIT_HEADER_CANDIDATES)
    credit_idx = _find_header(headers, CREDIT_HEADER_CANDIDATES)

    if date_idx is None:
        raise ParseError(
            f"Could not find a date column in headers: {headers}. "
            "Expected one of: date, transaction date, posted date."
        )
    if desc_idx is None:
        raise ParseError(
            f"Could not find a description column in headers: {headers}. "
            "Expected one of: description, memo, merchant, payee."
        )
    if amount_idx is None and debit_idx is None and credit_idx is None:
        raise ParseError(
            f"Could not find an amount/debit/credit column in headers: {headers}."
        )

    transactions: List[Transaction] = []
    for i, row in enumerate(data_rows, start=2):
        if len(row) <= date_idx or len(row) <= desc_idx:
            continue
        d = _parse_date(row[date_idx])
        if d is None:
            continue
        raw_desc = row[desc_idx].strip()
        if not raw_desc:
            continue

        amount: Optional[float] = None
        if amount_idx is not None and len(row) > amount_idx:
            raw_amount = _parse_amount(row[amount_idx])
            if raw_amount is not None:
                # Convention for a single "amount" column, as used by most
                # checking/debit-card exports: negative = money out
                # (purchase), positive = money in (deposit/refund). We flip
                # sign so that, like the debit/credit case below, a positive
                # Transaction.amount always means "money spent".
                amount = -raw_amount
        if amount is None and debit_idx is not None and len(row) > debit_idx:
            debit = _parse_amount(row[debit_idx])
            if debit is not None and debit != 0:
                amount = abs(debit)
        if amount is None and credit_idx is not None and len(row) > credit_idx:
            credit = _parse_amount(row[credit_idx])
            if credit is not None and credit != 0:
                amount = -abs(credit)
        if amount is None:
            continue

        transactions.append(
            Transaction(
                date=d,
                description=normalize_description(raw_desc),
                amount=amount,
                raw_description=raw_desc,
                row_number=i,
            )
        )

    transactions.sort(key=lambda t: t.date)
    return transactions


_NOISE_PATTERNS = [
    r"\b\d{4,}\b",            # long numbers (card #s, transaction ids)
    r"\b\d{2}/\d{2}(/\d{2,4})?\b",  # embedded dates
    r"#\d+",
    r"\*+\d+",
    r"\bref[a-z]*\d[a-z0-9]*\b",  # reference codes like "ref029384756", not words like "refund"
    r"\bxxxx\S*\b",
    r"\b[a-z0-9]{8,}-[a-z0-9-]{4,}\b",  # uuid-ish
]


def normalize_description(desc: str) -> str:
    """Collapse a raw statement description into a stable merchant key.

    Bank descriptions often include store numbers, dates, or trailing
    reference codes that differ transaction to transaction even for the
    same merchant (e.g. "NETFLIX.COM 8885062929 CA" vs
    "NETFLIX.COM*AB12CD"). We strip common noise so recurring charges from
    the same merchant group together.
    """
    s = desc.lower()
    s = re.sub(r"[^a-z0-9\s.&'-]", " ", s)
    for pat in _NOISE_PATTERNS:
        s = re.sub(pat, " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    # Keep only the leading 4 tokens: merchant names rarely need more,
    # and trailing tokens are usually location/branch noise.
    tokens = s.split(" ")
    s = " ".join(tokens[:4])
    return s.strip()
