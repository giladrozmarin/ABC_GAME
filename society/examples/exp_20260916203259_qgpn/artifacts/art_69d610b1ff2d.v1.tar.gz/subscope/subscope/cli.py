"""Command-line interface for SubScope."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .detector import detect_subscriptions
from .parser import ParseError, parse_csv
from .report import to_html, to_json, to_text


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="subscope",
        description="Detect recurring subscriptions and creeping costs from a bank/card CSV export.",
    )
    parser.add_argument("csv_file", help="Path to a CSV export from your bank or credit card.")
    parser.add_argument(
        "--format",
        choices=["text", "json", "html"],
        default="text",
        help="Output format (default: text).",
    )
    parser.add_argument(
        "--output", "-o", help="Write report to this file instead of stdout."
    )
    parser.add_argument(
        "--min-occurrences",
        type=int,
        default=2,
        help="Minimum number of similar charges required to call something recurring (default: 2).",
    )
    args = parser.parse_args(argv)

    path = Path(args.csv_file)
    if not path.exists():
        print(f"error: file not found: {path}", file=sys.stderr)
        return 1

    text = path.read_text(errors="replace")
    try:
        transactions = parse_csv(text)
    except ParseError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    if not transactions:
        print("error: no valid transactions could be parsed from this file.", file=sys.stderr)
        return 1

    subs = detect_subscriptions(transactions, min_occurrences=args.min_occurrences)

    if args.format == "json":
        out = to_json(subs)
    elif args.format == "html":
        out = to_html(subs)
    else:
        out = to_text(subs)

    if args.output:
        Path(args.output).write_text(out)
        print(f"Wrote {args.format} report to {args.output} ({len(subs)} subscriptions found).")
    else:
        print(out)

    return 0


if __name__ == "__main__":
    sys.exit(main())
