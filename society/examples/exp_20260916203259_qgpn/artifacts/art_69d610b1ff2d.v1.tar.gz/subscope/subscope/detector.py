"""Detect recurring subscriptions / bills from a list of Transactions."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, timedelta
from statistics import mean, pstdev
from typing import Dict, List, Optional, Tuple

from .parser import Transaction

# Known recurring cadences we try to match, in days, with tolerance.
CADENCES: List[Tuple[str, int, int]] = [
    ("weekly", 7, 2),
    ("biweekly", 14, 3),
    ("monthly", 30, 6),
    ("quarterly", 91, 10),
    ("semiannual", 182, 14),
    ("annual", 365, 20),
]

AMOUNT_TOLERANCE_RATIO = 0.15  # amounts within 15% are considered "the same" charge


@dataclass
class Occurrence:
    date: date
    amount: float
    raw_description: str


@dataclass
class Subscription:
    merchant_key: str
    display_name: str
    cadence: str
    occurrences: List[Occurrence]
    typical_amount: float
    total_spent: float
    first_seen: date
    last_seen: date
    next_expected: date
    price_changes: List[Tuple[date, float, float]] = field(default_factory=list)
    likely_cancelled: bool = False

    @property
    def occurrence_count(self) -> int:
        return len(self.occurrences)

    @property
    def annualized_cost(self) -> float:
        per_year = {
            "weekly": 52,
            "biweekly": 26,
            "monthly": 12,
            "quarterly": 4,
            "semiannual": 2,
            "annual": 1,
        }.get(self.cadence, 12)
        return round(self.typical_amount * per_year, 2)


def _cluster_by_merchant(transactions: List[Transaction]) -> Dict[str, List[Transaction]]:
    groups: Dict[str, List[Transaction]] = defaultdict(list)
    for t in transactions:
        if t.amount <= 0:
            continue  # skip refunds/deposits for subscription detection
        if not t.description:
            continue
        groups[t.description].append(t)
    return groups


def _split_by_amount(txns: List[Transaction]) -> List[List[Transaction]]:
    """Within a merchant group, split into sub-clusters of similar amount.

    A merchant might have both a subscription (fixed amount) and unrelated
    one-off purchases (variable amounts) - e.g. "AMAZON". We cluster amounts
    that are within AMOUNT_TOLERANCE_RATIO of each other.
    """
    sorted_txns = sorted(txns, key=lambda t: t.amount)
    clusters: List[List[Transaction]] = []
    current: List[Transaction] = []
    for t in sorted_txns:
        if not current:
            current = [t]
            continue
        ref = mean(x.amount for x in current)
        if abs(t.amount - ref) <= ref * AMOUNT_TOLERANCE_RATIO + 0.01:
            current.append(t)
        else:
            clusters.append(current)
            current = [t]
    if current:
        clusters.append(current)
    return clusters


def _match_cadence(dates: List[date]) -> Optional[Tuple[str, float]]:
    """Given sorted dates, find the best-fit cadence and confidence 0-1."""
    if len(dates) < 2:
        return None
    diffs = [(dates[i + 1] - dates[i]).days for i in range(len(dates) - 1)]
    avg_diff = mean(diffs)
    best: Optional[Tuple[str, float]] = None
    for name, target, tol in CADENCES:
        if abs(avg_diff - target) > tol:
            continue
        # Require the *individual* gaps to be regular, not just the average.
        # This is what separates a real subscription (charged every ~30
        # days, every time) from coincidentally-similar-amount noise (e.g.
        # coffee/Amazon purchases that average out to a plausible cadence
        # but whose actual gaps are all over the place).
        matching = sum(1 for d in diffs if abs(d - target) <= tol)
        ratio = matching / len(diffs)
        if ratio < 0.75:
            continue
        spread = pstdev(diffs) if len(diffs) > 1 else 0.0
        consistency = max(0.0, 1.0 - spread / target)
        count_bonus = min(1.0, len(dates) / 4)
        confidence = 0.4 * consistency + 0.3 * count_bonus + 0.3 * ratio
        if best is None or confidence > best[1]:
            best = (name, confidence)
    return best


def detect_subscriptions(
    transactions: List[Transaction],
    min_occurrences: int = 3,
    min_confidence: float = 0.4,
    today: Optional[date] = None,
) -> List[Subscription]:
    """Detect recurring subscription-like charges.

    Requires at least `min_occurrences` charges of a similar amount from the
    same normalized merchant at a roughly regular cadence.
    """
    today = today or max((t.date for t in transactions), default=date.today())
    subscriptions: List[Subscription] = []
    groups = _cluster_by_merchant(transactions)

    for merchant_key, txns in groups.items():
        for cluster in _split_by_amount(txns):
            if len(cluster) < 2:
                continue
            cluster_sorted = sorted(cluster, key=lambda t: t.date)
            dates = [t.date for t in cluster_sorted]
            match = _match_cadence(dates)
            if match is None:
                continue
            cadence, confidence = match
            if confidence < min_confidence:
                continue
            # Long-period cadences (annual/semiannual) rarely accumulate
            # `min_occurrences` charges within a single year of statement
            # history, so we accept them with just 2 well-matched charges.
            required = 2 if cadence in ("annual", "semiannual") else min_occurrences
            if len(cluster_sorted) < required:
                continue

            amounts = [t.amount for t in cluster_sorted]
            typical_amount = round(mean(amounts[-3:]), 2)  # weight toward recent price
            total_spent = round(sum(amounts), 2)

            # Detect price changes: consecutive occurrences where amount
            # shifts by more than the tolerance band.
            price_changes: List[Tuple[date, float, float]] = []
            for prev, cur in zip(cluster_sorted, cluster_sorted[1:]):
                if abs(cur.amount - prev.amount) > max(0.5, prev.amount * 0.03):
                    price_changes.append((cur.date, prev.amount, cur.amount))

            cadence_days = {c[0]: c[1] for c in CADENCES}[cadence]
            last_seen = dates[-1]
            next_expected = last_seen + timedelta(days=cadence_days)
            likely_cancelled = (today - last_seen).days > cadence_days * 2 + 10

            display_name = _best_display_name(cluster_sorted)

            subscriptions.append(
                Subscription(
                    merchant_key=merchant_key,
                    display_name=display_name,
                    cadence=cadence,
                    occurrences=[
                        Occurrence(t.date, t.amount, t.raw_description) for t in cluster_sorted
                    ],
                    typical_amount=typical_amount,
                    total_spent=total_spent,
                    first_seen=dates[0],
                    last_seen=last_seen,
                    next_expected=next_expected,
                    price_changes=price_changes,
                    likely_cancelled=likely_cancelled,
                )
            )

    subscriptions.sort(key=lambda s: s.annualized_cost, reverse=True)
    return subscriptions


def _best_display_name(txns: List[Transaction]) -> str:
    # Use the shortest raw description as it's often the cleanest, title-cased.
    raw = min((t.raw_description for t in txns), key=len)
    return raw.strip()


def summarize(subscriptions: List[Subscription]) -> Dict[str, float]:
    active = [s for s in subscriptions if not s.likely_cancelled]
    return {
        "subscription_count": len(subscriptions),
        "active_count": len(active),
        "monthly_burn": round(sum(s.annualized_cost for s in active) / 12, 2),
        "annual_burn": round(sum(s.annualized_cost for s in active), 2),
        "flagged_price_increases": sum(1 for s in subscriptions if s.price_changes),
    }
