"""A tiny local web UI: drag-and-drop a CSV, get a dashboard back.

No third-party dependencies (stdlib http.server only). Runs entirely on
localhost; your transaction data never leaves your machine. This is meant
for people who don't want to touch a terminal beyond `subscope-web`.
"""
from __future__ import annotations

import argparse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

from .detector import detect_subscriptions
from .parser import ParseError, parse_csv
from .report import to_html

UPLOAD_PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>SubScope</title>
<style>
  body { font-family: -apple-system, Segoe UI, Roboto, Arial, sans-serif; background: #0b0f14; color: #e6edf3;
         display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
  .box { max-width: 560px; text-align: center; }
  h1 { font-size: 2rem; margin-bottom: 0.2rem; }
  p.sub { color: #8b949e; margin-top: 0; }
  .drop { border: 2px dashed #30363d; border-radius: 14px; padding: 3rem 1.5rem; margin-top: 2rem; }
  input[type=file] { display: block; margin: 1rem auto; color: #e6edf3; }
  button { background: #238636; color: white; border: none; padding: 0.7rem 1.6rem; border-radius: 8px;
           font-size: 1rem; cursor: pointer; margin-top: 0.5rem; }
  button:hover { background: #2ea043; }
  .note { color: #8b949e; font-size: 0.85rem; margin-top: 2rem; }
  .error { color: #e05555; margin-top: 1rem; }
</style>
</head>
<body>
<div class="box">
  <h1>SubScope</h1>
  <p class="sub">Find the subscriptions quietly draining your bank account.</p>
  <div class="drop">
    <form method="POST" action="/analyze" enctype="multipart/form-data">
      <p>Upload a CSV export from your bank or credit card:</p>
      <input type="file" name="csv_file" accept=".csv" required>
      <button type="submit">Analyze</button>
    </form>
  </div>
  __ERROR_HTML__
  <p class="note">Runs 100% locally. Your file is analyzed in memory on this
  machine and is never uploaded anywhere else.</p>
</div>
</body>
</html>
"""


def _parse_multipart(body: bytes, content_type: str) -> bytes:
    """Extract the first file's raw bytes from a multipart/form-data body."""
    if "boundary=" not in content_type:
        raise ValueError("missing multipart boundary")
    boundary = content_type.split("boundary=")[-1].strip().strip('"').encode()
    delimiter = b"--" + boundary
    parts = body.split(delimiter)
    for part in parts:
        part = part.strip(b"\r\n")
        if not part or part == b"--":
            continue
        if b"\r\n\r\n" not in part:
            continue
        headers_blob, _, content = part.partition(b"\r\n\r\n")
        if b"filename=" not in headers_blob:
            continue
        content = content.rstrip(b"\r\n")
        return content
    raise ValueError("no file part found in upload")


class Handler(BaseHTTPRequestHandler):
    server_version = "SubScope/0.1"

    def log_message(self, fmt, *args):  # quieter logs
        pass

    def do_GET(self):
        if self.path not in ("/", ""):
            self.send_response(404)
            self.end_headers()
            return
        html = UPLOAD_PAGE.replace("__ERROR_HTML__", "")
        self._send_html(html)

    def do_POST(self):
        if self.path != "/analyze":
            self.send_response(404)
            self.end_headers()
            return
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        content_type = self.headers.get("Content-Type", "")
        try:
            file_bytes = _parse_multipart(body, content_type)
            text = file_bytes.decode("utf-8", errors="replace")
            transactions = parse_csv(text)
            if not transactions:
                raise ParseError("No valid transactions could be parsed from this file.")
            subs = detect_subscriptions(transactions)
            html = to_html(subs)
            self._send_html(html)
        except (ParseError, ValueError) as e:
            error_html = f'<p class="error">Could not analyze that file: {e}</p>'
            self._send_html(UPLOAD_PAGE.replace("__ERROR_HTML__", error_html))

    def _send_html(self, html: str):
        encoded = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="subscope-web", description="Run SubScope's local web UI.")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-browser", action="store_true", help="Don't auto-open a browser tab.")
    args = parser.parse_args(argv)

    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    url = f"http://127.0.0.1:{args.port}/"
    print(f"SubScope running at {url}  (Ctrl+C to stop)")
    if not args.no_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
