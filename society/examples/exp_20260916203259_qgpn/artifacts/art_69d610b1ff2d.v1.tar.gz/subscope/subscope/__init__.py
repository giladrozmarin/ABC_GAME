"""SubScope: detect recurring subscriptions and creeping costs from bank CSV exports."""

__version__ = "0.1.0"
