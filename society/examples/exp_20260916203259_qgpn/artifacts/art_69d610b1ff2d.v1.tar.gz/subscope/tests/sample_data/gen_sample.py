"""One-off script used to build sample_transactions.csv (not part of the test suite)."""
import csv
import random
from datetime import date, timedelta

random.seed(42)

rows = []


def add(d, desc, amount):
    rows.append((d.isoformat(), desc, f"-{amount:.2f}"))  # bank convention: purchases negative


# Netflix: monthly, price increase partway through
d = date(2025, 9, 5)
price = 15.99
while d <= date(2026, 9, 5):
    if d >= date(2026, 4, 1):
        price = 17.99
    add(d, f"NETFLIX.COM 866-579-7172 CA", price)
    # advance ~1 month
    month = d.month + 1
    year = d.year + (1 if month > 12 else 0)
    month = month if month <= 12 else 1
    d = date(year, month, 5)

# Spotify: monthly, steady
d = date(2025, 9, 12)
while d <= date(2026, 9, 12):
    add(d, "SPOTIFY USA 8885551234 NY", 9.99)
    month = d.month + 1
    year = d.year + (1 if month > 12 else 0)
    month = month if month <= 12 else 1
    d = date(year, month, 12)

# Adobe: annual
add(date(2024, 10, 20), "ADOBE CREATIVE CLOUD 8008336687", 599.88)
add(date(2025, 10, 20), "ADOBE CREATIVE CLOUD 8008336687", 599.88)

# Gym: monthly then cancelled
d = date(2025, 9, 1)
for _ in range(5):
    add(d, "ANYTIME FITNESS 4021 MEMB", 44.99)
    month = d.month + 1
    year = d.year + (1 if month > 12 else 0)
    month = month if month <= 12 else 1
    d = date(year, month, 1)
# then nothing after Jan 2026 -> cancelled

# HelloFresh: weekly, still active
d = date(2026, 4, 6)
while d <= date(2026, 9, 14):
    add(d, "HELLOFRESH 8556098092 NY", 59.94)
    d += timedelta(days=7)

# iCloud storage: monthly small amount
d = date(2025, 9, 8)
while d <= date(2026, 9, 8):
    add(d, "APPLE.COM/BILL ICLOUD+", 2.99)
    month = d.month + 1
    year = d.year + (1 if month > 12 else 0)
    month = month if month <= 12 else 1
    d = date(year, month, 8)

# Noise: irregular Amazon purchases (variable amount & timing) - should NOT be flagged
d = date(2025, 9, 1)
for _ in range(30):
    d = d + timedelta(days=random.randint(3, 18))
    if d > date(2026, 9, 16):
        break
    amt = round(random.uniform(8, 120), 2)
    add(d, f"AMAZON.COM*{random.randint(100000,999999)} AMZN.COM/BILL", amt)

# Noise: irregular coffee shop purchases (frequent, variable amount)
d = date(2025, 9, 1)
for _ in range(60):
    d = d + timedelta(days=random.randint(1, 6))
    if d > date(2026, 9, 16):
        break
    amt = round(random.uniform(3.25, 7.75), 2)
    add(d, "STARBUCKS STORE 08912 SEATTLE WA", amt)

# One-off large purchase, should never be flagged (only 1 occurrence)
add(date(2026, 2, 14), "BEST BUY 00123 SEATTLE WA", 449.00)

# A paycheck deposit (credit / negative-of-negative -> positive inflow), tests sign handling
for i in range(24):
    d2 = date(2025, 9, 1) + timedelta(days=15 * i)
    if d2 > date(2026, 9, 16):
        break
    rows.append((d2.isoformat(), "PAYROLL DIRECT DEP ACME CORP", "2450.00"))

rows.sort(key=lambda r: r[0])

with open("tests/sample_data/sample_transactions.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["Date", "Description", "Amount"])
    w.writerows(rows)

print(f"wrote {len(rows)} rows")
