from datetime import date, timedelta

import pytest

from subscope.detector import detect_subscriptions
from subscope.parser import Transaction


def make_txn(d: date, desc: str, amount: float) -> Transaction:
    return Transaction(date=d, description=desc, amount=amount, raw_description=desc, row_number=0)


def monthly_series(desc, amount, start, count, day_step=30):
    txns = []
    d = start
    for _ in range(count):
        txns.append(make_txn(d, desc, amount))
        d = d + timedelta(days=day_step)
    return txns


def test_detects_simple_monthly_subscription():
    txns = monthly_series("netflix.com", 15.99, date(2026, 1, 5), 6)
    subs = detect_subscriptions(txns, today=date(2026, 6, 10))
    assert len(subs) == 1
    assert subs[0].cadence == "monthly"
    assert subs[0].typical_amount == pytest.approx(15.99)
    assert not subs[0].likely_cancelled


def test_detects_weekly_subscription():
    txns = monthly_series("hellofresh", 59.94, date(2026, 1, 1), 8, day_step=7)
    subs = detect_subscriptions(txns, today=date(2026, 3, 1))
    assert len(subs) == 1
    assert subs[0].cadence == "weekly"


def test_detects_annual_subscription_with_only_two_charges():
    txns = [
        make_txn(date(2024, 10, 20), "adobe creative cloud", 599.88),
        make_txn(date(2025, 10, 20), "adobe creative cloud", 599.88),
    ]
    subs = detect_subscriptions(txns, today=date(2026, 1, 1))
    assert len(subs) == 1
    assert subs[0].cadence == "annual"
    assert subs[0].next_expected == date(2026, 10, 20)


def test_single_purchase_is_not_a_subscription():
    txns = [make_txn(date(2026, 2, 14), "best buy", 449.00)]
    subs = detect_subscriptions(txns, today=date(2026, 6, 1))
    assert subs == []


def test_irregular_amount_purchases_are_not_flagged():
    # Same merchant, wildly different amounts and irregular days -> noise.
    import random

    random.seed(1)
    d = date(2026, 1, 1)
    txns = []
    for _ in range(20):
        d = d + timedelta(days=random.randint(1, 6))
        txns.append(make_txn(d, "amazon.com", round(random.uniform(8, 120), 2)))
    subs = detect_subscriptions(txns, today=date(2026, 6, 1))
    assert subs == []


def test_irregular_timing_same_amount_is_not_flagged():
    # Same amount every time (plausible for a fixed-price item) but the
    # days between purchases are random/inconsistent -> should not be
    # treated as a subscription cadence.
    import random

    random.seed(2)
    d = date(2026, 1, 1)
    txns = []
    for _ in range(15):
        d = d + timedelta(days=random.randint(1, 10))
        txns.append(make_txn(d, "corner store", 4.50))
    subs = detect_subscriptions(txns, today=date(2026, 6, 1))
    assert subs == []


def test_detects_price_increase():
    txns = monthly_series("netflix.com", 15.99, date(2026, 1, 5), 3)
    txns += monthly_series("netflix.com", 17.99, date(2026, 4, 5), 3)
    subs = detect_subscriptions(txns, today=date(2026, 7, 10))
    assert len(subs) == 1
    assert subs[0].price_changes
    d, old, new = subs[0].price_changes[0]
    assert old == pytest.approx(15.99)
    assert new == pytest.approx(17.99)


def test_flags_likely_cancelled_subscription():
    txns = monthly_series("gym", 44.99, date(2025, 9, 1), 5)
    subs = detect_subscriptions(txns, today=date(2026, 9, 16))
    assert len(subs) == 1
    assert subs[0].likely_cancelled is True


def test_active_subscription_not_flagged_as_cancelled():
    txns = monthly_series("spotify", 9.99, date(2026, 1, 12), 6)
    subs = detect_subscriptions(txns, today=date(2026, 6, 20))
    assert subs[0].likely_cancelled is False


def test_refunds_and_deposits_are_ignored():
    txns = monthly_series("netflix.com", 15.99, date(2026, 1, 5), 4)
    txns.append(make_txn(date(2026, 2, 1), "payroll deposit", -2000.00))
    subs = detect_subscriptions(txns, today=date(2026, 5, 1))
    assert len(subs) == 1
    assert subs[0].display_name.startswith("netflix") or "netflix" in subs[0].merchant_key


def test_two_different_merchants_detected_independently():
    txns = monthly_series("netflix.com", 15.99, date(2026, 1, 5), 5)
    txns += monthly_series("spotify usa", 9.99, date(2026, 1, 12), 5)
    subs = detect_subscriptions(txns, today=date(2026, 6, 1))
    names = {s.merchant_key for s in subs}
    assert len(subs) == 2
    assert "netflix.com" in names
    assert "spotify usa" in names


def test_annualized_cost_scales_by_cadence():
    weekly = monthly_series("hellofresh", 10.0, date(2026, 1, 1), 6, day_step=7)
    subs = detect_subscriptions(weekly, today=date(2026, 3, 1))
    assert subs[0].annualized_cost == pytest.approx(520.0)  # 10 * 52
