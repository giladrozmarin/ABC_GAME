import re
import threading
import time
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer

import pytest

from subscope.webapp import Handler


@pytest.fixture
def running_server():
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    time.sleep(0.2)
    yield port
    server.shutdown()


def _upload(port, filename, content: bytes):
    boundary = "----testboundary"
    body = (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="csv_file"; filename="{filename}"\r\n'
        f"Content-Type: text/csv\r\n\r\n"
    ).encode() + content + f"\r\n--{boundary}--\r\n".encode()
    conn = HTTPConnection("127.0.0.1", port)
    headers = {
        "Content-Type": f"multipart/form-data; boundary={boundary}",
        "Content-Length": str(len(body)),
    }
    conn.request("POST", "/analyze", body=body, headers=headers)
    resp = conn.getresponse()
    return resp.status, resp.read().decode()


def test_upload_page_serves(running_server):
    conn = HTTPConnection("127.0.0.1", running_server)
    conn.request("GET", "/")
    resp = conn.getresponse()
    body = resp.read().decode()
    assert resp.status == 200
    assert "Upload a CSV export" in body
    # regression guard: CSS braces must not leak the raw template placeholder
    assert "__ERROR_HTML__" not in body


def test_upload_valid_csv_returns_dashboard(running_server):
    csv_bytes = (
        b"Date,Description,Amount\n"
        b"2026-01-05,NETFLIX.COM 8005551234,-15.99\n"
        b"2026-02-05,NETFLIX.COM 8005551234,-15.99\n"
        b"2026-03-05,NETFLIX.COM 8005551234,-15.99\n"
    )
    status, body = _upload(running_server, "t.csv", csv_bytes)
    assert status == 200
    assert "netflix" in body.lower()
    values = re.findall(r'<div class="value">([0-9.]*)</div>', body)
    assert values[0] == "1"  # one subscription detected


def test_upload_invalid_csv_shows_error(running_server):
    status, body = _upload(running_server, "bad.csv", b"nonsense,file\nrow1,row2\n")
    assert status == 200
    assert "Could not analyze that file" in body
