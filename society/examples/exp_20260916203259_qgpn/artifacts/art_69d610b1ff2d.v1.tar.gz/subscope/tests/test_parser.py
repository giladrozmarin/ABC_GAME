from datetime import date

import pytest

from subscope.parser import ParseError, normalize_description, parse_csv


def test_parse_basic_single_amount_column():
    csv_text = (
        "Date,Description,Amount\n"
        "2026-01-05,NETFLIX.COM 8005551234,-15.99\n"
        "2026-01-10,PAYROLL DEPOSIT,2000.00\n"
    )
    txns = parse_csv(csv_text)
    assert len(txns) == 2
    netflix = [t for t in txns if "netflix" in t.description][0]
    payroll = [t for t in txns if "payroll" in t.description][0]
    # purchase (negative in file) becomes positive "spent" amount
    assert netflix.amount == pytest.approx(15.99)
    # deposit (positive in file) becomes negative "spent" amount
    assert payroll.amount == pytest.approx(-2000.00)


def test_parse_debit_credit_columns():
    csv_text = (
        "Posted Date,Memo,Debit,Credit\n"
        "01/05/2026,SPOTIFY,9.99,\n"
        "01/06/2026,REFUND,,5.00\n"
    )
    txns = parse_csv(csv_text)
    assert len(txns) == 2
    spotify = [t for t in txns if "spotify" in t.description][0]
    refund = [t for t in txns if "refund" in t.description][0]
    assert spotify.amount == pytest.approx(9.99)
    assert refund.amount == pytest.approx(-5.00)


def test_parse_handles_parens_and_currency_symbols():
    csv_text = "Date,Description,Amount\n2026-02-01,GYM,($45.00)\n"
    txns = parse_csv(csv_text)
    assert txns[0].amount == pytest.approx(45.00)


def test_parse_missing_date_column_raises():
    csv_text = "Foo,Description,Amount\n1,NETFLIX,-9.99\n"
    with pytest.raises(ParseError):
        parse_csv(csv_text)


def test_parse_empty_file_raises():
    with pytest.raises(ParseError):
        parse_csv("")


def test_parse_skips_unparseable_rows_but_keeps_good_ones():
    csv_text = (
        "Date,Description,Amount\n"
        "not-a-date,BROKEN,10.00\n"
        "2026-03-01,GOOD ROW,10.00\n"
    )
    txns = parse_csv(csv_text)
    assert len(txns) == 1
    assert txns[0].date == date(2026, 3, 1)


def test_normalize_description_strips_noise_and_ids():
    a = normalize_description("NETFLIX.COM 8885062929 CA")
    b = normalize_description("Netflix.com   REF029384756")
    assert a.startswith("netflix.com")
    assert b.startswith("netflix.com")


def test_normalize_description_groups_same_merchant_variants():
    a = normalize_description("AMAZON.COM*182934756 AMZN.COM/BILL WA")
    b = normalize_description("AMAZON.COM*998877665 AMZN.COM/BILL WA")
    assert a == b
