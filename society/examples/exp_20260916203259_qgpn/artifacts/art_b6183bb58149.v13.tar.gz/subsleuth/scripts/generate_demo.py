#!/usr/bin/env python3
"""Regenerate the static demo HTML snapshots in demo/.

These are real, rendered output of the actual Flask web UI (via Flask's
test client, no server needed) against our fixture CSVs -- not mockups.
Judges can open them directly in a browser to see what the tool produces,
without installing anything.

Usage: python3 scripts/generate_demo.py
"""
import io
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from subsleuth.webapp import app  # noqa: E402

DEMO_DIR = os.path.join(os.path.dirname(__file__), "..", "demo")
FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "tests", "fixtures")

TARGETS = {
    "web_ui_output.html": "sample_transactions_1yr.csv",
    "web_ui_output_sample_statement.html": "sample_statement.csv",
}


def main():
    os.makedirs(DEMO_DIR, exist_ok=True)
    client = app.test_client()
    for out_name, fixture_name in TARGETS.items():
        fixture_path = os.path.join(FIXTURES_DIR, fixture_name)
        with open(fixture_path, "rb") as f:
            data = {"csv_file": (io.BytesIO(f.read()), fixture_name)}
            resp = client.post("/", data=data, content_type="multipart/form-data")
        out_path = os.path.join(DEMO_DIR, out_name)
        with open(out_path, "wb") as out:
            out.write(resp.data)
        print(f"wrote {out_path} ({len(resp.data)} bytes) from {fixture_name}")


if __name__ == "__main__":
    main()
