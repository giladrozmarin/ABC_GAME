import os

import pytest

from subsleuth.parser import ParseError, normalize_merchant, parse_transactions

FIXTURE_DIR = os.path.join(os.path.dirname(__file__), "fixtures")


def load_fixture(name):
    with open(os.path.join(FIXTURE_DIR, name), encoding="utf-8") as f:
        return f.read()


def test_parses_sample_statement():
    text = load_fixture("sample_statement.csv")
    txs = parse_transactions(text)
    assert len(txs) == 25
    assert all(t.amount > 0 for t in txs)  # expenses normalized to positive
    first = txs[0]
    assert first.date.isoformat() == "2025-01-03"
    assert first.amount == 15.49


def test_normalize_merchant_strips_noise():
    a = normalize_merchant("NETFLIX.COM 866-579-7172")
    b = normalize_merchant("NETFLIX.COM 866-579-7172")
    assert a == b

    c = normalize_merchant("SPOTIFY USA")
    assert "SPOTIFY" in c


def test_normalize_merchant_groups_star_suffix_ids():
    a = normalize_merchant("NETFLIX*AB12CD3")
    b = normalize_merchant("NETFLIX*XY99ZZ1")
    assert a == b


def test_missing_columns_raise_parse_error():
    bad_csv = "foo,bar\n1,2\n"
    with pytest.raises(ParseError):
        parse_transactions(bad_csv)


def test_alternate_column_names_and_parens_negative():
    csv_text = (
        "Transaction Date,Payee,Transaction Amount\n"
        "01/15/2025,ACME CORP,(12.50)\n"
        "02/15/2025,ACME CORP,(12.50)\n"
    )
    txs = parse_transactions(csv_text)
    assert len(txs) == 2
    assert txs[0].amount == 12.50


def test_skips_rows_with_missing_fields():
    csv_text = "Date,Description,Amount\n2025-01-01,,-10.00\n2025-01-02,ACME,-5.00\n"
    txs = parse_transactions(csv_text)
    assert len(txs) == 1


def test_generic_signed_amount_column_excludes_deposits_and_payroll():
    """Regression test for a real bug: a generic signed 'Amount' column
    mixes expenses (negative) with deposits/refunds/payroll (positive).
    Treating positive rows as spend misdetects biweekly payroll as a huge
    recurring 'subscription'. Positive rows in a mixed-sign generic column
    must be excluded, not counted as spend."""
    csv_text = (
        "Date,Description,Amount\n"
        "2025-01-01,PAYROLL DIRECT DEP ACME CORP,2450.00\n"
        "2025-01-15,PAYROLL DIRECT DEP ACME CORP,2450.00\n"
        "2025-01-05,NETFLIX.COM,-15.49\n"
        "2025-02-05,NETFLIX.COM,-15.49\n"
    )
    txs = parse_transactions(csv_text)
    descriptions = {t.description for t in txs}
    assert "PAYROLL DIRECT DEP ACME CORP" not in descriptions
    assert any("NETFLIX" in d for d in descriptions)
    assert len(txs) == 2


def test_credit_card_style_positive_spend_with_minority_negative_refund():
    """Regression test for a real bug found via adversarial testing: many
    credit-card exports use the OPPOSITE convention from a checking account
    -- purchases are positive, and payments/refunds/credits are the (rare)
    negative rows. The old 'any negative present => negative is spend' rule
    would, on a file like this, treat every real purchase as a 'deposit' and
    silently drop it -- while the isolated refund (the minority sign) got
    flipped into the only detected 'spend'. That's a worse failure than a
    single misclassification: the whole report would go empty/wrong on a
    very common real-world file shape. We now take a majority vote on sign:
    whichever sign is strictly more common is spend, so a single refund
    among many real charges doesn't invert the whole file."""
    csv_text = (
        "Date,Description,Amount\n"
        "2025-01-01,RENT PAYMENT LLC,1500.00\n"
        "2025-02-01,RENT PAYMENT LLC,1500.00\n"
        "2025-03-01,RENT PAYMENT LLC,1500.00\n"
        "2025-03-03,RENT PAYMENT LLC REFUND,-1500.00\n"
    )
    txs = parse_transactions(csv_text)
    spends = [t for t in txs if t.amount == 1500.00]
    assert len(spends) == 3
    assert len(txs) == 3


def test_unsigned_debit_column_still_treats_positive_as_spend():
    """A column explicitly named 'Debit'/'Withdrawal' is unsigned by
    convention -- a positive value there IS money out, unlike a generic
    signed 'Amount' column."""
    csv_text = "Date,Description,Debit\n2025-01-05,ACME CORP,15.49\n2025-02-05,ACME CORP,15.49\n"
    txs = parse_transactions(csv_text)
    assert len(txs) == 2
    assert all(t.amount == 15.49 for t in txs)


def test_semicolon_delimited_csv():
    # Some European bank exports (and Excel's regional CSV export) use
    # semicolons instead of commas. Before delimiter sniffing was added,
    # this silently parsed to zero transactions instead of erroring or
    # working -- the worst kind of failure (looks successful, is empty).
    csv_text = "Date;Description;Amount\n2026-01-05;NETFLIX;-15.99\n2026-02-05;NETFLIX;-15.99\n"
    txns = parse_transactions(csv_text)
    assert len(txns) == 2
    assert txns[0].amount == 15.99


def test_utf8_bom_is_stripped():
    csv_text = "﻿Date,Description,Amount\n2026-01-05,NETFLIX,-15.99\n"
    txns = parse_transactions(csv_text)
    assert len(txns) == 1
    assert txns[0].description == "NETFLIX"


def test_all_positive_generic_amount_column_still_parses_as_spend():
    """When a generic 'Amount' column never contains a negative value (e.g.
    some Amex-style exports where Amount always means 'charged'), we can't
    tell it apart from 'this account only had expenses in this window', so
    we fall back to treating positive amounts as spend -- otherwise an
    entire valid export would silently produce zero transactions."""
    csv_text = "Date,Description,Amount\n2025-01-15,ADOBE,52.99\n2025-02-15,ADOBE,52.99\n"
    txs = parse_transactions(csv_text)
    assert len(txs) == 2
    assert all(t.amount == 52.99 for t in txs)
