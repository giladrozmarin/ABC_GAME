"""Unit tests for the scanner + report logic using a fully mocked OSV
client (no network access needed). This is what CI should run."""
from pathlib import Path
from unittest.mock import MagicMock, patch

import json

from depaudit import osv
from depaudit.report import render_console, render_json, render_markdown
from depaudit.scanner import scan_path

FIXTURES = Path(__file__).parent.parent / "fixtures"


def _fake_query_batch(queries, session=None):
    # lodash@4.17.15 -> one known vuln id, everything else clean
    out = []
    for q in queries:
        if q["package"]["name"] == "lodash":
            out.append(["GHSA-fake-lodash-1"])
        else:
            out.append([])
    return out


def _fake_fetch_vuln_details(ids, session=None):
    return {
        "GHSA-fake-lodash-1": osv.Vuln(
            id="GHSA-fake-lodash-1",
            summary="Prototype Pollution in lodash",
            severity="HIGH",
            cvss_score=7.4,
            fixed_versions=["4.17.19"],
            url="https://osv.dev/vulnerability/GHSA-fake-lodash-1",
        )
    }


@patch("depaudit.scanner.osv.fetch_vuln_details", side_effect=_fake_fetch_vuln_details)
@patch("depaudit.scanner.osv.query_batch", side_effect=_fake_query_batch)
def test_scan_finds_known_vuln(mock_batch, mock_details):
    result = scan_path(FIXTURES / "vulnerable_project")
    vulnerable_names = {f.dependency.name for f in result.vulnerable_findings}
    assert "lodash" in vulnerable_names
    assert "left-pad" not in vulnerable_names

    lodash_finding = next(f for f in result.findings if f.dependency.name == "lodash")
    assert lodash_finding.worst_severity == "HIGH"
    assert lodash_finding.vulns[0].fixed_versions == ["4.17.19"]

    counts = result.severity_counts()
    assert counts["HIGH"] == 1

    console = render_console(result)
    assert "lodash@4.17.15" in console
    assert "GHSA-fake-lodash-1" in console

    md = render_markdown(result)
    assert "lodash@4.17.15" in md
    assert "HIGH" in md

    payload = json.loads(render_json(result))
    assert payload["vulnerable_count"] == 1
    assert payload["severity_counts"]["HIGH"] == 1
    assert payload["findings"][0]["name"] == "lodash"
    assert payload["findings"][0]["vulnerabilities"][0]["id"] == "GHSA-fake-lodash-1"


@patch("depaudit.scanner.osv.fetch_vuln_details", side_effect=lambda ids, session=None: {})
@patch("depaudit.scanner.osv.query_batch", side_effect=lambda queries, session=None: [[] for _ in queries])
def test_scan_clean_project(mock_batch, mock_details):
    result = scan_path(FIXTURES / "clean_project")
    assert result.vulnerable_findings == []
    console = render_console(result)
    assert "No known vulnerabilities" in console


def test_scan_empty_dir(tmp_path):
    result = scan_path(tmp_path)
    assert result.manifests_scanned == []
    assert result.dependencies == []
    console = render_console(result)
    assert "No package.json" in console
